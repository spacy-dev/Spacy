#! /bin/sh
# Copyright 2018 - 2018 Zuse Institute Berlin




GCC_CONFIGURE=

#------------------------------------------------------------------------------
# Install MPC if required. This library is a prerequisite of GCC, but
# if there is a system library, available, we can use that.
if [ "$MPC_SRC_PATH" != "" ]; then
  cd $DOWNLOAD
  echo downloading MPC library from $MPC_SRC_PATH
  wget -c $MPC_SRC_PATH

  cd $SCRATCH
  TARFILE=$DOWNLOAD/`basename $MPC_SRC_PATH`
  tar xzf $TARFILE

  SRCDIR=`basename -s .gz $TARFILE`
  SRCDIR=`basename -s .tar $SRCDIR`
  SRCDIR=$SCRATCH/`basename -s .tgz $SRCDIR`

  cd $SRCDIR
  echo configuring MPC
  ./configure --prefix=$TARGET/GCC
  make
  make install
  GCC_CONFIGURE="$GCC_CONFIGURE --with-mpc=$TARGET/GCC"
fi

#------------------------------------------------------------------------------
# Install GCC itself.

cd $DOWNLOAD
echo downloading GCC from $GCC_SRC_PATH.
wget -c $GCC_SRC_PATH

cd $SCRATCH
TARFILE=$DOWNLOAD/`basename $GCC_SRC_PATH`
tar xzf $TARFILE

SRCDIR=`basename -s .gz $TARFILE`
SRCDIR=`basename -s .tar $SRCDIR`
SRCDIR=$SCRATCH/`basename -s .tgz $SRCDIR`

OBJDIR=$SCRATCH/objdir
mkdir $OBJDIR

# GCC configuration (consider --diable-bootstrap for faster installation)
cd $OBJDIR
echo configuring GCC
$SRCDIR/configure --prefix=$TARGET $GCC_CONFIGURE

# GCC building (consider executing the self test as well)
echo building GCC
make -j 4

# GCC installation
echo installing GCC
make install

# Report C++ compiler to use
CXX=$TARGET/bin/g++
CC=$TARGET/bin/gcc
FC=$TARGET/bin/gfortran
FTNLIB="-lgfortran -lpthread"


#------------------------------------------------------------------------------
# Clean up
# if [ -n "$SCRATCH" ]; then
#   echo running rm -r "$SCRATCH"/* in a few seconds
#   sleep 20
#   rm -r "$SCRATCH"/*
# fi



