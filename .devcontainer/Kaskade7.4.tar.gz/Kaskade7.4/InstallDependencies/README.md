# Kaskade 7 installation scripts

This is a set of shell scripts to install third party libraries
needed by Kaskade 7. It consists of simple scripts intended to
- work well in specific basic situations
- be easily adapted to particular needs.

To start the installation, edit the first part of file "install.sh" as
you see fit, following the detailed comments in that file,
and then execute "bash install.sh".

