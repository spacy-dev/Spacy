/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2015 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef MIXEDFEM_HH
#define MIXEDFEM_HH

#include <algorithm>
#include <type_traits>
#include <iostream>

#include "fem/functional_aux.hh"
#include "fem/fixdune.hh"
#include "fem/variables.hh"

#include <dune/common/fvector.hh>
#include <dune/common/fmatrix.hh>

#include "utilities/linalg/scalarproducts.hh"

template <class RType, class VarSet, class MatVarSet>
class GFFunctional : public Kaskade::FunctionalBase<Kaskade::WeakFormulation>
{
   
  public:
  using Scalar = RType;
  using OriginVars = VarSet;
  using AnsatzVars = VarSet;
  using TestVars = VarSet;
  
  using Cell = typename AnsatzVars::Grid::template Codim<0>::Entity;
  using Position = Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension>;

  static constexpr int dim = AnsatzVars::Grid::dimension; //Achtung , ist 2 !!
  static constexpr int hIdx = 0;
  
  static constexpr int hSpaceIdx = Kaskade::spaceIndex<AnsatzVars, hIdx>; // Ist 0
  
  // convenient template aliases
  template <int row>
  static constexpr int testComponents = TestVars::template components<row>; // 
  template <int row>
  static constexpr int ansatzComponents = AnsatzVars::template components<row>; // 

  class DomainCache : public Kaskade::CacheBase<GFFunctional, DomainCache>
  {

  public:
    DomainCache(GFFunctional<RType, AnsatzVars, MatVarSet> const &f_,
                typename AnsatzVars::VariableSet const &vars_, int flags = 7) :vars(vars_) ,f(f_)                                                                      
    {   


    }
    
    void moveTo(Cell const &entity) { e = &entity; }

    template <class Position, class Evaluators>
    void evaluateAt(Position const &x, Evaluators const &evaluators)
    {
      using namespace boost::fusion;
    //  Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension> xglob = e->geometry().global(x);
      
      h = at_c<hIdx>(vars.data).value(at_c<hSpaceIdx>(evaluators)); //(h)
      dh = at_c<hIdx>(vars.data).derivative(at_c<hSpaceIdx>(evaluators)); //(hx hy)
      
      hydrK = boost::fusion::at_c<0>(f.mat.data).value(*e, x);

    }
    
    Scalar d0() const
    {
      return 0.0;
    }

    template <int row>
    Scalar d1_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg) const
    {
            

           Dune::FieldMatrix<Scalar,1,2 > scaleddh;
           scaleddh[0][0] = dh[0][0];
           scaleddh[0][1] = dh[0][1];
           
           
           scaleddh[0][0]*= hydrK[0];
           scaleddh[0][1]*= hydrK[1];

            //return sp(scaleddh,arg.derivative);
           return  scaleddh[0][0]*arg.derivative[0][0] + scaleddh[0][1]*arg.derivative[0][1];
    }

    template <int row, int col>
    Scalar d2_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg1,
                   Kaskade::VariationalArg<Scalar, dim, ansatzComponents<col>> const &arg2) const
    {
                       
           Dune::FieldMatrix<Scalar,1,2 > scaleddh;
           scaleddh[0][0] = arg2.derivative[0][0];
           scaleddh[0][1] = arg2.derivative[0][1];
           
           scaleddh[0][0]*= hydrK[0];
           scaleddh[0][1]*= hydrK[1];
           
           //return sp(scaleddh,arg1.derivative);
           return  scaleddh[0][0]*arg1.derivative[0][0] + scaleddh[0][1]*arg1.derivative[0][1];
    }
    

    
  private:
    typename AnsatzVars::VariableSet const &vars;
    Kaskade::LinAlg::EuclideanScalarProduct sp;
    Cell const* e;

    Dune::FieldVector<Scalar,1> h; //1x1
    Dune::FieldMatrix<Scalar,1,2 > dh; //1x2
    
    Dune::FieldVector<Scalar,2>  hydrK;

    GFFunctional const& f;
  };
  
  class BoundaryCache : public Kaskade::CacheBase<GFFunctional, BoundaryCache>
  {

    using FaceIterator = typename AnsatzVars::Grid::LeafIntersectionIterator;

  public:    

    BoundaryCache(GFFunctional<RType, AnsatzVars,MatVarSet> const &F,
                  typename AnsatzVars::VariableSet const &vars_,
                  int flags = 7) : vars(vars_), face(nullptr), penalty(1e20),h0(0)
    {

    }

    void moveTo(FaceIterator const &face_) { face = &face_; }

    template <class Evaluators>
    void evaluateAt(Dune::FieldVector<typename AnsatzVars::Grid::ctype, dim - 1> const &x, Evaluators const &evaluators)
    {
      using namespace boost::fusion;

      Dune::FieldVector<Scalar, dim> xglob = (*face)->geometry().global(x);
          
      h = at_c<hIdx>(vars.data).value(at_c<hSpaceIdx>(evaluators));
         
      if(xglob[1] < 0.0001)
      {
          penalty = 1e20;  
          h0[0] = 0.0;
      }
      
      else if(xglob[1] > 9.9999)
      {
          penalty = 1e20;
          h0[0] = 12.0;
      }
             
      else
      {
          penalty = 0.0;
      }
    }

    Scalar d0() const
    {
      return 0.5 *  penalty * (h - h0) * (h - h0);
    }

    template <int row>
    Scalar d1_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg) const
    {

        

        return penalty * (h - h0) * arg.value;
           

    }

    template <int row, int col>
    Scalar d2_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg1,
                   Kaskade::VariationalArg<Scalar, dim, ansatzComponents<col>> const &arg2) const
    {

        return penalty * arg1.value * arg2.value;

    }


  private:
    typename AnsatzVars::VariableSet const &vars;
    FaceIterator const *face;

    Scalar penalty;

    Dune::FieldVector<Scalar,dim > h; //1x2 
    Dune::FieldVector<Scalar,dim > h0; //1x2 
  };
  


  

public:
  GFFunctional(MatVarSet const& mat_)  : mat(mat_){}
  
  template <int row>
  struct D1 : public Kaskade::FunctionalBase<Kaskade::WeakFormulation>::D1<row>
  {
    static bool const present   = true;
  };

  template <int row, int col>
  struct D2 : public Kaskade::FunctionalBase<Kaskade::WeakFormulation>::D2<row, col>
  {
    static bool const present = true;
    //static bool const symmetric = true;
    static bool const lumped = false;
  };
    

  template <class Cell>
  int integrationOrder(Cell const & /* cell */, int shapeFunctionOrder, bool boundary) const
  {
    if (boundary)
      return 2 * shapeFunctionOrder; // mass term u*u on boundary
    else
      return 2 * (shapeFunctionOrder + 1); // energy term "u_x * u_x" in interior
  }

private:

 //Hydraulic conductivity
    MatVarSet const& mat;  

};

#endif
