/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2018 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <fstream>
#include <limits>

#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"
#include "dune/grid/io/file/dgfparser.hh"
#include "dune/grid/io/file/gmshreader.hh"

#include "dune/istl/solvers.hh"

#include "fem/assemble.hh"
// #include "fem/istlinterface.hh"
#include "fem/functional_aux.hh"
#include "fem/gridmanager.hh"
#include "fem/lagrangespace.hh"
#include "fem/variables.hh"
#include "fem/norms.hh"
#include "fem/hierarchicErrorEstimator.hh"
// #include "fem/diffops/elastoVariationalFnuctionals.hh"

#include "linalg/direct.hh"
#include "linalg/umfpack_solve.hh"
/*
#include "linalg/iluprecond.hh"      // ILUT, ILUK, ARMS
#include "linalg/cg.hh"
*/

#include "mg/hb.hh"

#include "io/vtk.hh"
#include "io/matlab.hh"

#include <boost/program_options.hpp>

#include "utilities/timing.hh"
#include "utilities/enums.hh"
#include "utilities/kaskopt.hh"
#include "utilities/gridGeneration.hh"

using namespace Kaskade;
#include "gf.hh"

namespace po = boost::program_options;

struct materialdata
{
    using Scalar = double;
    static int const components = 2;
    using ValueType = Dune::FieldVector<Scalar,components>;

    materialdata(){}   

    template <class Cell> int order(Cell const&) const { return std::numeric_limits<int>::max(); }
 
    template <class Cell>
    ValueType value(Cell const& cell,

                    Dune::FieldVector<typename Cell::Geometry::ctype,Cell::dimension> const& localCoordinate) const 

                    { 
                        Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> x = cell.geometry().global(localCoordinate);

                        /*
                        Unconsolidated Sedimentary Materials
                        Material 	Hydraulic Conductivity
                                    (m/sec)
                        Gravel 	3×10-4 to 3×10-2
                        Coarse sand 	9×10-7 to 6×10-3
                        Medium sand 	9×10-7 to 5×10-4
                        Fine sand 	2×10-7 to 2×10-4
                        Silt, loess 	1×10-9 to 2×10-5
                        Till 	1×10-12 to 2×10-6
                        Clay 	1×10-11 to 4.7×10-9
                        Unweathered marine clay 	8×10-13 to 2×10-9
                        */
                         if( x[1] <= 5.0 )
                         {
                            ValueType K(0);
                            K[0] = 4.7E-7; 
                            K[1] = 4.7E-7;
                            return K;
                         }

                         else if( x[1] > 5.0 && x[1] <= 8.0 )
                         {

                            ValueType K(0);
                            K[0] = 9E-5; 
                            K[1] = 9E-5;
                            return K;
                         }
 
                         else if( x[1] > 8.0  )
                         {

                            ValueType K(0);
                            K[0] = 3E-2; //Kx
                            K[1] = 3E-2; //Ky
                            
                            return K;
                         }   
                    }
};

int main(int argc, char **argv)
{
    /**

    TUTORIAL PROGRAM FOR CALCULATING THE HYDRAULIC HEAD (2D)
    

    Form theory its known that the hydraulic head for saturated soils can by calculated by
    div(K * grad(h)) = 0 
    
    where K represents the hydraulkic conductivity tensor of the material.

    

    h: RxRxR -> R

    K: RxRxR x RxRxR 




    This tutorial considers a two dimensional case following the example problem form "Groundwater Modeling by the Finite Element Method by Jonathan Istok, Page 35"
    

    The following weak formulation has to be solved

    

    Find h in H1(Omega) such that

    

    int_Omega (K * grad(h)) * grad(w) dOmega = 0  for all w in H1

    
    with the Dirichlet boundaries
    h = 12 for y = 10
    h = 0  for y = 0 
    

   */    
    
    
    using namespace boost::fusion;
    auto &timer = Timings::instance();
    
    std::cout << "\n";
    std::cout << "Tutorial program for calculating the hydraulic head (steady state saturated groundwater flow) for different soil materials" << std::endl;
    
    //Parameters for grid and ansatzfunctions
    constexpr int dim 	= 2;
    int order 	= 1;
    int refinements = 6;
   
    //Output parameters
    int verbosity, PREPROVERBOSITY, POSTPROVERBOSITY, DEBUG;

    //Typedef
    using Grid     = Dune::UGGrid<dim>;
    using LeafView = Grid::LeafGridView;
    using H1Space  = FEFunctionSpace<ContinuousLagrangeMapper<double, LeafView>>;

    //Program options
    try{
        std::cout << "\n";
        po::options_description desc("Allowed options");
        desc.add_options()
        ("help", "produce help message")
        
        /*PRE-PROCESSING: GRID*/
        ("refinements",   po::value(&refinements)     ->default_value(7),     	"   : Uniform refinement at start")    
        
        /*PRE-PROCESSING: Simulation Parameters*/
        ("order",      po::value(&order)         ->default_value(2),"   : Element order for h")
         
        /* Output */
        ("verbosity"     , po::value(&verbosity)->default_value(1),                "   : Verbosity overall")
        ("PREPROVERBOSITY"     , po::value(&PREPROVERBOSITY)->default_value(1),    "   : Verbosity in Preprocessing")
        ("POSTPROVERBOSITY"     , po::value(&POSTPROVERBOSITY)->default_value(1),  "   : Verbosity in Postprocessing");
        ("DEBUG"     , po::value(&DEBUG)->default_value(1),                "   : Debugmode");       
        
        po::variables_map vm;        
        po::store(po::parse_command_line(argc, argv, desc), vm);
        po::notify(vm);    
        
        if (vm.count("help")) {
            std::cout << desc << "\n";
            return 1;
        }
        
    }     
    catch(std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    } 
    catch(...) {
        std::cerr << "Exception of unknown type!\n";
    }
    

  
    /* ----------------- PREPROCESSING -----------------*/


    // Create grid via factory
    // vertex coordinates v[0], v[1]
    // Don't forget to adjust the boundary conditions if anything other then a unit grid is used !
    /*
     * (d)---------------(c)
     *  |------------------|
     *  |------------------|
     *  |------------------|
     *  |------------------|
     * (a)---------------(b)
     * 
     */
    
    Dune::GridFactory<Grid> factory;
    Dune::FieldVector<double, dim> v;
    v[0] = 0;  v[1] = 0;
    factory.insertVertex(v); //a(x,y)
    v[0] = 5;  v[1] = 0;
    factory.insertVertex(v); //b(x,y)
    v[0] = 5;  v[1] = 10;
    factory.insertVertex(v); //c(x,y)
    v[0] = 0;  v[1] = 10;
    factory.insertVertex(v); //d(x,y)
    
    // triangle defined by 3 vertex indices
    std::vector<unsigned int> vid(3);
    Dune::GeometryType gt(Dune::GeometryType::simplex, 2);
    vid[0] = 0;  vid[1] = 1;  vid[2] = 2;
    factory.insertElement(gt, vid);
    vid[0] = 0;  vid[1] = 2;  vid[2] = 3;
    factory.insertElement(gt, vid);
    // a gridmanager is constructed
    // as connector between geometric and algebraic information
    GridManager<Grid> gridManager(factory.createGrid());
    gridManager.enforceConcurrentReads(true);
    gridManager.globalRefine(refinements);

    // Some information on the refined mesh
    if(PREPROVERBOSITY){
        std::cout << "Grid infos-------------------" << "\n"; 
        std::cout << "Grid: " << gridManager.grid().size(0) << " triangles, " << std::endl;
        std::cout << "      " << gridManager.grid().size(1) << " edges, " << std::endl;
        std::cout << "      " << gridManager.grid().size(2) << " points" << std::endl;
        std::cout << "-----------------------------" << "\n"; 
        std::cout << "\n"; 
    }
    
    // Construct involved spaces and variable descriptions.
    H1Space hSpace(gridManager, gridManager.grid().leafGridView(), order);
    
    if(PREPROVERBOSITY){
        std::cout << "Space infos------------------" << "\n"; 
        std::cout << "hSpace, DOF: " << hSpace.degreesOfFreedom() << std::endl;
        std::cout << "hSpace, Grid dimension: " << hSpace.dim << std::endl;
        std::cout << "\n";
    }
    
    // Creates a variable set description from given spaces and variables.
    auto varSetDesc = makeVariableSetDescription(makeSpaceList(&hSpace),
                                                 boost::fusion::make_vector(Variable<SpaceIndex<0>, Components<1>>("h")));
    using VarSetDesc = decltype(varSetDesc);
    
    //Material space
    std::cout << "Create material space" << std::endl;
    std::cout << "\n";    
    
    /*

        To set different hydraulic conductivities the following approch is used. 

        A discontinious space of constant Lagrange polynomial is created where the desired material data is interpolated on.

        The interpolation takes place in "interpolateGloballyWeak" using a struct to define the functor, where of course a lambda-function can be used.

        All the "materialdata()" function is doing is walking over every cell and set the desired permittivity.

     */
    
    using  P0Space = FEFunctionSpace<DiscontinuousLagrangeMapper<double,Grid::LeafGridView> >;
    P0Space p0Space(gridManager,gridManager.grid().leafGridView(), 0);

    auto matVarSetDesc = makeVariableSetDescription(makeSpaceList(&p0Space),
                                                    boost::fusion::make_vector(Variable<SpaceIndex<0>, Components<2>>("mat")));
    auto mat = matVarSetDesc.variableSet();
    mat = 0;
    using MatVarSetDesc = decltype(mat);

    interpolateGloballyWeak<Volume>(boost::fusion::at_c<0>(mat.data), materialdata());

    writeVTK(mat,"material",IoOptions().setPrecision(7));
    
    //Create Functional, plot some simulation data if desired and apply the variables and the material
    using Functional = GFFunctional<double, VarSetDesc, MatVarSetDesc>;
    Functional F(mat); 
    
    //Create Assembler + Galerkin repr.
    using CoefficientVectors = VarSetDesc::CoefficientVectorRepresentation<>::type;
    typedef VariationalFunctionalAssembler<LinearizationAt<Functional>> Assembler;
    Assembler assembler(varSetDesc.spaces);
    
    //Create solution parameters
    constexpr int neq = Functional::TestVars::noOfVariables;
    constexpr int nvars = Functional::AnsatzVars::noOfVariables;
    auto h = varSetDesc.variableSet();

    size_t nnz = assembler.nnz(0, /*3*/neq, 0, /*3*/nvars, false);
    size_t dof = varSetDesc.degreesOfFreedom(0, /*3*/2);
    
    if(PREPROVERBOSITY){
        std::cout << "DOF infos--------------------" << "\n"; 
        std::cout << "Overall degrees of freedom: "      << dof << std::endl;
        std::cout << "(Structurally) nonzero elements: " << nnz << std::endl;
        std::cout << std::endl << "no of variables = " << nvars << std::endl;
        std::cout << "no of equations = " << neq   << std::endl;
        std::cout << "-----------------------------" << "\n"; 
        std::cout << "\n";
    }
    
    //Set initial values
    h = 0;
    writeVTKFile(h, "init");

    // Solve   
    std::cout << "\n"; 
    std::cout << "Solving, starting Newton iteration" << std::endl;  
    std::cout << "\n"; 
             
    assembler.assemble(LinearizationAt<Functional>(F, h) , Assembler::EVERYTHING , 4 , false);
    CoefficientVectors rhs(assembler.rhs());  
    auto sol = varSetDesc.zeroCoefficientVector();
    directInverseOperator(AssembledGalerkinOperator<Assembler>(assembler),DirectType::UMFPACK).applyscaleadd(-1.0, rhs, sol);
    
    h.data = sol.data;
    writeVTK(h,"h",IoOptions().setOrder(order).setPrecision(7));
     
    //Calculating hydraulic gradient (darcy slope)
    /*

        Since the darcy lsope calculated via H = -grad(h) all that has to be done is to "walk" over every cell and calculate the gradient of h. 

        This is again done with interpolateGlobally using the continuous Lagrange Space

     
*/
    
     auto fieldvarSetDesc = makeVariableSetDescription(makeSpaceList(&hSpace),
                                                     boost::fusion::make_vector(Variable<SpaceIndex<0>,Components<2>>("gradh"))); 
     auto gradh = fieldvarSetDesc.variableSet();
	 gradh = 0;
     
	 interpolateGlobally<PlainAverage>(component<0>(gradh),

                                       makeFunctionView(component<0>(h).space(), [&] (auto const& evaluator)
    {
          auto dh = component<0>(h).derivative(evaluator);

          Dune::FieldVector<double,2> ret(0);
          ret[0] = dh[0][0];
          ret[1] = dh[0][1];

          return ret;
        }));

        writeVTKFile(gridManager.grid().leafGridView(), gradh, "gradh");
            
    return 0;
}
