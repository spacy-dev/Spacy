/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*                                                                           */

/*  This file is part of the library KASKADE 7                               */

/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */

/*                                                                           */

/*  Copyright (C) 2002-2015 Zuse Institute Berlin                            */

/*                                                                           */

/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */

/*    see $KASKADE/academic.txt                                              */

/*                                                                           */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



#ifndef CDR_HH
# define CDR_HH

# include <algorithm>
# include <type_traits>
# include <iostream>
# include <cmath> 

# include "fem/diffops/materialLaws.hh"
# include "fem/functional_aux.hh"
# include "fem/fixdune.hh"
# include "fem/variables.hh"

# include <dune/common/fvector.hh>
# include <dune/common/fmatrix.hh>

template <class RType, class VarSet>
class CDRFunctional : public Kaskade::FunctionalBase<Kaskade::WeakFormulation>
{

    

public:
    using Scalar = RType;
    using OriginVars = VarSet;
    using AnsatzVars = VarSet;
    using TestVars = VarSet;

    using Self = CDRFunctional<RType,VarSet>;
    using Cell = typename AnsatzVars::Grid::template Codim<0>::Entity;
    using Position = Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension>;	
    
    static constexpr int dim = AnsatzVars::Grid::dimension;   //Achtung , ist 2 !!
    static constexpr int cIdx = 0;
    static constexpr int cSpaceIdx = Kaskade::spaceIndex<AnsatzVars, cIdx>;

    // convenient template aliases

    template <int row>
    static constexpr int testComponents = TestVars::template components<row>;

    template <int row>
    static constexpr int ansatzComponents = AnsatzVars::template components<row>;
    /// \class DomainCache
    ///
    class DomainCache : public Kaskade::CacheBase<CDRFunctional, DomainCache>
    {
        
    public:

        DomainCache(CDRFunctional const &F,
                    typename AnsatzVars::VariableSet const &vars_, int flags = 7) : vars(vars_)  
        {
            //Debug
            D = F.getD();
            alpha = F.getalpha();
            x0=F.getx0();
            y0=F.gety0();
            q0=F.getq0();
            sigma=F.getsigma();
            v[0][0] = F.getvx();
            v[0][1] = F.getvy();  
            refinements = F.getrefinements();
            tau = 0.0 ; 
            StabilizationScheme = F.getstab();
            
            if(refinements == 5)
            {
                h_zeta = 1.0/32.0* 10;
                h_eta = 1.0/32.0* 10;
            }
            else if(refinements == 6)
            {
                h_zeta = 1.0/64.0* 10;
                h_eta = 1.0/64.0* 10;
            }
            else if(refinements == 7)
            {
                h_zeta = 1.0/128.0* 10;
                h_eta = 1.0/128.0* 10;
            }      
            else if(refinements == 8)
            {
                h_zeta = 1.0/256.0* 10;
                h_eta = 1.0/256.0* 10;
            }  
            else if(refinements == 9)
            {
                h_zeta = 1.0/512.0 * 10;
                h_eta = 1.0/512.0 * 10;
            }  
            else if(refinements == 10)
            {
                h_zeta = 1.0/1024.0* 10;
                h_eta = 1.0/1024.0* 10;
            }    
            
        }  

        void moveTo(Cell const &entity) { e = &entity; }       
        
        
        template <class Position, class Evaluators>
        void evaluateAt(Position const &x, Evaluators const &evaluators)
        {
            using namespace boost::fusion;
            Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension> xglob = e->geometry().global(x);
        
            //Concentration and gradient an quadrature poi
            c = at_c<cIdx>(vars.data).value(at_c<cSpaceIdx>(evaluators));
            dc = at_c<cIdx>(vars.data).derivative(at_c<cSpaceIdx>(evaluators));
            ddc = at_c<cIdx>(vars.data).hessian(at_c<cSpaceIdx>(evaluators));                 
           
            // Right-hand side
            Scalar normdiff = std::pow((xglob[0]-x0),2) + std::pow((xglob[1]-y0),2);
            q = q0*std::exp(- 0.5 * normdiff / std::pow(sigma,2));
            
            /*
            v[0][0] = -xglob[1];
            v[0][1] = xglob[0];
            
            //Scaled
            v[0][0] *= 0.05;
            v[0][1] *= 0.05;*/
            
            if(v[0][0] == 0 || v[0][1] == 0 ) //Praktisch ein 1D Problem
            {
            
                if(v[0][0] == 0)
                {
                    
                auto a = v[0][1];
                auto Pe = a*h_zeta / (2*D);
                auto beta = 1 / tanh(Pe) - 1/Pe;
                auto mutilde = 0.5* (h_zeta * a * beta);
            
                tau = mutilde / (std::pow(v[0][1],2));

                }
                
                else{
                
                auto a = v[0][0];
                auto Pe = a*h_eta / (2*D);
                auto beta = 1 / tanh(Pe) - 1/Pe;
                auto mutilde = 0.5* (h_eta * a * beta);
            
                tau = mutilde / (std::pow(v[0][0],2));

                }
            }
            
            
            else{
            
            auto a_zeta = v[0][0];
            auto a_eta = v[0][1];
                                
            auto Pe_zeta = (a_zeta*h_zeta)/(2*D) ;
            auto Pe_eta = (a_eta*h_eta)/(2*D) ;
            
            auto zeta = 1/tanh(Pe_zeta) - 1 / Pe_zeta;
            auto eta  = 1/tanh(Pe_eta)  - 1 / Pe_eta;
            
            auto mutilde = 0.5* (zeta*a_zeta*h_zeta + eta*a_eta*h_eta);
            
            tau = mutilde / (std::pow(v[0][0],2)+std::pow(v[0][1],2));

                
            }
            
            
            
        }               
        
        Scalar d0() const
        {
            return 0.0;
        }

        template <int row>
        Scalar d1_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg) const
        {
            Dune::FieldMatrix<Scalar,1,dim> dw(0);  //2x1
            Dune::FieldVector<Scalar,1> w(0);
            dw = arg.derivative;
            w = arg.value;
            auto ddw = arg.hessian;
            
            //Matrix to vec                        
            Dune::FieldVector<Scalar,2>dcvec(0);
            Dune::FieldVector<Scalar,2>dwvec(0);
            Dune::FieldVector<Scalar,2>vvec(0);
            dcvec[0] = dc[0][0]; dcvec[1] = dc[0][1];
            dwvec[0] = dw[0][0]; dwvec[1] = dw[0][1];
            vvec[0] = v[0][0]; vvec[1] = v[0][1];
             
            auto PW = 0;           
            if(StabilizationScheme == "GLS")
            {//GLS - Stabilization 
            PW = -vvec*dwvec + D*(ddw[0][0][0]+ddw[1][0][1]) + alpha * w;
            }
            
            else if(StabilizationScheme == "SUPG"){
            //SUPG - Stabilization 
            PW = vvec*dwvec;
            }
            
            auto RC = -vvec*dcvec + D*(ddc[0][0][0]+ddc[1][0][1]) + alpha * c - q;
            auto stabfactor = PW*tau*RC;
            
            return D * dcvec*dwvec +  v * dcvec * w - alpha* c * w - q * w + stabfactor;
        }

        template <int row, int col>
        Scalar d2_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg1,
                       Kaskade::VariationalArg<Scalar, dim, ansatzComponents<col>> const &arg2) const
        {
            Dune::FieldMatrix<Scalar,1,dim> dw(0);  //2x1
            Dune::FieldVector<Scalar,1> w(0);
        
            Dune::FieldMatrix<Scalar,1,dim> dzeta(0);  //2x1
            Dune::FieldVector<Scalar,1> zeta(0);
            
            dw = arg1.derivative;
            w = arg1.value;
            auto ddw = arg1.hessian;
            
            dzeta = arg2.derivative;
            zeta = arg2.value;
            auto ddzeta = arg2.hessian;
            
            //Matrix to vec   
            Dune::FieldVector<Scalar,2>dwvec(0);
            Dune::FieldVector<Scalar,2>dzetavec(0);                        
            Dune::FieldVector<Scalar,2>vvec(0);
            dzetavec[0] = dzeta[0][0]; dzetavec[1] = dzeta[0][1];
            dwvec[0] = dw[0][0]; dwvec[1] = dw[0][1];
            vvec[0] = v[0][0]; vvec[1] = v[0][1];
            
            auto PW = 0; 
            if(StabilizationScheme == "GLS")
            {//GLS - Stabilization 
            PW = vvec*dwvec + D*(ddw[0][0][0]+ddw[1][0][1]) + alpha * arg1.value;        
            }
            
            else if(StabilizationScheme == "SUPG")
            {
            //SUPG - Stabilization 
            PW = vvec*dwvec;
            }
                        
            auto RC = -vvec*dzetavec + D*(ddzeta[0][0][0]+ddzeta[1][0][1]) + alpha* arg2.value;
            auto stabfactor = PW*tau*RC;
            
            return D * dzetavec*dwvec + vvec * dzetavec * w - alpha* zeta * w + stabfactor; 
        }

    private:

        typename AnsatzVars::VariableSet const &vars;
        Cell const* e;

        Scalar q, q0, alpha, D, sigma, x0, y0,h_zeta,h_eta , tau;
        int refinements;

        Dune::FieldVector<Scalar,ansatzComponents<cIdx>> c;
        Dune::FieldMatrix<Scalar,1,dim> dc;
        Kaskade::Tensor<Scalar,1,2,2> ddc;
        Dune::FieldMatrix<Scalar,1,dim> v; 
        
        std::string StabilizationScheme;

    };

    class BoundaryCache : public Kaskade::CacheBase<CDRFunctional, BoundaryCache>
    {

    using FaceIterator = typename AnsatzVars::Grid::LeafIntersectionIterator;

    public:  

        BoundaryCache(CDRFunctional<RType, AnsatzVars> const &F,
                      typename AnsatzVars::VariableSet const &vars_,
                      int flags = 7) : vars(vars_), face(nullptr), penalty(1e20), c0(0)
                      {
                        D = F.getD();
                      }

                      
        void moveTo(FaceIterator const &face_) { 
            face = &face_ ;
            
            
            //Inhomogene Neumann-RB
            Dune::FieldVector<Scalar,2> up(0); up[0] = 1; // unit upwards pointing vector
            auto n = face_->centerUnitOuterNormal();       // unit outer normal
                       
            if(n * up > 0.5)  // right side 
            {
                penalty = 0.0;
                drain = 1/*1E-4*/;
            }
            
            
        }
        
        template <class Evaluators>
        void evaluateAt(Dune::FieldVector<typename AnsatzVars::Grid::ctype, dim - 1> const &x, Evaluators const &evaluators)
        {
            using namespace boost::fusion;
            
            Dune::FieldVector<Scalar, dim> xglob = (*face)->geometry().global(x);
           c = at_c<cIdx>(vars.data).value(at_c<cSpaceIdx>(evaluators));
           
            if(xglob[0] <= 0.0001)
            {
                penalty = 1e20;
                c0[0] = 0;
            }

            else if(xglob[1]<= 0.0001)
            {
                penalty = 1e20;
                c0[0] = 0;
            }
        
            else if(xglob[1]>= 9.9999)
            {
                penalty = 1e20;
                c0[0] = 0;
            }  
            else{
                penalty = 0;
            }
        }
        Scalar d0() const
        {
            return 0.5 * penalty * (c - c0) * (c - c0) ;
        }
                      
        template <int row>
        Scalar d1_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg) const
        {
  
                return penalty * (c - c0) * arg.value /*inhom. Neumann RB */+ D*arg.value*drain;

        }
        template <int row, int col>
        Scalar d2_impl(Kaskade::VariationalArg<Scalar, dim, testComponents<row>> const &arg1,
                       Kaskade::VariationalArg<Scalar, dim, ansatzComponents<col>> const &arg2) const
        {

          return penalty * arg1.value * arg2.value /*inhom. Nuemann RB*/+ D*arg1.value*arg2.derivative[0];

        }                                                  

    private:

        typename AnsatzVars::VariableSet const &vars;
        FaceIterator const *face;

        Scalar penalty, drain, D;

        Dune::FieldVector<Scalar, 1> c;                   //2x1
        Dune::FieldVector<Scalar, 1> c0;                  //2x1
    };

public:

    CDRFunctional(Scalar D, Scalar alpha, Scalar vx, Scalar vy, Scalar x0, Scalar y0, Scalar q0,Scalar sigma,int refinements, std::string StabScheme = "SUPG" , int verbose =1 ): 
    diffcoeff_(D),
    alpha_(alpha),
    vx_(vx),
    vy_(vy),
    x0_(x0),
    y0_(y0),
    q0_(q0),
    sigma_(sigma),
    refinements_(refinements),
    StabScheme_(StabScheme),
    verbose_(verbose)
    {
        tau_ = 0.0;
    }
    
    template <int row>
    struct D1 : public Kaskade::FunctionalBase<Kaskade::VariationalFunctional>::D1<row>
    {
        static bool const present = true;
        static constexpr int derivatives = 1;
    };

    

    template <int row, int col>
    struct D2 : public Kaskade::FunctionalBase<Kaskade::VariationalFunctional>::D2<row, col>
    {
        static constexpr int derivatives = 1;
        static bool const present = true;
    };
    
    Scalar getD() const {return diffcoeff_;};
    Scalar getalpha() const {return alpha_;};
    Scalar getvx() const {return vx_;};
    Scalar getvy() const {return vy_;};
    Scalar getsigma() const {return sigma_;};
    Scalar getq0() const {return q0_;};
    Scalar getx0() const {return x0_;};
    Scalar gety0() const {return y0_;} ;
    Scalar getrefinements() const {return refinements_;} ;
    Scalar gettau() const {return tau_;} ;
    std::string getstab() const {return StabScheme_;} ;
    
    template <class Cell>
    int integrationOrder(Cell const & /* cell */, int shapeFunctionOrder, bool boundary) const
    {

        if (boundary)
            return 2 * shapeFunctionOrder;                        // mass term u*u on boundary
        else
            return 2 * (shapeFunctionOrder - 1);                  // energy term "u_x * u_x" in interior

    }

    

private:
    Scalar diffcoeff_, alpha_, vx_, vy_, sigma_, q0_, x0_, y0_, tau_;
    int verbose_,refinements_;
    std::string StabScheme_;
};

#endif
