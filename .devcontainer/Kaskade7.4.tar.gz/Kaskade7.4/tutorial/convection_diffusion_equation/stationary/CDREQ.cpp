/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2018 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <fstream>

#include "dune/grid/config.h"  

#include "dune/grid/uggrid.hh"
#include "utilities/gridGeneration.hh"

#include "fem/assemble.hh"
#include "fem/istlinterface.hh"
#include "fem/functional_aux.hh"
#include "fem/gridmanager.hh"
#include "fem/lagrangespace.hh"
#include "fem/variables.hh"
#include "fem/norms.hh"
#include "fem/diffops/elastoVariationalFunctionals.hh"

#include "utilities/enums.hh"

#include "io/vtk.hh"
#include "io/matlab.hh"

#include "linalg/direct.hh"
#include "linalg/umfpack_solve.hh"

#include <boost/program_options.hpp>
#include "utilities/timing.hh"

#include "ConsoleTable.hh"

#include "CDREQ.hh"

namespace po = boost::program_options;
using namespace Kaskade;

//------------------------------------------------------------------------------------------------------------------------------------
// Anfangswerte
struct InitialValue
{
    using Scalar = double;
    static int const components = 1;
    using ValueType = Dune::FieldVector<Scalar,components>;
    
    InitialValue(){}
    InitialValue(Scalar x0, Scalar y0 , Scalar q0, Scalar sigma): m_q0(q0), m_sigma(sigma)
    {
        xstart = {x0,y0};
    }
    
    template <class Cell> int order(Cell const&) const { return std::numeric_limits<int>::max(); }
    template <class Cell>
    ValueType value(Cell const& cell, Dune::FieldVector<typename Cell::Geometry::ctype,Cell::dimension> const& localCoordinate) const 
    {
        Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> x = cell.geometry().global(localCoordinate);
        
        Scalar normdiff = std::pow((x[0]-xstart[0]),2)+std::pow((x[1]-xstart[1]),2);
        
        return  m_q0*std::exp(-normdiff/(2*std::pow(m_sigma,2)));
    }
    
private:
    std::vector<Scalar> xstart;
    Scalar m_q0, m_sigma;
};
//------------------------------------------------------------------------------------------------------------------------------------

double geth(int refinementlevel){
    
            if(refinementlevel == 5)
            {
                return 1.0/32.0* 10;
            
            }
            else if(refinementlevel == 6)
            {
                return  1.0/64.0* 10;
               
            }
            else if(refinementlevel == 7)
            {
                return 1.0/128.0* 10;
               
            }      
            else if(refinementlevel == 8)
            {
                return  1.0/256.0* 10;
                
            }  
            else if(refinementlevel == 9)
            {
                return  1.0/512.0 * 10;
               
            }  
            else if(refinementlevel == 10)
            {
                return  1.0/1024.0* 10;
              
            }  
}

int main(int argc, char **argv)
{
    
    /**
    TUTORIAL PROGRAM FOR CALCULATING THE STATIONARY CONVECTION DIFFUSION REACTION EQUATION
    
    The stationary convection diffusion reaction (CDR) equation is given by:
    
    div(D gracd c) - div(v * c) + R = Q
    
    with     
    
    D:   RxRxR x RxRxR - Diffusivity tensor
    c:   RxRxR -> R - variable of interest , concentration or heat transfer
    v:   RxRxR -> RxRxR - velocity field_type
    R:   RxRxR -> R : Reaction term
    Q:   RxRxR -> R : Source or sinks

    This tutorial considers a two dimensional case where a source in the form a gaussian curve is set in the middle of the domain.
    A practical example could be a leaking barrell inside of a river, where the concenctration of the leakage is distributed by convection and diffusion in the water.
    
    The following weak formulation has to be solved
    
    D * dcvec*dwvec +  v * dcvec * w - alpha* c * w - q * w + stabfactor;
    
    Find c in H1(Omega) such that
    
    D int_Omega grad(c)*grad(w) + int_Omega v * grad(v)*w - R*w - Q*w  = 0 for all w in H1
    
    Dirichlet boundaries : c = 0 on the left, top und bottom
    Neumann boundaries : g = 1 on the right 
    
    where v is assumed to be constant.
    
    To stabilize the system SUPG oder GLS - Methods are used, such that da Stabilizationfactor P(w)*tau*L(c) has to be added, where P(w) depends on the Stabilization schema , see e.g. "Finite Element Methods for Flow Problems, Jean Donea, Antonio Huerta"
    
    */    
    
    
    
    using namespace boost::fusion;
    auto &timer = Timings::instance();
    
    std::cout << "\n";
    std::cout << "Stationary Convection-Diffusion-Reaction-Equation on a 2D grid" << std::endl;
    
    //Parameters for grid and ansatzfunctions
    constexpr int dim 	= 2;
    int ansatzorder 	= 1,
    refinements 		= 6;
    
    //Simulation parameters
    double D, alpha, vx, vy;
    double x0,y0,q0,sigma;    
    
    double newtonTol, regularization;
    int maxit;
    
    //Typedefs
    using Grid     = Dune::UGGrid<dim>;
    using LeafView = Grid::LeafGridView;
    using H1Space  = FEFunctionSpace<ContinuousLagrangeMapper<double, LeafView>>;
  
    std::string scheme;
    
    //Program options
    try{
        std::cout << "\n";
        po::options_description desc("Allowed options");
        desc.add_options()
        ("help", "produce help message")
        ("refinements",   po::value(&refinements)     ->default_value(8),     	"   : Uniform refinement at start")
        ("ansatzorder",      po::value(&ansatzorder)         ->default_value(1),"   : Element order for c")
        ("scheme",      po::value(&scheme)         ->default_value("SUPG"),"   : Stabilization scheme")
        
        ("D",       po::value(&D) ->default_value(0.25),"   : Diffusion coefficient")
        ("alpha",   po::value(&alpha) ->default_value(0.1),"   : Alpha")
        ("vx",      po::value(&vx) ->default_value(1),"   : Vectorfield component vx")
        ("vy",      po::value(&vy) ->default_value(0),"   : Vectorfield component vy") 
        
        ("x0",      po::value(&x0) ->default_value(5),"   : x0")
        ("y0",      po::value(&y0) ->default_value(5),"   : y0")
        ("q0",      po::value(&q0) ->default_value(1),"   : q0")
        ("sigma",   po::value(&sigma) ->default_value(1),"   : sigma") 
        
        ("newtonTol",     po::value(&newtonTol)       ->default_value(1e-8),  	"   : Stopping tolerance for Newton")
        ("maxit",         po::value(&maxit)       ->default_value(500),  		"   : Maximum iterations for iterative solver")
        ("regularization",  po::value(&regularization) ->default_value(1e-2),   "   : Regularization: add multiple of identity to assembled matrix");

        
        po::variables_map vm;        
        po::store(po::parse_command_line(argc, argv, desc), vm);
        po::notify(vm);    
        
        if (vm.count("help")) {
            std::cout << desc << "\n";
            return 1;
        }
        
        ConsoleTable ct(vm,desc);
        ct.writeToTex("booktab",true);
        std::cout << ct;
    } 
    
    catch(std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    } 
    catch(...) {
        std::cerr << "Exception of unknown type!\n";
    }
    
    // Create grid via factory
    // vertex coordinates v[0], v[1]
    // Don't forget to adjust the boundary conditions if anything other then a unit grid is used !
    /*
     * (d)---------------(c)
     *  |------------------|
     *  |------------------|
     *  |------------------|
     *  |------------------|
     * (a)---------------(b)
     * 
     */
    
    Dune::GridFactory<Grid> factory;
    Dune::FieldVector<double, dim> v;
    timer.start("Grid generation");
    v[0] = 0;  v[1] = 0;
    factory.insertVertex(v); //a(x,y)
    v[0] = 10;  v[1] = 0;
    factory.insertVertex(v); //b(x,y)
    v[0] = 10;  v[1] = 10;
    factory.insertVertex(v); //c(x,y)
    v[0] = 0;  v[1] = 10;
    factory.insertVertex(v); //d(x,y)
    
    // triangle defined by 3 vertex indices
    std::vector<unsigned int> vid(3);
    Dune::GeometryType gt(Dune::GeometryType::simplex, 2);
    vid[0] = 0;  vid[1] = 1;  vid[2] = 2;
    factory.insertElement(gt, vid);
    vid[0] = 0;  vid[1] = 2;  vid[2] = 3;
    factory.insertElement(gt, vid);
    // a gridmanager is constructed
    // as connector between geometric and algebraic information
    GridManager<Grid> gridManager(factory.createGrid());
    gridManager.enforceConcurrentReads(true);
    gridManager.globalRefine(refinements);
    timer.stop("Grid generation");
    
    //Data log
    std::string logfilename = "ansatzorder-"+std::to_string(ansatzorder)+"-refinements-"+std::to_string(refinements)+"-scheme-"+scheme+ ".log";
    std::cout << "statistics output to logfile " << logfilename << "\n";
    std::ofstream logfile(logfilename);
    logfile << "# iteration \t correctionNorm \n";
    
    // Construct involved spaces and variable descriptions.
    H1Space cSpace(gridManager, gridManager.grid().leafGridView(), ansatzorder);
    
    // Creates a variable set descrpition from given spaces and variables. Dim-1 because (c) in R x R -> R
    auto varSetDesc = makeVariableSetDescription(makeSpaceList(&cSpace),
                                                 boost::fusion::make_vector(Variable<SpaceIndex<0>, Components<dim-1>>("c")));

    using VarSetDesc = decltype(varSetDesc);
    using Functional = CDRFunctional<double, VarSetDesc>;
    
    //Debug convenience 
    constexpr int nvars = Functional::AnsatzVars::noOfVariables;
    constexpr int neq   = Functional::TestVars::noOfVariables;

    // Create Functional
    // Stabilization "SUPG" or "GLS" , where SUPG is standard
    Functional F(D, alpha, vx, vy, x0, y0, q0, sigma,refinements,scheme); 
    
    //Create Assembler + Galerkin repr.
    using CoefficientVectors = VarSetDesc::CoefficientVectorRepresentation<>::type;
    typedef VariationalFunctionalAssembler<LinearizationAt<Functional>> Assembler;
    Assembler assembler(varSetDesc.spaces);
    
    //Create solution parameters
    auto x = varSetDesc.variableSet();
    auto dx = varSetDesc.variableSet();
    size_t nnz = assembler.nnz(0, 2, 0, 2, false);
    size_t dof = varSetDesc.degreesOfFreedom(0, 2);    

    //GRIDTABLE
    ConsoleTable grdspaceTable={"Data","Value"};
    grdspaceTable += {"No. of triangles",std::to_string(gridManager.grid().size(0))};
    grdspaceTable += {"No. of edges",std::to_string(gridManager.grid().size(1))};
    grdspaceTable += {"No. of points",std::to_string(gridManager.grid().size(2))};
    grdspaceTable += {"DoF of space",std::to_string(cSpace.degreesOfFreedom())};
    grdspaceTable += {"Grid dimension of space",std::to_string(cSpace.dim)};
    grdspaceTable += {"AnsatzVars::noOfVariables",std::to_string(nvars)};
    grdspaceTable += {"TestVars::noOfVariables",std::to_string(neq)};    
    grdspaceTable += {"Overall degrees of freedom",std::to_string(dof)};
    grdspaceTable += {"(Structurally) nonzero elements",std::to_string(nnz)};
    std::cout << grdspaceTable;
    std::cout << "\n";
    grdspaceTable.writeToTex("grdspaceTable");
    
    //Set initial values
    x = 0;
    interpolateGloballyWeak<Volume>(boost::fusion::at_c<0>(x.data) ,InitialValue(x0, y0, q0, sigma)); //Initials for c
    writeVTKFile(x, "Initial_configuration_"+std::to_string(refinements));
    
    auto Pe = (std::sqrt( std::pow(vx,2) + std::pow(vy,2) ) * geth(refinements)) / (2*D);
    std::cout << "Peclet-No.: " << Pe << std::endl;
    std::cout << "\n";
    
    //Solve
    L2Norm l2Norm;
    double updatednorm = 0;
    
    //Variables for regularization
    using Matrix = Dune::BCRSMatrix<Dune::FieldMatrix<double,1,1> >;
    using Vector = Dune::BlockVector<Dune::FieldVector<double,1>>;
    Matrix hessian, initialHessian;
    
    std::cout << "------Solver parameters------" << "\n";  
    std::cout << "Newton tolerance: " << newtonTol << std::endl;
    std::cout << "Max Iteration: " << maxit << std::endl;
    std::cout << "-----------------------------" << "\n"; 
    
    std::cout << "\n"; 
    std::cout << "Solve...." << std::endl;  
    
    ConsoleTable newtontable = {"Iteration","L2Norm ||dx||"};
    
    for (unsigned int j = 0; j < maxit ; ++j)
    {
        timer.start("Assembly");
        assembler.assemble(LinearizationAt<Functional>(F, x) , Assembler::EVERYTHING , 4 , false);
        timer.stop("Assembly");
              
        CoefficientVectors rhs(assembler.rhs());
        auto sol = varSetDesc.zeroCoefficientVector();
        
        /* REGULARIZATION */
        std::cout << "------ Regularization v-Block------";
        std::cout << "\n";  
        std::cout << " Transform to unitMatrix...";
        std::cout << "\n";
        
        initialHessian = assembler.get<Matrix>();
        //transform to unitMatrix
        initialHessian = 0.0;
        
        for(size_t row=0; row <varSetDesc.degreesOfFreedom(0, 2); ++row)
        {  
            initialHessian[row][row] = 1.0;
        }
        
        initialHessian *= regularization;
        std::cout << " Transform to unitMatrix...done";
        std::cout << "\n";
        
        std::cout << " Regularize...";
        std::cout << "\n";

        hessian = assembler.get<Matrix>();
        hessian += initialHessian; // regularization

        std::cout << " Regularize...done";
        std::cout << "\n";
        std::cout << "...solve...\n";

        Vector rhsVec(dof), solVec(dof); 
        assembler.toSequence(0,2, rhsVec.begin());

        timer.start("Direct solver");       
        directInverseOperator(MatrixRepresentedOperator<Matrix,Vector,Vector>(hessian)).apply(rhsVec,solVec);
        vectorFromSequence(sol, solVec.begin());
        timer.stop("Direct solver");
        
        dx.data = sol.data;
        updatednorm = std::sqrt(l2Norm.square(boost::fusion::at_c<0>(dx.data)));     
               
        newtontable+= {std::to_string(j),std::to_string(updatednorm)};
        
        std::cout << newtontable;
        // newtontable.flush()  - if it is not desired to plot every step in the table
        
        logfile << j << "\t";
        logfile << std::setprecision(12) << std::setw(17) << updatednorm << "\t" << "\n";
        
        if (updatednorm < newtonTol)
        {         
            std::cout << "Sufficient accuracy is reached, solution converged, write data to output" << std::endl;
            
            std::string output = "ansatzorder-"+std::to_string(ansatzorder)+"-refinements-"+std::to_string(refinements)+"-scheme-"+scheme+"-iteration-" + std::to_string(j);
            writeVTKFile(x, output, IoOptions().setOrder(ansatzorder).setOutputType(IoOptions::binary));
            
            logfile.close();
            
            std::cout << "Graphical output finished, data in VTK format is written into file " << output << "\n";
            std::cout << "\n";
            
            return 0;           
        }
        
        std::string output = "ansatzorder-"+std::to_string(ansatzorder)+"-refinements-"+std::to_string(refinements)+"-scheme-"+scheme+"-iteration-" + std::to_string(j);
        
        writeVTKFile(x, output, IoOptions().setOrder(ansatzorder).setOutputType(IoOptions::binary));
        
        x -= dx;
        
        std::cout << "Graphical output finished, data in VTK format is written into file " << output << "\n";
        std::cout << "\n";        
    }
    
    std::cout << "No solution was found in: "<<maxit << " iterations...."<< std::endl;
    std::cout << "\n";
    logfile.close();
    
    return 0;
}
