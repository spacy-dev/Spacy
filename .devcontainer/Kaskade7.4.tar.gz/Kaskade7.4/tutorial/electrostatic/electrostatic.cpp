/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2018 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>

#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"
#include "dune/grid/io/file/gmshreader.hh"


#include "fem/assemble.hh"
#include "fem/istlinterface.hh"
#include "fem/functional_aux.hh"
#include "fem/gridmanager.hh"
#include "fem/lagrangespace.hh"
#include "fem/variables.hh"

#include "io/vtk.hh"
#include "utilities/gridGeneration.hh" //  createUnitSquare

#include "linalg/direct.hh"
#include "linalg/umfpack_solve.hh"
#include "linalg/dynamicMatrix.hh"


using namespace Kaskade;
#include "electrostatic.hh"


struct materialdata
{
    using Scalar = double;
    static int const components = 1;
    using ValueType = Dune::FieldVector<Scalar,components>;
    
    materialdata(){}
    
    template <class Cell> int order(Cell const&) const { return std::numeric_limits<int>::max(); }
    
    /*
     * For UNIT GRID !!!
     * 
     * template <class Cell>
    ValueType value(Cell const& cell,
                    Dune::FieldVector<typename Cell::Geometry::ctype,Cell::dimension> const& localCoordinate) const 
                    {
                        
                         Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> x = cell.geometry().global(localCoordinate);
                         
                         if( x[0] >= 0.25 && x[0] <= 0.75 )
                         {
                             if( x[1] >= 0.25 && x[1] <= 0.75 )
                             {
                                 ValueType ret(10);
                                 return ret;
                            }
                         }
                         
                        ValueType ret(1.0);
                        return ret;
                    }*/ 
    
    /*
     * For capacitor
     * 
    template <class Cell>
    ValueType value(Cell const& cell,
                    Dune::FieldVector<typename Cell::Geometry::ctype,Cell::dimension> const& localCoordinate) const 
                    {
                        
                         Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> x = cell.geometry().global(localCoordinate);
                         
                         if( x[0] >= 0.255 && x[0] <= 0.745 )
                         {
                             if( x[1] >= 0.375 && x[1] <= 0.625 )
                             {
                                 ValueType ret(2.4);
                                 return ret;
                            }
                         }
                         
                        ValueType ret(1.0);
                        return ret;
                    }  */    
    
    template <class Cell>
    ValueType value(Cell const& cell,
                    Dune::FieldVector<typename Cell::Geometry::ctype,Cell::dimension> const& localCoordinate) const 
                    {
                        
                         Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> x = cell.geometry().global(localCoordinate);

                        ValueType ret(1.0);
                        return ret;
                    } 
private:
    float mat;
};



int main()
{

  /**
    TUTORIAL PROGRAM FOR CALCULATING THE ELECTROSTATIC POTENTIAL
    
    Form theory its known that the electrostatic potential can be calculated from the Gaussian law div E = -rho and since E is a conservative Field there exists a potential with 
    E = -grad Phi with, such that div(grad Phi) = -rho. Considering isotropic media other then air, the equation then becomes
    
    epsilon * div(grad Phi) = -rho . where epsilon is the permittivity of the material.
    
    E:   RxRxR -> RxRxR
    Phi: RxRxR -> R
    epsilon: RxRxR -> R

    This tutorial considers a two dimensional case where it will be shown how to set different material types e.g. permittivities and how to calculate the electric field from the scalar potential.
    
    The following weak formulation has to be solved
    
    Find phi in H1(Omega) such that
    
    epsilon * int_Omega grad(phi) * grad(w) dOmega = 0  for all w in H1
    
    with given potentials phi at the boundaries
   */    
    
    std::cout << "Tutorial program for calculating the electrostatic potential for different cases" << std::endl;

    constexpr int dim = 2; //Since  E: RxR -> RxR and Phi: RxR -> R
    int refinements = 6,
        order       = 2;

    using Grid = Dune::UGGrid<dim>;
    using LeafView = Grid::LeafGridView;
    using H1Space = FEFunctionSpace<ContinuousLagrangeMapper<double,LeafView>>;

    /* ----------------- PREPROCESSING -----------------*/
    // Create grid via factoryTHE
    // vertex coordinates v[0], v[1]
    // Don't forget to adjust the boundary conditions if anything other then a unit grid is used !
    /*
     * (d)---------------(c)
     *  |------------------|
     *  |------------------|
     *  |------------------|
     *  |------------------|
     * (a)---------------(b)
     * 
     */
    
    std::cout << "Create grid" << std::endl;
    std::cout << "\n";
    
    /* UNIT GRID
    Dune::GridFactory<Grid> factory;
    Dune::FieldVector<double, dim> v;
    v[0] = 0;  v[1] = 0;
    factory.insertVertex(v); //a(x,y)
    v[0] = 1;  v[1] = 0;
    factory.insertVertex(v); //b(x,y)
    v[0] = 1;  v[1] = 1;
    factory.insertVertex(v); //c(x,y)
    v[0] = 0;  v[1] = 1;interpolateGlobally
    factory.insertVertex(v); //d(x,y)
    
    // triangle defined by 3 vertex indices
    std::vector<unsigned int> vid(3);
    Dune::GeometryType gt(Dune::GeometryType::simplex, 2);
    vid[0] = 0;  vid[1] = 1;  vid[2] = 2;
    factory.insertElement(gt, vid);
    vid[0] = 0;  vid[1] = 2;  vid[2] = 3;
    factory.insertElement(gt, vid);
    // a gridmanager is constructed
    // as connector between geometric and algebraic information
    GridManager<Grid> gridManager(factory.createGrid());
    gridManager.enforceConcurrentReads(true);
    gridManager.globalRefine(refinements);*/

    //LOAD  GMSH - Mesh
    std::string mesh;
    mesh = "mesh/quadropol.msh";
    std::cout << "Mesh: " << mesh << "\n";
    std::unique_ptr<Grid> gridPtrAvatar(Dune::GmshReader<Grid>::read(mesh));
    GridManager<Grid> gridManager(std::move(gridPtrAvatar));
    gridManager.enforceConcurrentReads(true);
    // If the mesh is fine enough , no additional refine is neccessary
        
    // Some information on the refined mesh
    std::cout << std::endl
    << "Grid is read successfully" << std::endl;
    std::cout << "Grid: " << gridManager.grid().size(0) << " triangles, " << std::endl;
    std::cout << "      " << gridManager.grid().size(1) << " edges, " << std::endl;
    std::cout << "      " << gridManager.grid().size(2) << " points" << std::endl;
    std::cout << "\n";
    
    //Create space where phi and w are to find
    std::cout << "Create space" << std::endl;
    std::cout << "\n";  
    H1Space phiSpace(gridManager,gridManager.grid().leafGridView(),order);
  
    auto varSetDesc = makeVariableSetDescription(makeSpaceList(&phiSpace),
                                                 boost::fusion::make_vector(Variable<SpaceIndex<0>, Components<1>>("phi"))); // One component since phi is a scalar field
  
    using VarSetDesc = decltype(varSetDesc);

    std::cout << "Create functional" << std::endl;
    std::cout << "\n";  
  
    /*
        To set different permittivities the following approch is used. 
        A discontinious space of constant Lagrange polynomial is created where the desired material data is interpolated on.
        The interpolation takes place in "interpolateGloballyWeak" using a struct to define the functor, where of course a lambda-function can be used.
        All the "materialdata()" function is doing is walking over every cell and set the desired permittivity.
     */
    
    //Material space
    std::cout << "Create material space" << std::endl;
    std::cout << "\n";    
    using  P0Space = FEFunctionSpace<DiscontinuousLagrangeMapper<double,Grid::LeafGridView> >;
    P0Space p0Space(gridManager,gridManager.grid().leafGridView(), 0);
  
    auto matVarSetDesc = makeVariableSetDescription(makeSpaceList(&p0Space),
                                               boost::fusion::make_vector(Variable<SpaceIndex<0>, Components<1>>("mat")));
    auto mat = matVarSetDesc.variableSet();
    mat = 0;
    using MatVarSetDesc = decltype(mat);
  
    interpolateGloballyWeak<Volume>(boost::fusion::at_c<0>(mat.data), materialdata());
    writeVTK(mat,"material",IoOptions().setPrecision(7));
 
    //Create the functional and apply the variables and the material
    using Functional = ElectroStaticFunctional<double, VarSetDesc, MatVarSetDesc>;
    Functional F(mat);
  
    //Set solution vector and initial values 
    auto phi = varSetDesc.variableSet();
    phi = 0; //Inital values
    writeVTKFile(phi, "Initial_configuration");
    
    //Create Assembler + Galerkin repr.
    std::cout << "Create assembler" << std::endl;
    std::cout << "\n";
 
    using CoefficientVectors = VarSetDesc::CoefficientVectorRepresentation<>::type;
    typedef VariationalFunctionalAssembler<LinearizationAt<Functional>> Assembler;
    Assembler assembler(varSetDesc.spaces);
  
    std::cout << "...assemble" << std::endl;
    std::cout << "\n";
 
    //construct Galerkin representation
    assembler.assemble(LinearizationAt<Functional>(F, phi) , Assembler::EVERYTHING , 4 , true);

    std::cout << "...create rhs" << std::endl;
    std::cout << "\n";
 
    CoefficientVectors rhs(assembler.rhs());      
    auto sol = varSetDesc.zeroCoefficientVector();

    std::cout << "...solve" << std::endl;
    std::cout << "\n";
    
    //Solve the system of equations
    directInverseOperator(AssembledGalerkinOperator<Assembler>(assembler), DirectType::UMFPACK).applyscaleadd(-1.0, rhs, sol);
  
    phi.data = sol.data;
    
    //Write the solution to a .VTK file
    writeVTK(phi,"EStaticPotential",IoOptions().setOrder(order).setPrecision(7));
  
    
  
    //Calculating field
    /*
        Since the electrostatic field can be calculated via E = -grad(phi) all that has to be done is to "walk" over every cell and calculate the gradient of phi. 
        This is again done with interpolateGlobally using the continuous Lagrange Space
     
     */
    
    
    auto fieldvarSetDesc = makeVariableSetDescription(makeSpaceList(&phiSpace),
                                                     boost::fusion::make_vector(Variable<SpaceIndex<0>,Components<2>>("E")));        
    auto Efield = fieldvarSetDesc.variableSet();
	Efield = 0;

	interpolateGlobally<PlainAverage>(component<0>(Efield),
                                      makeFunctionView(component<0>(phi).space(), [&] (auto const& evaluator)
    {
          auto dphi = component<0>(phi).derivative(evaluator);
          
          Dune::FieldVector<double,2> ret(0);
          ret[0] = -dphi[0][0];
          ret[1] = -dphi[0][1];

          return ret;
    }));

    writeVTKFile(gridManager.grid().leafGridView(), Efield, "E");

    std::cout << "graphical output finished, data in VTK format is written into file EStaticPotential.vtu \n";

    return 0;
}
