/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/en/numerik/software/kaskade-7.html               */
/*                                                                           */
/*  Copyright (C) 2002-2015 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/* The example currently only does without runtime errors when KASKADE7 is   */
/* compiled with the FLAGS -DBOOST_DISABLE_THREADS -DKASKADE_SEQUENTIAL and  */
/* without the flag -DHAVE_NUMA                                              */
/* NOTE THAT BOOST_DISABLE_THREADS AND KASKADE_SEQUENTIAL ARE NO LONGER      */
/* SUPPORTED.
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#include <iostream>

#include <boost/timer/timer.hpp>

#include "mpi.h"
#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"

#include "fem/assemble.hh"
#include "fem/norms.hh"
#include "fem/lagrangespace.hh"
//#include "fem/hierarchicspace.hh"   // ContinuousHierarchicMapper
#include "linalg/mumpsmpi_solve.hh"
#include "linalg/direct.hh"
#include "utilities/enums.hh"
#include "utilities/gridGeneration.hh" //  createUnitSquare, createUnitCube
#include "io/vtk.hh"
//#include "io/amira.hh"
#include "utilities/kaskopt.hh"

using namespace Kaskade;
#include "ht.hh"

#ifndef SPACEDIM
#define SPACEDIM 2
#endif

#if ( SPACEDIM < 2 ) || ( SPACEDIM > 3 )
#error 'Dimension SPACEDIM must be 2 or 3'
#endif

#if SPACEDIM==2
#define DEFAULT_REFINEMENTS 5
#endif

#if SPACEDIM==3
#define DEFAULT_REFINEMENTS 2
#endif

int main(int argc, char *argv[])
{
  using namespace boost::fusion;
  int id;
  MPI::Init( argc,argv );
  id = MPI::COMM_WORLD.Get_rank ( );

  if ( id == 0 )
  {

  std::cout << "Start heat transfer tutorial program (with SpaceDimension=" << 
                SPACEDIM << ")" << std::endl;
  };

  boost::timer::cpu_timer totalTimer;

  int verbosityOpt = 1;
  bool dump = true; 
  std::unique_ptr<boost::property_tree::ptree> pt = getKaskadeOptions(argc, argv, verbosityOpt, dump);

  int  refinements = getParameter(pt, "refinements", DEFAULT_REFINEMENTS),
       order       = getParameter(pt, "order", 2),
       verbosity   = getParameter(pt, "verbosity", 1);
  if ( id == 0 )
  {
  std::cout << "original mesh shall be refined : " << refinements << " times" << std::endl;
  std::cout << "discretization order           : " << order << std::endl;
  std::cout << "output level (verbosity)       : " << verbosity << std::endl;
  };

  int  direct, onlyLowerTriangle = false, rcode;
    
  DirectType directType;
//   IterateType iterateType = IterateType::CG;
  MatrixProperties property = MatrixProperties::SYMMETRIC;
  PrecondType precondType = PrecondType::NONE;
  std::string empty;
    
  directType = DirectType::MUMPS;

  property = MatrixProperties::SYMMETRIC;

  onlyLowerTriangle = true;
  if ( id == 0 ) std::cout << "Note: direct solver MUMPS ===> onlyLowerTriangle is set to true!" << std::endl;

#if SPACEDIM==2
  constexpr int dim=2;        
  using Grid = Dune::UGGrid<dim>;
#else
  //  three-dimensional space: dim=3
  constexpr int dim=3; 
  using Grid = Dune::UGGrid<dim>;
#endif
  using LeafView = Grid::LeafGridView;
  using H1Space = FEFunctionSpace<ContinuousLagrangeMapper<double,LeafView> >;
  // using H1Space = FEFunctionSpace<ContinuousHierarchicMapper<double,LeafView> >;
  using Spaces = boost::fusion::vector<H1Space const*>;
  using VariableDescriptions = boost::fusion::vector<Variable<SpaceIndex<0>,Components<1>,VariableId<0> > >;
  using VariableSet = VariableSetDescription<Spaces,VariableDescriptions>;
  using Functional = HeatFunctional<double,VariableSet>;
  using Assembler = VariationalFunctionalAssembler<LinearizationAt<Functional> >;
  constexpr int neq = Functional::TestVars::noOfVariables;
  using CoefficientVectors = VariableSet::CoefficientVectorRepresentation<0,neq>::type;
  using LinearSpace = VariableSet::CoefficientVectorRepresentation<0,neq>::type;
  using MUMPSFactorization = MUMPSFactorization<double,int>;
  int blocks = getParameter(pt,"blocks",40);
  int nthreads = getParameter(pt,"threads",4);
  double rowBlockFactor = getParameter(pt,"rowBlockFactor",2.0);
  boost::timer::cpu_timer gridTimer;
#if SPACEDIM==2
  //   two-dimensional space: dim=2
  GridManager<Grid> gridManager( createUnitSquare<Grid>() );
  gridManager.globalRefine(refinements);
  if ( id == 0 ) std::cout << std::endl << "Grid: " << gridManager.grid().size(0) << " triangles, " << std::endl;
#else
  GridManager<Grid> gridManager( createUnitCube<Grid>(0.5) );
  gridManager.globalRefine(refinements);
  if ( id == 0 ) std::cout << std::endl << "Grid: " << gridManager.grid().size(0) << " tetrahedra, " << std::endl;
  if ( id == 0 ) std::cout << "      " << gridManager.grid().size(1) << " triangles, " << std::endl;
#endif
  if ( id == 0 ) std::cout << "      " << gridManager.grid().size(dim-1) << " edges, " << std::endl;
  if ( id == 0 ) std::cout << "      " << gridManager.grid().size(dim) << " points" << std::endl;

  if ( id == 0 ) std::cout << "computing time for generation of initial mesh: " << boost::timer::format(gridTimer.elapsed()) << "\n";
    
    
  // construction of finite element space for the scalar solution T.
  H1Space temperatureSpace(gridManager,gridManager.grid().leafGridView(),order);
    
  Spaces spaces(&temperatureSpace);
  Assembler assembler(gridManager,spaces);
    
  // construct variable list.
  // VariableDescription<int spaceId, int components, int Id>
  // spaceId: number of associated FEFunctionSpace
  // components: number of components in this variable
  // Id: number of this variable
        
  std::string varNames[1] = { "u" };
    
  VariableSet variableSet(spaces,varNames);

  // construct variational functional
    
  double kappa = getParameter(pt, "kappa", 1.0),
         q     = getParameter(pt, "q", 1.0);
  if ( id == 0 ) 
  {
    std::cout << "the diffusion constant kappa is   : " << kappa << std::endl;
    std::cout << "the mass coefficient q is         : " << q << std::endl;
  };
  Functional F(kappa,q);
  constexpr int nvars = Functional::AnsatzVars::noOfVariables;
  size_t size = variableSet.degreesOfFreedom(0,nvars);
  if ( id == 0 ) 
  {
    std::cout << std::endl << "no of variables = " << nvars << std::endl;
    std::cout << "no of equations = " << neq   << std::endl;
    std::cout << "number of degrees of freedom = " << size   << std::endl;
  };

  //construct Galerkin representation
  VariableSet::VariableSet u(variableSet);

  size_t nnz = assembler.nnz(0,neq,0,nvars,onlyLowerTriangle);
  if ( id == 0 ) std::cout << "number of nonzero elements in the stiffness matrix: " << nnz << std::endl << std::endl;
  
  boost::timer::cpu_timer assembTimer;
  
  // UG seems to admit concurrent reads while claiming not to be thread safe. In this case we enforce multithreading during assembly.
  if ( id == 0 ) 
  {
    gridManager.enforceConcurrentReads(true);
    assembler.setNSimultaneousBlocks(blocks);
    assembler.setRowBlockFactor(rowBlockFactor);
    assembler.assemble(linearization(F,u),assembler.MATRIX|assembler.RHS|assembler.VALUE,nthreads,verbosity);
    std::cout << "computing time for assemble: " << boost::timer::format(assembTimer.elapsed()) << "\n";
  };
  CoefficientVectors rhs(assembler.rhs());
  std::vector<double> rhsvec(size),solutionvec(size); 
  

  MatrixAsTriplet<double> tri;
  if ( id == 0 )
  {
    AssembledGalerkinOperator<Assembler,0,neq,0,nvars> A(assembler, onlyLowerTriangle);
    tri = A.get<MatrixAsTriplet<double> >();
    rhs.write(rhsvec.begin());
  };
  {
    boost::timer::cpu_timer directTimer;
    MUMPSFactorization mumpsFactorization(size,tri.ridx,tri.cidx,tri.data,property,0);
    mumpsFactorization.solve(rhsvec,solutionvec);
    std::cout << "computing time for direct solve: " << boost::timer::format(directTimer.elapsed()) << "\n";
  };
  if ( id == 0 )
  {
    u.read(solutionvec.begin());
  
    
  
    // compute L2 norm of the solution
    boost::timer::cpu_timer outputTimer;
    L2Norm l2Norm;
    std::cout << "L2norm(solution) = " << l2Norm(boost::fusion::at_c<0>(u.data)) << std::endl;
    
    

    // output of solution in VTK format for visualization,
    // the data are written as ascii stream into file temperature.vtu,
    // possible is also binary
    writeVTKFile(u,"temperature",IoOptions().setOrder(order).setPrecision(7));

    std::cout << "graphical output finished, data in VTK format is written into file temperature.vtu \n";
    
    // output of solution for Amira visualization,
    // the data are written in binary format into file temperature.am,
    // possible is also ascii
    // IoOptions options;
    // options.outputType = IoOptions::ascii;
    // LeafView leafGridView = gridManager.grid().leafGridView();
    // writeAMIRAFile(leafGridView,variableSet,u,"temperature",options);

    std::cout << "computing time for output: " << boost::timer::format(outputTimer.elapsed()) << "\n";

    std::cout << "total computing time: " << boost::timer::format(totalTimer.elapsed()) << "\n";
    std::cout << "End heat transfer tutorial program" << std::endl;
  };
  MPI::Finalize ( );
}
