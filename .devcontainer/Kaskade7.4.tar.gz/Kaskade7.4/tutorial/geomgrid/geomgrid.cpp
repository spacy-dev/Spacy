/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2009 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>
#include <cmath>

#include <boost/timer/timer.hpp>

#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"
#include "dune/grid/geometrygrid.hh"

#include "fem/assemble.hh"
#include "fem/norms.hh"
#include "fem/embedded_errorest.hh"
#include "fem/istlinterface.hh"
#include "fem/functional_aux.hh"
//#include "fem/hierarchicspace.hh"
#include "fem/lagrangespace.hh"
#include "linalg/direct.hh"
#include "io/vtk.hh"
#include "utilities/kaskopt.hh"

using namespace Kaskade;
#include "laplace.hh"

class SquareToCircle: public Dune::AnalyticalCoordFunction< double, 2, 2, SquareToCircle >
{
  using Base = Dune::AnalyticalCoordFunction< double, 2, 2, SquareToCircle >;

  public:
  using DomainVector = Base::DomainVector;
  using RangeVector = Base::RangeVector;
  
  SquareToCircle ( double _radius=sqrt(2) ): radius(_radius) {}
  
  void evaluate ( const DomainVector &u, RangeVector &y ) const
  {
    double enorm = sqrt(u[0]*u[0]+u[1]*u[1]);
    if(enorm > 1.0e-5)
    {
      double radiusFactor = radius*std::max(std::fabs(u[0]),std::fabs(u[1]));
      double scaling = radiusFactor/enorm;
      y[ 0 ] = u[ 0 ]*scaling;
      y[ 1 ] = u[ 1 ]*scaling;
    } 
    else
    {
      y[ 0 ] = u[ 0 ];
      y[ 1 ] = u[ 1 ];
    }
  }
  
  private:
  double radius;
};

int main(int argc, char *argv[])
{
  std::cout << "Start GeometryGrid tutorial program" << std::endl;

  boost::timer::cpu_timer totalTimer;

  int refinements, order, verbosity;
  double radius;

  if (getKaskadeOptions(argc,argv,Options
    ("refinements",      refinements,        5,          "number of uniform grid refinements")
    ("order",            order,              2,          "finite element ansatz order")
    ("verbosity",        verbosity,          1,          "output level")
    ("radius",           radius,  std::sqrt(2),          "radius of the circle")))
    return 1;

  std::cout << "original mesh shall be refined : " << refinements << " times" << std::endl;
  std::cout << "discretization order           : " << order << std::endl;
  std::cout << "output level (verbosity)       : " << verbosity << std::endl;

  bool onlyLowerTriangle = false;

 // two-dimensional space: dim=2
  constexpr int dim=2;        
  using Grid = Dune::UGGrid<dim>;
  using GeoGrid = Dune::GeometryGrid<Grid,SquareToCircle>;
  using LeafView = GeoGrid::LeafGridView;
  using H1Space = FEFunctionSpace<ContinuousLagrangeMapper<double,LeafView> >;
  using Spaces = boost::fusion::vector<H1Space const*>;
  using VariableDescriptions = boost::fusion::vector<Variable<SpaceIndex<0>,Components<1>,VariableId<0> > >;
  using VariableSetDesc = VariableSetDescription<Spaces,VariableDescriptions>;
  using Functional = HeatFunctional<double,VariableSetDesc>;
  using Assembler = VariationalFunctionalAssembler<LinearizationAt<Functional> >;
  using Operator = AssembledGalerkinOperator<Assembler>;
  constexpr int neq = Functional::TestVars::noOfVariables;
  using CoefficientVectors = VariableSetDesc::CoefficientVectorRepresentation<0,neq>::type;

  boost::timer::cpu_timer gridTimer;
  Dune::GridFactory<Grid> factory;
  // vertex coordinates v[0], v[1]
  Dune::FieldVector<double,dim> v;  
  v[0]=-1; v[1]=-1; factory.insertVertex(v);
  v[0]=1; v[1]=-1; factory.insertVertex(v);
  v[0]=1; v[1]=1; factory.insertVertex(v);
  v[0]=-1; v[1]=1; factory.insertVertex(v);
  v[0]=0; v[1]=0; factory.insertVertex(v);
  // triangle defined by 3 vertex indices
  std::vector<unsigned int> vid(3);
  Dune::GeometryType gt(Dune::GeometryType::simplex,2);
  vid[0]=0; vid[1]=1; vid[2]=4; factory.insertElement(gt,vid);
  vid[0]=1; vid[1]=2; vid[2]=4; factory.insertElement(gt,vid);
  vid[0]=2; vid[1]=3; vid[2]=4; factory.insertElement(gt,vid);
  vid[0]=3; vid[1]=0; vid[2]=4; factory.insertElement(gt,vid);

  Grid* grid( factory.createGrid() ) ;
  GridManager<GeoGrid> gridManager(new GeoGrid(grid,new SquareToCircle(radius)));    
  gridManager.globalRefine(refinements);
  std::cout << "Grid: " << gridManager.grid().size(0) << " triangles, " << std::endl;
  std::cout << "      " << gridManager.grid().size(1) << " edges, " << std::endl;
  std::cout << "      " << gridManager.grid().size(2) << " points" << std::endl;
  std::cout << "computing time for generation of initial mesh: " << boost::timer::format(gridTimer.elapsed());

  // construction of finite element space for the scalar solution u
  H1Space temperatureSpace(gridManager,gridManager.grid().leafGridView(),order);
  Spaces spaces(&temperatureSpace);
  std::string varNames[1] = { "T" };
  VariableSetDesc variableSet(spaces,varNames);

  Functional F(radius);
  constexpr int nvars = Functional::AnsatzVars::noOfVariables;
  std::cout << std::endl << "no of variables = " << nvars << std::endl;
  std::cout << "no of equations = " << neq   << std::endl;
  size_t dofs = variableSet.degreesOfFreedom(0,nvars);
  std::cout << "number of degrees of freedom = " << dofs   << std::endl;

 //construct Galerkin representation
  Assembler assembler(spaces);
  VariableSetDesc::VariableSet u(variableSet);

  size_t nnz = assembler.nnz(0,neq,0,nvars,onlyLowerTriangle);
  std::cout << "number of nonzero elements in the stiffness matrix: " << nnz << std::endl << std::endl;

  boost::timer::cpu_timer assembTimer;
  assembler.assemble(linearization(F,u));
  std::cout << "computing time for assemble: " << boost::timer::format(assembTimer.elapsed());
  
  Operator A(assembler);
  CoefficientVectors solution(VariableSetDesc::CoefficientVectorRepresentation<>::init(spaces));
  CoefficientVectors rhs(assembler.rhs());

  boost::timer::cpu_timer directTimer;
  directInverseOperator(A).applyscaleadd(-1.0,rhs,solution);
  std::cout << "computing time for direct solve: " << boost::timer::format(directTimer.elapsed());
  component<0>(u) = component<0>(solution);

  L2Norm l2Norm;
  std::cout << "L2norm(solution) = " << l2Norm(boost::fusion::at_c<0>(u.data)) << std::endl;
  
  boost::timer::cpu_timer outputTimer;
  writeVTK(u,"temperature",IoOptions().setOrder(order).setPrecision(7));
  std::cout << "graphical output finished, data in VTK format is written into file temperature.vtu\n";
  std::cout << "computing time for output: " << boost::timer::format(outputTimer.elapsed()) << "\n";
  std::cout << "total computing time: " << boost::timer::format(totalTimer.elapsed());
  std::cout << "End GeometryGrid tutorial program" << std::endl;
}
