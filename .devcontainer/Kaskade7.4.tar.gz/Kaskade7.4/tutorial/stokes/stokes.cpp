/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2020 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>

#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"

#include "fem/assemble.hh"
#include "fem/lagrangespace.hh"
#include "linalg/jacobiPreconditioner.hh"
#include "linalg/uzawa.hh"
#include "linalg/direct.hh"
#include "linalg/cg.hh"
#include "io/vtk.hh"
#include "utilities/kaskopt.hh" 
#include "utilities/gridGeneration.hh"
#include "utilities/timing.hh"

using namespace Kaskade;
#include "stokes.hh"

int main(int argc, char *argv[])
{
  using namespace boost::fusion;
  auto& timer = Timings::instance();

  int verbosity = 1;  // print to console if arguments are changed
  bool dump = false; // do not write properties into file

  int order, porder, refinements, lookAhead;
  std::string solver;
  if (getKaskadeOptions(argc,argv,Options
  ("order",        order,           2, "polynomial ansatz order for velocities")
  ("porder",      porder,           1, "polynomial ansatz order for pressure")
  ("refine", refinements,           5, "uniform mesh refinements")
  ("solver",      solver,   "UMFPACK", "solver to use (currently supported: UMFPACK, MUMPS")
  ("lookahead",lookAhead,           3, "look ahead that many iterations in CG termination criterion")
  )) return 0;

  std::cout << "Start stokes tutorial programm." << std::endl;

  constexpr int dim = 2;
  constexpr int uIdx = 0;
  constexpr int pIdx = 1;

  // command line parameters
  bool direct = false;
  DirectType directType;
  if (solver=="UMFPACK")
  {
    direct = true;
    directType = DirectType::UMFPACK;
  }
  else if (solver=="MUMPS")
  {
    direct = true;
    directType = DirectType::MUMPS;
  }
  else
  {
    std::cerr << "unknown solver type " << solver << "\n";
    return 1;
  }

  std::cout << "original mesh shall be refined : " << refinements << " times" << std::endl;
  std::cout << "discretization order           : " << order << std::endl;
  std::cout << "direct solver                  : " << directType << std::endl;

  // grid generation
  timer.start("Grid generation");
  using Grid = Dune::UGGrid<dim>;
  using H1Space = FEFunctionSpace<ContinuousLagrangeMapper<double,Grid::LeafGridView> >;

  Dune::FieldVector<double,dim> x0(0.0), length(1.0);
  GridManager<Grid> gridManager(createRectangle<Grid>(x0,length,1.0));
  gridManager.globalRefine(refinements);
  timer.stop("Grid generation");


  // construct involved spaces and variable set descriptions.
  H1Space pressureSpace(gridManager,gridManager.grid().leafGridView(),porder);
  H1Space velocitySpace(gridManager,gridManager.grid().leafGridView(),order);

  auto varSetDesc = makeVariableSetDescription(makeSpaceList(&pressureSpace,&velocitySpace),
                                               boost::fusion::make_vector(
                                                      Variable<SpaceIndex<1>,Components<dim>>("u"),
                                                      Variable<SpaceIndex<0>,Components<1>>("p")));
  using VarSetDesc = decltype(varSetDesc);


  using CoefficientVectors = VarSetDesc::CoefficientVectorRepresentation<>::type;
  using Functional = StokesFunctional<double,VarSetDesc>;
  using Assembler = VariationalFunctionalAssembler<LinearizationAt<Functional>>;


  // construct variational functional.
  Functional F;

  // construct Galerkin representation
  Assembler assembler(varSetDesc.spaces);
  auto x = varSetDesc.variableSet();
  auto dx = varSetDesc.variableSet();

  size_t nnz = assembler.nnz(0,2,0,2,false);
  size_t dof = varSetDesc.degreesOfFreedom(0,2);
  std::cout << "overall degrees of freedom: " << dof << std::endl;
  std::cout << "(structurally) nonzero elements: " << nnz << std::endl;

  timer.start("Assembly");
  assembler.assemble(linearization(F,x));
  timer.stop("Assembly");
  std::cout << "End stokes tutorial program" << std::endl;
}
