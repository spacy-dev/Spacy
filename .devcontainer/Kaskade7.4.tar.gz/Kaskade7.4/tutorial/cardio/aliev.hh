/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/en/numerik/software/kaskade-7.html               */
/*                                                                           */
/*  Copyright (C) 2002-2011 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef ALIEV_HH
#define ALIEV_HH

#include "fem/fixdune.hh"
#include "fem/variables.hh"

/// Example simple moving source equation
///

int printCount = 10; 
    
template <class RType, class VarSet>
class AlievPanfilovEquation: public FunctionalBase<WeakFormulation>
{
  using Self=AlievPanfilovEquation<RType,VarSet>;
  public:
  using Scalar = RType;
  using AnsatzVars = VarSet;
  using TestVars = VarSet;
  using OriginVars = VarSet;

  //Material material;

  //static ProblemType const type = WeakFormulation;

  using Cell = typename AnsatzVars::Grid::template Codim<0>::Entity;
  using Position = Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension>;

  private:
  static int const uIdx = 0; // u
  static int const vIdx = 1; // v
  static int const uSIdx = boost::fusion::result_of::value_at_c<typename OriginVars::Variables,uIdx>::type::spaceIndex;
  static int const vSIdx = boost::fusion::result_of::value_at_c<typename OriginVars::Variables,vIdx>::type::spaceIndex;

  public:

  /// \class DomainCache
  ///
  class DomainCache 
  {
    public:
    DomainCache(Self const& F_,
                typename AnsatzVars::VariableSet const& vars_,int flags=7):
      F(F_), vars(vars_) 
    {}

    void moveTo(Cell const &entity) { e = &entity; }

    template <class Position, class Evaluators>
    void evaluateAt(Position const& x, Evaluators const& evaluators) 
    {
      using namespace boost::fusion;
      Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension> xglob = e->geometry().global(x);

      u   = at_c<uIdx>(vars.data).value(at_c<uSIdx>(evaluators));
      du  = at_c<uIdx>(vars.data).derivative(at_c<uSIdx>(evaluators))[0];
      
      v   = at_c<vIdx>(vars.data).value(at_c<vSIdx>(evaluators));
      dv  = at_c<vIdx>(vars.data).derivative(at_c<vSIdx>(evaluators))[0];
      
      
      t = F.time();

      // f = 0.0;
      
      ex = F.excitation(e->geometry().global(x));
    }

    template<int row, int dim> 
    Dune::FieldVector<Scalar, TestVars::template Components<row>::m>
    d1 (VariationalArg<Scalar,dim> const& arg) const 
    {
      if (row==uIdx) return -F.kappa*(du*arg.derivative[0]) + f(u,v)*arg.value + ex*arg.value;
      else if (row==vIdx) return g(u,v)*arg.value;
      assert("wrong index\n"==0);
      return 0;
    }

    template<int row, int col, int dim> 
    Dune::FieldMatrix<Scalar, TestVars::template Components<row>::m, AnsatzVars::template Components<col>::m>
    d2 (VariationalArg<Scalar,dim> const &arg1, VariationalArg<Scalar,dim> const &arg2) const 
    {
      // reaction explicit
      if (row==uIdx && col==uIdx) return -F.kappa*(arg1.derivative[0]*arg2.derivative[0]);
      if (row==uIdx && col==vIdx) return 0.0;
      
      if (row==vIdx && col==uIdx) return gu(u,v)*arg1.value*arg2.value;
      if (row==vIdx && col==vIdx) return gv(u,v)*arg1.value*arg2.value;


      assert("wrong index\n"==0);
      return 0;
    }

    template<int row, int col, int dim> 
    Dune::FieldMatrix<Scalar, TestVars::template Components<row>::m, AnsatzVars::template Components<col>::m>
    b2 (VariationalArg<Scalar,dim> const &arg1, VariationalArg<Scalar,dim> const &arg2) const 
    {
      if (row==uIdx && col==uIdx) return arg1.value[0]*arg2.value[0];
      else if (row==col)          return arg1.value[0]*arg2.value[0];
      else                        return 0;

    }

    private:
    Self const& F;
    typename AnsatzVars::VariableSet const& vars;

    Cell const* e;

    Scalar f(Scalar u, Scalar v)  const { return -(F.ga*u*(u-F.a)*(u-1.0) + u*v); }
    
    Scalar fu(Scalar u, Scalar v) const 
    { Scalar  Fu = -F.ga*( (2*u-F.a)*(u-1.0) + u*(u-F.a) ) - v; 
      if (Fu > 0.0) Fu=0.0; return Fu;
    }
    
    Scalar fv(Scalar u, Scalar v) const { return -u; }
    
    Scalar g(Scalar u, Scalar v)  const { return 0.25*(F.eps1+F.mu1*v/(u+F.mu2))*(-v-F.gs*u*(u-F.a-1.0)); }
    
    Scalar gu(Scalar u, Scalar v) const 
    { 
      return 0.25*( - F.mu1*v/((u+F.mu2)*(u+F.mu2))*(-v-F.gs*u*(u-F.a-1))-(F.eps1+F.mu1*v/(u+F.mu2))*(F.gs*(2*u-F.a-1)) ); 
    }
    
    Scalar gv(Scalar u, Scalar v) const 
    { 
       Scalar Gv =  0.25*( F.mu1/(u+F.mu2)*(-v-F.gs*u*(u-F.a-1)) - (F.eps1+F.mu1*v/(u+F.mu2)) ); 
       if (Gv > 0.0) { Gv = 0.0;}
       return Gv;
    }

    Scalar u, v, t, ex;
    Dune::FieldVector<Scalar,AnsatzVars::Grid::dimension> du, dv;
  };

  /// \class BoundaryCache
  ///
  class BoundaryCache 
  {
    public:
    using FaceIterator = typename AnsatzVars::Grid::LeafIntersectionIterator;

    BoundaryCache(Self const& F_,
                  typename AnsatzVars::VariableSet const& vars_,int flags=7):
      F(F_), vars(vars_), e(0)
    {}

    void moveTo(FaceIterator const& entity)
    {
      e = &entity;
      penalty = 1.0e9;
    }

    template <class Evaluators>
    void evaluateAt(Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension-1> const& x, Evaluators const& evaluators) 
    {}
    
    template<int row, int dim> 
    Dune::FieldVector<Scalar, TestVars::template Components<row>::m>
    d1 (VariationalArg<Scalar,dim> const& arg) const 
    {
      return 0;
    }

    template<int row, int col, int dim> 
    Dune::FieldMatrix<Scalar, TestVars::template Components<row>::m, AnsatzVars::template Components<col>::m>
    d2 (VariationalArg<Scalar,dim> const &arg1, VariationalArg<Scalar,dim> const &arg2) const 
    {
      return 0;
    }
    
    template<int row, int col, int dim> 
    Dune::FieldMatrix<Scalar, TestVars::template Components<row>::m, AnsatzVars::template Components<col>::m>
    b2 (VariationalArg<Scalar,dim> const &arg1, VariationalArg<Scalar,dim> const &arg2) const 
    {
      return 0;
    }

    private:
    Self const& F;
    typename AnsatzVars::VariableSet const& vars;
    FaceIterator const* e;
    Scalar penalty;
    Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension> xglob;
  };

  class Scaling 
  {
    public:
    Scaling(Self const& self_): self(&self_) {}

    template <class Vals>
    void scale(Cell const&, Position const&, Vals& vals) const 
    {
    }

    private:
    Self const* self;
  };

  public:

  void newTime(Scalar dt) { t += dt; }
  
  Scalar time() const { return t; }
  
  void time(Scalar tnew)  { t=tnew; }

  Scaling scaling() const { return Scaling(*this); }

  void temporalEvaluationRange(double t0, double t1) { tau = t1-t0; }

  template <int row>
  struct D1: public FunctionalBase<VariationalFunctional>::D1<row> 
  {
    static bool const present   = true;
    static bool const constant  = false;
  };

  template <int row, int col>
  struct D2: public FunctionalBase<VariationalFunctional>::D2<row,col> 
  {
    static bool const present   = (row==col) || (row==vIdx && col==uIdx);
    static bool const symmetric = true;
    static bool const lumped    = false;
  };

  template <int row, int col>
  struct B2 
  {
    static bool const present   = (row==col);
    static bool const symmetric = true;
    static bool const constant  = false;
    static bool const lumped    = false;
  };

  /**
   * Given an initial value, this is transfered to a properly scaled
   * finite element iterate.
   */
  template <int row, class WeakFunctionView>
  void scaleInitialValue(WeakFunctionView const& u0, typename AnsatzVars::VariableSet& u) const 
  {
    interpolateGloballyWeak<Volume>(boost::fusion::at_c<row>(u.data),
                                      ScaledFunction<WeakFunctionView>(true,u0,*this));
  }

  /// \fn integrationOrder
  ///

  template <class Cell>
  int integrationOrder(Cell const& /* cell */, int shapeFunctionOrder, bool boundary) const 
  {
    if (boundary) 
      return 2*shapeFunctionOrder;
    else
      return 2*shapeFunctionOrder+1;
  }

  private:
  Scalar t, tau;
     

  template <class WeakFunctionView>
  struct ScaledFunction 
  {
    using Scalar = typename WeakFunctionView::Scalar;
    static int const components = WeakFunctionView::components;
    using ValueType = Dune::FieldVector<Scalar,components>;

    ScaledFunction(bool doScaling_,
                   WeakFunctionView const& u0_,
                   AlievPanfilovEquation<RType,AnsatzVars> const& f_): doScaling(doScaling_), u0(u0_), f(f_) {}

    template <class Cell>
    int order(Cell const&) const { return std::numeric_limits<int>::max(); }

    template <class Cell>
    ValueType value(Cell const& cell,
                    Dune::FieldVector<typename Cell::Geometry::ctype,Cell::dimension> const& localCoordinate) const 
    {
      ValueType u = u0.value(cell,localCoordinate);
      return u;
    }

    private:
    bool doScaling;
    WeakFunctionView const& u0;
    AlievPanfilovEquation<RType,AnsatzVars> const& f;
  };

  private:  
  Scalar xi, kappa, a, gs, ga, mu1, mu2, eps1, v_rest, v_peak;
  double reactionImplicitFactor;
  
  Scalar excitation(Position const& x) const 
  {
    Scalar Iapp = 0.0;
    
    // slab
    if(t<0.015) 
      if ( (x[0]>=1.4) && (x[0]<=1.6) && (x[1]>=1.4) && (x[1]<=1.6) && (x[2]>=1.05) && (x[2]<=1.1) ) 
      {
        Iapp=10000.0*t;
        if (Iapp > 100.0) Iapp = 100.0;
      }
    return Iapp;
  }

  public: 
  AlievPanfilovEquation(Scalar xi_, Scalar kappa_, Scalar a_, Scalar gs_, Scalar ga_, Scalar mu1_, Scalar mu2_, Scalar eps1_,
            Scalar v_rest_, Scalar v_peak_):
            t(0), xi(xi_), kappa(kappa_), a(a_), gs(gs_), ga(ga_), 
            mu1(mu1_), mu2(mu2_), eps1(eps1_), v_rest(v_rest_), v_peak(v_peak_),
            reactionImplicitFactor(1) 
  {}

};

#endif
