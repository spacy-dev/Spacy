/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/en/numerik/software/kaskade-7.html               */
/*                                                                           */
/*  Copyright (C) 2002-2011 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#define FUSION_MAX_VECTOR_SIZE 20

#include <iostream>

#include <boost/timer/timer.hpp>

#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"

#include "utilities/enums.hh"
#include "fem/assemble.hh"
#include "fem/gridmanager.hh"
#include "fem/lagrangespace.hh"
#include "fem/functional_aux.hh"
#include "fem/coarsening.hh"
#include "fem/norms.hh"

#include "linalg/direct.hh"
//#include "linalg/cg.hh"               // alternative: use Kaskade7 CG
//#include "linalg/iluprecond.hh"       // with ILUK preconditioner

#include "timestepping/limexWithoutJens.hh"

#include "utilities/kaskopt.hh"
#include "utilities/gridGeneration.hh"

using namespace Kaskade;

#include "aliev-integrate.hh"
#include "aliev.hh"

struct InitialValue 
{
  using Scalar = double;
  static int const components = 1;
  using ValueType = Dune::FieldVector<Scalar,components>;

  InitialValue(int c): component(c) {}
  
  template <class Cell> int order(Cell const&) const { return std::numeric_limits<int>::max(); }
  template <class Cell>
  ValueType value(Cell const& cell,
                  Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> const& localCoordinate) const 
  {
    Dune::FieldVector<typename Cell::Geometry::ctype,Cell::Geometry::coorddimension> x = cell.geometry().global(localCoordinate);


    if (component==0) 
      return 0.0;	
    else if ( component==1 ) 
      return 0.0;
    else
      assert("wrong index!\n"==0);
    return 0;
  }

private:
  int component;
};

int main(int argc, char *argv[])
{
  using namespace boost::fusion;

  int verbosityOpt = 1; 
  bool dump = false; 
  std::unique_ptr<boost::property_tree::ptree> pt = getKaskadeOptions(argc, argv, verbosityOpt, dump);

  std::cout << "Start cardiac tutorial program" << std::endl;

  boost::timer::cpu_timer totalTimer;
  double gridTime=0.0;

  int  verbosity   = getParameter(pt, "verbosity", 1);

  int const dim = 3;
  int refinements;
  int  order, extrapolOrder, maxSteps;
  double dt, maxDT, T, rTolT, aTolT, rTolX, aTolX, writeInterval;

  DirectType directType = DirectType::MUMPS;
  // IterateType iterateType = IterateType::CG;
  // PrecondType precondType = PrecondType::ILUK;
  // MatrixProperties property = MatrixProperties::SYMMETRIC;

  // initial grid and space parameters 
  refinements = 2;   
  order = 2;

  //integrator parameters
  extrapolOrder = 2;
  T     = 100.0;
  dt    = 1.0e-3;
  maxDT = 4.0;
  writeInterval = 1.0;
  rTolT = 1e-3;
  aTolT = 1e-3;
  rTolX = 2e-3;
  aTolX = 2e-3;
  maxSteps = getParameter(pt,"maxSteps",40); 

  double xi, a, gs, ga, mu1, mu2, eps1, kappa, v_rest, v_peak;
  
  // equation parameters
  xi   = 1.0;
  kappa = 0.001;
  a = 0.1;
  gs = 8.0;
  ga = 8.0;
  mu1 = 0.07;
  mu2 = 0.3;
  eps1 = 0.01;
  v_rest = 0.0;   //-85.0;
  v_peak = 1.0;   //35.0;

  std::cout << "Start Aliev-Panfilov integration" << std::endl;

  using Grid = Dune::UGGrid<dim>;
  int heapSize=65536;   // 16384;
  Grid::setDefaultHeapSize(heapSize);

  double dh = 0.1;
  Dune::FieldVector<double,dim> c0(0.0), dc(0.0);
  c0[0]=1.0; c0[1]=1.0; c0[2]=1.0; 
  dc[0]=1.0; dc[1]=1.0; dc[2]=0.1; 
  GridManager<Grid> gridManager( createCuboid<Grid>(c0,dc,dh,true) );
  gridManager.enforceConcurrentReads(true);

  // some information on the refined mesh
  std::cout << std::endl << "Grid: " << gridManager.grid().size(0) << " tetrahedra, " << std::endl;
  std::cout << "      " << gridManager.grid().size(1) << " triangles, " << std::endl;
  std::cout << "      " << gridManager.grid().size(dim-1) << " edges, " << std::endl;
  std::cout << "      " << gridManager.grid().size(dim) << " points" << std::endl;


  // construct involved spaces.
  using H1Space = FEFunctionSpace<ContinuousLagrangeMapper<double,Grid::LeafGridView> >;

  H1Space temperatureSpace(gridManager,gridManager.grid().leafGridView(),order);

  using Spaces = boost::fusion::vector<H1Space const*>;
  Spaces spaces(&temperatureSpace);

  using VariableDescriptions = boost::fusion::vector<Variable<SpaceIndex<0>,Components<1>,VariableId<0> >,
                                Variable<SpaceIndex<0>,Components<1>,VariableId<1> > >;
  std::string varNames[5] = { "u", "v" };
  
  using VarSetDesc = VariableSetDescription<Spaces,VariableDescriptions>;
  VarSetDesc varSetDesc(spaces,varNames);

  VarSetDesc::VariableSet u(varSetDesc);

  using Equation = AlievPanfilovEquation<double,VarSetDesc>;
  Equation Eq(xi,kappa,a,gs,ga,mu1,mu2,eps1,v_rest,v_peak);

  gridManager.globalRefine(refinements);

  std::vector<VarSetDesc::VariableSet> solutions;

  Eq.time(0);

  Eq.scaleInitialValue<0>(InitialValue(0),u);
  Eq.scaleInitialValue<1>(InitialValue(1),u);
    
  u = integrate(gridManager,Eq,varSetDesc,spaces,gridManager.grid(),
                dt,maxDT,T,maxSteps,rTolT,aTolT,rTolX,aTolX,extrapolOrder,
                std::back_inserter(solutions),writeInterval,u,directType,
                verbosity);

  std::cout << "total cpu-time: " << boost::timer::format(totalTimer.elapsed()) << "\n";
  std::cout << "End cardiac tutorial program" << std::endl;
}
