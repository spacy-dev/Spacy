/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/en/numerik/software/kaskade-7.html               */
/*                                                                           */
/*  Copyright (C) 2002-2011 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#ifndef INTEGRATE_HH
#define INTEGRATE_HH

#include <iostream>

#include "io/vtk.hh"
#if HAVE_LIBAMIRA == 1
#include "io/amira.hh"
#endif

template <class Grid, class Equation, class VariableSet, class Spaces, class OutIter>
typename VariableSet::VariableSet  integrate(GridManager<Grid>& gridManager,
                                                Equation& eq, VariableSet const& variableSet, Spaces const& spaces,
                                                Grid const& grid, double dt, double dtMax,
                                                double T, int maxSteps, double rTolT, double aTolT,
                                                double rTolX, double aTolX, int extrapolOrder, 
                                                OutIter out, double outInterval,
                                                typename VariableSet::VariableSet x,
                                                DirectType directType,
                                                int verbosity = 0)
{
  // write initial position
  *out = x;
  ++out;
  double outTime = eq.time()+outInterval;
  
  std::vector<std::pair<double,double> > tolX(variableSet.noOfVariables);
  std::vector<std::pair<double,double> > tolXC(variableSet.noOfVariables);

  for (int i=0; i<tolX.size(); ++i) {
    tolX[i] = std::make_pair(aTolX,rTolX);
    tolXC[i] = std::make_pair(aTolX/100,rTolX/100);
  }
  
  std::vector<std::pair<double,double> > tolT(variableSet.noOfVariables);
  for (int i=0; i<tolT.size(); ++i)
    tolT[i] = std::make_pair(aTolT,rTolT);
  
  Limex<Equation> limex(gridManager,eq,variableSet,directType,PrecondType::ILUK,verbosity);

  static int vtkFileNo = 0;

  Dune::FieldVector<double,3> samplePos1(0);
  samplePos1[0] =  1.01;
  samplePos1[1] =  1.01;
  samplePos1[2] =  1.01;
  std::cout << "checkpoint: " << samplePos1 << std::endl;
  const char* sample1File_name = "potentialInVertex.gnu";
  static std::ofstream sample1_out(sample1File_name);
  
  int steps;
  bool done = false;
  for (steps=0; !done && steps<maxSteps; ++steps) 
  {
    if (eq.time()>T-1.1*dt) {
      dt = T-eq.time();
      done = true;
    }
    
    typename VariableSet::VariableSet dx(x);

    int redMax = 5;
    int red = 0;
    double factor = 1.0;
    double err;
    
    do {
      dt *= factor;
      dx = limex.step(x,dt,extrapolOrder,tolX);

      std::vector<std::pair<double,double> > errors = limex.estimateError(x,extrapolOrder,extrapolOrder-1);
      err = 0;
      for (int i=0; i<errors.size(); ++i)
        err = std::max(err, errors[i].first/(tolT[i].first+tolT[i].second*errors[i].second));
      
      factor = std::pow(0.5/err,1./(extrapolOrder+2));
      factor = std::max(0.5,std::min(factor,1.33));
      if ( verbosity > 0 ) 
      {
        std::cout << eq.time()+dt << ' ' << dt << ' ' << err << ' ' << red << ' '
        << variableSet.degreesOfFreedom() << ' ' << std::scientific << std::setprecision(3) <<
	  //  boost::fusion::at_c<0>(x.data).value(samplePos)[0]  << 
        std::resetiosflags(std::ios::scientific) << std::setprecision(6) << '\n';
      };
      ++red;
    } while(err>1 && red<=redMax);
    
    if ( verbosity>0 ) 
    {
      std::cout.flush();
      std::cout << "t= " << eq.time()+dt << " dt = " << dt << " factor = " << factor << " red=" << red << '\n';
    };

    // write linearly interpolated equidistant output
    assert(eq.time()<=outTime);
    while (outTime<=eq.time()+dt) {
      typename VariableSet::VariableSet z(x);
      z.axpy((outTime-eq.time())/dt,dx);
      // *out = z;
      // ++out;
      outTime += outInterval;
    }
    
    // step ahead
    x += dx;
    eq.time(eq.time()+dt);
    dt = std::min(dt*factor,dtMax);

    std::ostringstream fn;
    fn << "graph/aliev-slab-uv-";
    fn.width(3);
    fn.fill('0');
    fn.setf(std::ios_base::right,std::ios_base::adjustfield);
    vtkFileNo++;
    fn << vtkFileNo;    // steps+1;      //2*steps+1;
    fn.flush();
    writeVTKFile(x,fn.str(),IoOptions().setOrder(1));
    if ( verbosity>0 ) 
    {
      std::cout << variableSet.degreesOfFreedom() << " values written to " << fn.str() << std::endl;
    }

    double checkPt = boost::fusion::at_c<0>(x.data).value(samplePos1)[0];
    sample1_out << eq.time() << ' '  << ' ' <<  checkPt << std::endl;
    std::cout << "checkpoint: " << eq.time() << "    " <<  checkPt << '\n';
    
    // perform mesh coarsening
    std::vector<bool> dummy(0);
    coarsening(variableSet,x,eq.scaling(),tolX,gridManager,dummy,verbosity);
    
    // output of solution for Amira visualization,
    // the data are written in binary format into file graph/aliev-slab-uv-###.am,
    // possible is also ascii
    #if HAVE_LIBAMIRA == 1
    using LeafView = typename Grid::LeafGridView;
    LeafView leafGridView = gridManager.grid().leafGridView();
    writeAMIRAFile(leafGridView,x,fn.str(),IoOptions());
    #endif

    if ( verbosity>0 ) 
    {
      std::cout << variableSet.degreesOfFreedom() << " values written to " << fn.str() << std::endl;
    }
    
  }
  std::cout << '\n';

  limex.reportTime(std::cout);

  if (!done)
    std::cout << "*** maxSteps reached ***\n";
  
  return x;
}
#endif
