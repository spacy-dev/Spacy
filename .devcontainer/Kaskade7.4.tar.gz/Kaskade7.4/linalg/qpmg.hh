/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2017-2020 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef QPMG_HH
#define QPMG_HH

#include <memory>
#include <tuple>

#include "dune/istl/bvector.hh"

#include "linalg/dynamicMatrix.hh"
#include "linalg/threadedMatrix.hh"
#include "mg/prolongation.hh"
#include "utilities/enums.hh"

namespace Kaskade
{

  /**
   * \ingroup qp
   * \brief An interface for gathering multigrid solver statistics.
   *
   * This interface provides also a trivial, i.e. do-nothing, implementation of
   * all virtual functions for entering values.
   */
  template <int d, class Real=double>
  class MGSolverStatistics
  {
  public:
    using VectorX = Dune::BlockVector<Dune::FieldVector<Real,d>>;

    ~MGSolverStatistics() {}

    virtual void enterPreSmoothingCorrection(int level, VectorX const& dx) {}
    virtual void enterCoarseGridCorrection(int level, VectorX const& dx) {}
    virtual void enterPostSmoothingCorrection(int level, VectorX const& dx) {}

    /**
     * \brief At the end of a V-cycle, specify the iteration number, the correction, and the resulting energy
     *        at the new iterate.
     * \param activeSetChanges the number of inequality constraints that changed their activity state in this iteration
     */
    virtual void enterVCycleCorrection(int iter, VectorX const& dx, Real energy, int activeSetChanges) {}
  };

  // ----------------------------------------------------------------------------------------------
  // ----------------------------------------------------------------------------------------------

  template <int d, class Prolongation, class Smoother, class Real=double>
  class QPMultiGridBase
  {
    using EntryA = Dune::FieldMatrix<Real,d,d>;
  public:
    using VectorX = Dune::BlockVector<Dune::FieldVector<Real,d>>;
    using VectorB = Dune::BlockVector<Dune::FieldVector<Real,1>>;
    using MatrixA = NumaBCRSMatrix<EntryA>;
    using MatrixB = NumaBCRSMatrix<Dune::FieldMatrix<Real,1,d>>;
    using Self = QPMultiGridBase<d,Prolongation,Smoother,Real>;

    /**
     * \brief Constructs the solver, providing the matrices \f$ A \f$ and \f$ B \f$.
     *
     * \param A the Hessian. The matrix is referenced internally and has to exist during the lifetime of the smoother.
     * \param B the constraints. The matrix is referenced internally and has to exist during the lifetime of the smoother.
     *
     * \param blocks
     *    - block=true: treat blocks of dof coupled by constraints jointly (default)
     *    - block=false: treat all dofs individually (only for testing and comparison purposes)
     *    \warning This is intended for testing purposes only and may be removed in future.
     */
    QPMultiGridBase(MatrixA A, MatrixB const& B, std::vector<Prolongation>&& prolongations,
                    Real smootherRegularization=0, bool blocks=true);

    /**
     * \brief Destructor.
     */
    virtual ~QPMultiGridBase();

    /**
     * \brief Computes a single V-cycle correction for approximately solving the QP for the given right hand side vectors.
     *
     * \param x initial guess for the solution
     * \param c linear objective term
     * \param b constant constraint term
     * \return the correction dx
     */
    VectorX step(VectorX const& x, VectorX c, VectorB b) const;

    /**
     * \brief Approximately solves the QP for the given right hand side vectors up to a given tolerance.
     *
     * \param x initial guess for the solution
     * \param c linear objective term
     * \param b constant constraint term
     * \param tol tolerance
     * \return a tuple \f$ (x,\mathrm{iter}) \f$ of solution vector, multiplier update, and iteration count
     */
    std::tuple<VectorX,int> solve(VectorX x, VectorX const& c, VectorB const& b, double tol, int vcycles) const;


    Self& setCoarseLevel(int coarselevel);
    Self& setSmoothings(int pre, int post);

    /**
     * \brief Sets the number of coarse corrections to compute and apply.
     *
     * \param n number of coarse corrections
     *
     * - n=0: just the smoother on the fine grid is performed, no multigrid at all (for testing purposes only).
     * - n=1: V-cycle (default)
     * - n=2: W-cycle
     */
    Self& setCoarseCorrections(int n);

    Self& setBulkMode(ParallelMode m);
    Self& setConstraintsMode(ParallelMode m);
    Self& setGlobalMode(ParallelMode m);

    /**
     * \brief Sets the logging facility for reporting solver statistics.
     *
     * \param logger a pointer to the logger object. This can be a nullpointer, in which case logging is stopped.
     *
     * Ownership of the logger object remains with the caller. The logger object
     * needs to exist for the lifetime of the QPMultiGrid class or until it is replaced
     * by a different logger (or none).
     */
    Self& setLogger(MGSolverStatistics<d,Real>* logger);

  protected:
    /**
     * \brief Compute the problem energy of current iterate for logging purposes.
     */
    virtual double computeEnergy(MatrixA const& A, MatrixB const& B,
                            VectorX const& c, VectorB const& b, VectorX const& x) const = 0;

    /**
     * \brief Compute the optimal step size in direction of dx.
     */
    virtual double qpLinesearch(MatrixA const& A, MatrixB const& B, VectorX const& c,
                                VectorB const& b, VectorX const& dx) const = 0;

    std::vector<Smoother> smoothers;

    /**
     * \brief Provides a reference to the fine grid constraints.
     */
    MatrixB const& B() const;

  private:
    /**
     * \brief Solves a (possibly penalized) QP problem by a multigrid V-cycle
     *
     * \param b upper bound for \f$ s \f$, has to be nonnegative (\f$ b\ge 0 \f$)
     *
     * \return the solution \f$ (x,s) \f$
     */
    VectorX mgRecursion(int level, int lpre, int lpost, VectorX c, VectorB b) const;

    MultiGridStack<Prolongation,EntryA,size_t> mgStackA;
    std::vector<MatrixB> mgStackB;

    mutable Real gamma;
    int coarseLevel = 0;
    int pre = 3;
    int post = 3;
    int mid = 1;

    std::unique_ptr<MGSolverStatistics<d,Real>> dummyLogger; // this dummy will be used if no other logger is given
    MGSolverStatistics<d,Real>* logger;
  };

  // ----------------------------------------------------------------------------------------------
  // ----------------------------------------------------------------------------------------------

  // forward declaration
  template <int d, class Real>
  class QPPenaltySmoother;



  /**
   * \ingroup qp
   * \brief A multigrid solver for convex QPs.
   *
   * This solves QPs of the form
   * \f[ \min \frac{1}{2} x^T A x + c^T x \quad \text{s.t.} \quad Bx\le b. \f]
   *
   * On the finest level, this works with the augmented Lagrangian formulation
   * \f[ \min \frac{1}{2} x^T A x + c^T x + \frac{\gamma}{2} \|(Bx-(b+\lambda/\gamma))_+\|^2  \f]
   * for some multiplier \f$ \lambda \le 0 \f$, and an appropriate multiplier update.
   *
   * The multilevel minimization works with level-dependent penalty factors. On each level, the
   * following computations (\f$\text{MGM}(A,B,x,c,b,\gamma)\f$ are performed:
   * - pre-smoothing: apply a block Jacobi smoother to the augmented Lagrangian.
   * - multiplier update (optional: is interleaving multigrid with multiplier updates a good idea?)
   * - coarse grid correction: compute residuals  \f$ c_r \f$ and \f$ b_r \f$ and compute a correction
   *   \f[ (\delta x, \delta \lambda) = \text{MGM}(P^TAP,BP,0,P^Tc_r,b_r,\gamma/4) \f]
   * - post-smoothing: apply correction to primal variable and multiplier and perform
   *   block Jacobi
   * - multiplier update
   *
   * Rationale: The level-dependence of the penalty factor is based on the following idea.
   * Enforcing the constraint by the penalty should allow sufficient slack such as not to
   * impede convergence of Gauß-Seidel. On coarser levels, GS is supposed to take larger steps
   * (the whole reason for multigrid) approximately by a factor of two for each grid level,
   * and so the penalty should increase the permitted steps by a factor of two as well.
   * This means decreasing the penalty factor by four.
   *
   * The restriction of multipliers is not necessary for asymptotically optimal complexity,
   * as the number of constraints is \f$ \mathcal{O}(N^{1-1/d}) \f$ and therefore the
   * computational work of a single V-cycle is \f$ \mathcal{O}(N + N^{1-1/d}\log N) = \mathcal{O}(N) \f$.
   * Nevertheless, restricting the constraints in an appropriate way (open how to do this) might
   * be beneficial for performance.
   */
  template <int d, class Prolongation, class Real=double>
  class QPMultiGrid
  : public QPMultiGridBase<d,Prolongation,QPPenaltySmoother<d,Real>,Real>
  {
    using EntryA = Dune::FieldMatrix<Real,d,d>;
    using Smoother = QPPenaltySmoother<d,Real>;
    using Base = QPMultiGridBase<d,Prolongation,Smoother,Real>;

  public:
    using VectorX = Dune::BlockVector<Dune::FieldVector<Real,d>>;
    using VectorB = Dune::BlockVector<Dune::FieldVector<Real,1>>;
    using MatrixA = NumaBCRSMatrix<EntryA>;
    using MatrixB = NumaBCRSMatrix<Dune::FieldMatrix<Real,1,d>>;
    using Self = QPMultiGrid<d,Prolongation,Real>;

    /**
     * \brief Constructs the solver, providing the matrices \f$ A \f$ and \f$ B \f$.
     *
     * \param A the Hessian. The matrix is copied internally and need not exist after solver construction.
     * \param B the constraints. The matrix is referenced internally and has to exist during the lifetime of the solver.
     *
     * \param blocks
     *    - block=true: treat blocks of dof coupled by constraints jointly (default)
     *    - block=false: treat all dofs individually (only for testing and comparison purposes)
     *    \warning This is intended for testing purposes only and may be removed in future.
     */
    QPMultiGrid(MatrixA const& A, MatrixB const& B, std::vector<Prolongation>&& prolongations,
                 Real smootherRegularization=0, bool blocks=true);

    /**
     * \brief Destructor.
     */
    ~QPMultiGrid();

    /**
     * \brief Approximately solves the QP for the given right hand side vectors up to a given tolerance.
     *
     * \param x initial guess for the solution
     * \param c linear objective term
     * \param b constant constraint term
     * \param lambda approximate multiplier
     * \param tol tolerance
     * \return a tuple \f$ (x,\delta\lambda,\mathrm{iter}) \f$ of solution vector, multiplier update, and iteration count
     */
    std::tuple<VectorX,VectorB,int> solve(VectorX x, VectorX const& c, VectorB const& b, VectorB const& lambda, double tol, int vcycles) const;

//     /**
//      * \brief A least-squares multiplier update.
//      *
//      * This can be used if a good initial guess for \f$ x \f$ is available, but not for \f$ \lambda \f$.
//      * A common situation where this is typically the case is finite strain contact mechanics, where the
//      * constraints and hence the multiplier changes with deformation, after having solved a QP linearization.
//      */
//     void leastSquaresMultiplierUpdate(VectorX const& c, VectorB const& b, VectorX const& x, VectorB& lambda) const;
//
//     void firstOrderMultiplierUpdate(VectorX const& c, VectorB const& b, VectorX const& x, VectorB& lambda) const;


    /**
     * \brief Sets the penalty factor \f$ \gamma \f$.
     *
     * The default on construction is \f$ \gamma = 10^3 \f$.
     */
    Self& setPenalty(Real gamma);


  protected:
    virtual double computeEnergy(MatrixA const& A, MatrixB const& B,
                            VectorX const& c, VectorB const& b, VectorX const& x) const;

    virtual double qpLinesearch(MatrixA const& A, MatrixB const& B, VectorX const& c,
                                VectorB const& b, VectorX const& dx) const;


  private:
    mutable Real gamma;
  };

  // ----------------------------------------------------------------------------------------------
  // ----------------------------------------------------------------------------------------------

  // forward declaration
  template <int d, class Real>
  class QPSmoother;

  template <int d, class Prolongation, class Real=double>
  class QPMultiGridStrict
  : public QPMultiGridBase<d,Prolongation,QPSmoother<d,Real>,Real>
  {
    using Smoother = QPSmoother<d,Real>;
    using Base = QPMultiGridBase<d,Prolongation,Smoother,Real>;

  public:
    using Self = QPMultiGridStrict<d,Prolongation,Real>;
    using typename Base::MatrixA;
    using typename Base::MatrixB;
    using typename Base::VectorX;
    using typename Base::VectorB;

    /**
     * \brief Constructs the solver, providing the matrices \f$ A \f$ and \f$ B \f$.
     *
     * \param A the Hessian. The matrix is copied internally and need not exist after solver construction.
     * \param B the constraints. The matrix is referenced internally and has to exist during the lifetime of the solver.
     *
     * \param blocks
     *    - block=true: treat blocks of dof coupled by constraints jointly (default)
     *    - block=false: treat all dofs individually (only for testing and comparison purposes)
     *    \warning This is intended for testing purposes only and may be removed in future.
     */
    QPMultiGridStrict(MatrixA const& A, MatrixB const& B, std::vector<Prolongation>&& prolongations,
                      Real smootherRegularization=0, bool blocks=true);

    /**
     * \brief Destructor.
     */
    ~QPMultiGridStrict();


  protected:
    virtual double computeEnergy(MatrixA const& A, MatrixB const& B,
                                 VectorX const& c, VectorB const& b, VectorX const& x) const;

    virtual double qpLinesearch(MatrixA const& A, MatrixB const& B, VectorX const& c,
                                VectorB const& b, VectorX const& dx) const;
  };
}

#endif
