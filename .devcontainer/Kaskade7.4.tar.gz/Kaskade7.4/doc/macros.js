MathJax.Hub.Config({
  TeX: {
    Macros: {
      R: "{\\mathbb{R}}"
    }
  }
});
