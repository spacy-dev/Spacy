/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2017-2019 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef CONTACTCONSTRAINTS
#define CONTACTCONSTRAINTS

#include <algorithm>
#include <limits>
#include <optional>

#include "dune/istl/bvector.hh"

#include "fem/boundaryLocator.hh"
#include "fem/quadrature.hh"
#include "linalg/threadedMatrix.hh"
#include "utilities/bezier.hh"

namespace Kaskade 
{
  /**
   * \ingroup contact
   * \brief Computes a single multibody contact point constraint.
   * 
   * For a given boundary point \f$ x \f$, the outer normal ray (in direction of the unit outer normal
   * vector \f$ n\f$) is tested for intersection with other boundary faces. More precisely, intersections
   * are considered on the ray \f$ \{ x+tn \mid t\in[-\mathrm{overlap},\infty\mathclose[\} \f$. Positive values
   * of overlap allow to detect contact partners in an infeasible, already overlapping configuration, which
   * is common for penalty methods or may arise due to nonlinearity.
   *
   * If an intersection is found at point \f$ y \f$, the (linearized) non-penetration condition for a displacement
   * \f$ \delta u \f$ is 
   * \f[ n^T (\delta u(x)-\delta u(y)) \le |x-y|. \f]
   * With a basis representation of \f$ \delta u = \sum_j \delta u_j \varphi_j\f$, this leads to a
   * scalar algebraic constraint of the form
   * \f[ \sum_j n^T(\varphi_j(x) -\varphi_j(y)) \delta u_j \le |x-y|. \f]
   * Let \f$ J(z) := \{ j\in \mathbf{N} \mid z \in \mathrm{supp}\varphi_j \} \f$ denote the dofs
   * associated to \f$ z \f$. The return value is the (optional) pair
   * \f[ \left( \{ (j,n^T(\varphi_j(x) -\varphi_j(y))) \mid j \in J(x)\cup J(y) \}, |x-y| \right), \f]
   * which can establish one row of a complete contact constraint of the form \f$ B\delta u \le g \f$.
   *
   * \return an optional pair (vector[(i,c)],g).
   *
   * In order to support nonlinear contact problems (with finite displacement), we consider an already 
   * deformed domain given in terms of a displacement \f$ u \f$, that is provided by the boundary locator.
   * This displacement \f$ u \f$ can, but need not be a finite element function.
   * 
   * \param space the FEFunctionSpace for which the constraints are to be computed
   * \param boundaryLocator a spatial index for looking up boundary intersections with rays
   * \param face the current boundary face
   * \param xi the local coordinate in the face
   * \param overlap states how far into the interior for an opposed face is searched.
   *                If `std::numeric_limits<double>::lowest()` is provided, a default value proportional to the
   *                cell diameter is chosen.
   */
  template <class Space, class Displacement>
  auto getContactConstraint(Space const& space,
                            BoundaryLocator<typename Space::GridView,Displacement> const& boundaryLocator,
                            typename Space::GridView::Intersection const& face,
                            Dune::FieldVector<typename Space::GridView::ctype,Space::GridView::Grid::dimension-1> const& xi,
                            double overlap)
  {
    using GridView = typename Space::GridView;
    using ctype = typename GridView::ctype;
    using RowEntry = Dune::FieldMatrix<ctype,1,GridView::Grid::dimension>;
    using EntryType = std::pair<size_t,RowEntry>;
    using ReturnType = std::optional<std::pair<std::vector<EntryType>,ctype>>;

    // Find intersections of faces with the ray starting at the given point and extending in normal direction.
    // In a Newton loop, the current configuration need not be feasible (i.e. without overlap / interpenetration).
    // Hence we pull back a little bit (on the order of a single element diameter) to detect a slight overlap as well.
    auto n = boundaryLocator.unitOuterNormal(face,xi);

    if(overlap == std::numeric_limits<double>::lowest())
    {
      ctype diameter = std::pow(face.inside().geometry().volume(),1.0/GridView::Grid::dimension);
      overlap = 0.0001*diameter;
    }
    auto intersection = boundaryLocator.byRay(boundaryLocator.global(face,xi)-overlap*n,n);
 
    if (!intersection)                  // no intersection found -> no constraint 
      return ReturnType();
    
    auto oface = std::get<0>(*intersection); // extract opposing boundary face and local point
    auto oxi = std::get<1>(*intersection);

    auto dofs  = space.linearCombination(face.inside(),face.geometryInInside().global(xi));
    auto odofs = space.linearCombination(oface.inside(),oface.geometryInInside().global(oxi));
    
    std::vector<EntryType> entries;

    RowEntry nt; nt[0] = n;             // normal as a row vector

    ctype const eps = std::numeric_limits<ctype>::epsilon();
    for (auto const& p: dofs)
      if (p.second.two_norm2() > 1e3*eps)                           // omit negligible contributions. Those are
        entries.push_back(std::make_pair(p.first,p.second[0]*nt));  // typically structurally zero, but have rounding errors
    for (auto const& p: odofs)
      if (p.second.two_norm2() > 1e3*eps)
        entries.push_back(std::make_pair(p.first,-p.second[0]*nt));
    
    auto x = boundaryLocator.global(face,xi);
    auto y = boundaryLocator.global(oface,oxi);
// std::cout << "Constraint found:\n";
// std::cout << "x          = " << x << "\n";
// std::cout << "x opposite = " << y << "\n";
// std::cout << "n          = " << n << "\n";
// std::cout << "gap        = " << (y-x)*n << "\n";

    // compute the gap distance (can be negative in case of interpenetration)
    return ReturnType(std::make_pair(entries,(y-x)*n));
  }

  /**
   * \ingroup contact
   * \brief Computes a single multibody contact point constraint.
   *
   * This version is for problems where each body is represented by its own grid.
   *
   * \param boundaryLocator1 boundary geometry for current point
   * \param boundaryLocator2 a spatial index for looking up boundary intersections with rays
   * \param face the current boundary face
   * \param xi the local coordinate in the face
   * \param overlap states how far into the interior for an opposed face is searched.
   * \param space1 the first grid's displacement FE-space with respect to which the contact constraint is to be computed.
   *        If no space is provided, only distance will be returned.
   * \param space1 the second grid's displacement FE-space with respect to which the contact constraint is to be computed
   * Negative value means search is only performed in the exterior with corresponding minimal distance.
   */
  template <class GridView1, class Displacement1, int dimw1, class GridView2, class Displacement2,  int dimw2>
  auto getContactConstraint(BoundaryLocator<GridView1,Displacement1,dimw1> const& boundaryLocator1,
                            BoundaryLocator<GridView2,Displacement2,dimw2> const& boundaryLocator2,
                            typename /*GridView::Intersection*/BoundaryLocator<GridView1,Displacement1,dimw1>::Face const& face,
//                             Dune::FieldVector<typename GridView::ctype,GridView::Grid::dimension-1> const& xi,
                            Dune::FieldVector<typename GridView1::ctype, dimw1-1> const& xi,
                            double overlap,
                            int which=0
                            /*,
                            typename Displacement::Space const* space1 = nullptr,
                            typename Displacement::Space const* space2 = nullptr */)
  {
    using ctype = typename GridView1::ctype;
    using RowEntry = Dune::FieldMatrix<ctype,1,dimw1>;
    using EntryType = std::pair<size_t,RowEntry>;
    using ReturnType = std::optional<std::tuple<std::vector<EntryType>,std::vector<EntryType>,ctype>>;

    constexpr int dim1 = GridView1::Grid::dimension;
    constexpr int dim2 = GridView2::Grid::dimension;
    
    // Find intersections of faces with the ray starting at the given point and extending in normal direction.
    // In a Newton loop, the current configuration need not be feasible (i.e. without overlap / interpenetration).
    // Hence we pull back a little bit (on the order of a single element diameter) to detect a slight overlap as well.
    auto n = boundaryLocator1.unitOuterNormal(face,xi,which);
    double volume;
    if constexpr(dim1==dimw1) volume = face.inside().geometry().volume(); //2D-2D or 3D-3D-contact: face is an intersection
    else                      volume = face.geometry().volume();          //2D grid in 3D world: face is a 2D cell
    ctype diameter = std::pow(volume,1.0/dim1);
    if(overlap == std::numeric_limits<double>::lowest()) 
      overlap = 0.0001*diameter;
        
    auto intersection = boundaryLocator2.byRay(boundaryLocator1.global(face,xi)-overlap*n,n);

    RowEntry nt; nt[0] = n;             // normal as a row vector

    if (!intersection)                  // no intersection found -> no constraint
      return ReturnType();

    //  auto oface = intersection->first;   // extract opposing boundary face and point
    //  auto oxi = intersection->second;
    auto oface = std::get<0>(intersection.value());
    auto oxi = std::get<1>(intersection.value());

    std::vector<EntryType> entries1;
    std::vector<EntryType> entries2;
    ctype const eps = std::numeric_limits<ctype>::epsilon();

    
    if constexpr(dim1==dimw1)
    {
      auto dofs  = boundaryLocator1.displacement()->space().linearCombination(face.inside(),face.geometryInInside().global(xi));
      for (auto const& p: dofs)
        if (p.second.two_norm2() > 1e3*eps)                           // omit negligible contributions. Those are
          entries1.push_back(std::make_pair(p.first,p.second[0]*nt));  // typically structurally zero, but have rounding errors
    }
    else
    {
      auto dofs  = boundaryLocator1.displacement()->space().linearCombination(face,xi/*face.geometry().global(xi)*/);
      for (auto const& p: dofs)
        if (p.second.two_norm2() > 1e3*eps)                           // omit negligible contributions. Those are
          entries1.push_back(std::make_pair(p.first,p.second[0]*nt));  // typically structurally zero, but have rounding errors
    }

    if constexpr(dim2==dimw2)
    {
      auto odofs = boundaryLocator2.displacement()->space().linearCombination(oface.inside(),oface.geometryInInside().global(oxi));
      for (auto const& p: odofs)
        if (p.second.two_norm2() > 1e3*eps)
          entries2.push_back(std::make_pair(p.first,-p.second[0]*nt));
    }
    else
    {
      auto odofs = boundaryLocator2.displacement()->space().linearCombination(oface,oxi/*oface.geometry().global(oxi)*/);
      for (auto const& p: odofs)
        if (p.second.two_norm2() > 1e3*eps)
          entries2.push_back(std::make_pair(p.first,-p.second[0]*nt));
    }

    
//    if(space1 && space2)
//    {
//      auto dofs  = space1->linearCombination(face.inside(),face.geometryInInside().global(xi));
//      auto odofs = space2->linearCombination(oface.inside(),oface.geometryInInside().global(oxi));

      
//    }
//    else
//    {
//      assert(!space1 && !space2);
//    }

    auto x = boundaryLocator1.global(face,xi);
    auto y = boundaryLocator2.global(oface,oxi);

    // compute the gap distance (can be negative in case of interpenetration)
    return ReturnType(std::make_tuple(entries1,entries2,(y-x)*n));
  }
  
  // ---------------------------------------------------------------------------------------------------------------
  // ---------------------------------------------------------------------------------------------------------------


  /**
   * \brief Abstract base class for computation of constraints from constraint samples.
   *
   * Let \f$ x \f$ denote the vector of displacements. On a boundary face, a set of \f$ n \f$
   * constraint samples is defined at local positions \f$ \xi_i \f$, leading to (pointwise)
   * nonpenetration conditions of the form
   * \f[ \sum_{k\in K_i} G_{ik} x_k \le g_i \f]
   * where \f$ g_i \f$ is the gap between opposing boundary points and \f$ G_i \f$ is the
   * impact of the displacements \f$ x_k \f$ on this gap.
   * Note that the entries \f$ x_k \f$ may be (column) vector-valued, and the corresponding
   * matrix entries \f$ G_{ik} \f$ are (row) vector-valued.
   *
   * Now the actual constraints of the form \f$ Bx \le b \f$ can be defined by certain
   * linear combinations of the pointwise constraints. Taking them one by one as they are
   * results in pointwise constraints (with Dirac weights),
   * \f[ Gx \le g, \f] see \ref DiracMortar. If the pointwise constraints are multiplied
   * by test functions \f$ \psi_j \f$ and integrated (summed) over the
   * boundary face, different constraints result (see, e.g., \ref BezierMortar):
   * \f[ \forall j: \quad \sum_{i\in I} \psi_j(\xi_i) \sum_{k\in K_i} G_{ik} x_k
   *                      \le \sum_{i\in I} \psi_j(\xi_i) g_i. \f]
   * In any case, linear inequalities of the form \f$ Bx \le b \f$ are defined.
   *
   * This class defines an interface for computing \f$ B \f$ and \f$ b \f$ from \f$ G \f$
   * and \f$ g \f$.
   */
  template <class Scalar, int dim>
  class Mortar
  {
  public:

    /**
     * \brief The type of matrix entries in the constraint matrix \f$ B \f$ in \f$ Bx \le b \f$.
     *
     * The entries are row vectors with the same length as the primal variable \f$ x \f$ entries.
     */
    using Entry = Dune::FieldMatrix<Scalar,1,dim>;
    using Row = std::vector<std::pair<size_t,Entry>>;

    virtual ~Mortar();

    /**
     * \brief The number of resulting constraints if `n` samples are provided.
     */
    virtual int size(int n) const = 0;

    /**
     * \brief Updates the given set of constraints (by \f$ B \f$ and \f$ b \f$) when a
     *        new constraint sample becomes available.
     *
     * This method needs to be implemented in derived classes.
     *
     * \param n The total number of samples that may be provided (actually there may be fewer, because
     *          some points may lack a contact partner).
     * \param xi The face-local coordinate of the current contact sample.
     * \param Gi A sparse representation of the matrix row \f$ G_i \f$.
     * \param gi The gap \f$ g_i \f$
     * \param B The sparse matrix \f$ B \f$ to be updated. The update process can modify values
     *          as well as change the shape of the matrix.
     * \param b The bounds vector \f$ b \f$
     *
     * If B and b are empty on entry, a new face is started. The containers
     * are resized as needed.
     */
    virtual void updateConstraints(int n, Dune::FieldVector<Scalar,dim-1> const& xi,
                                   Row& Gi, Scalar gi,
                                   std::vector<Row>& B, std::vector<Scalar>& b) const = 0;
  };

  /**
   * \brief Defines a constraint formulation where each sample is taken as a single constraint of its own.
   *
   * For a detailed description of the concept, see the base class \ref Mortar. This implementation
   * creates constraints that correspond one to one to the provided constraint samples, i.e. the
   * mortar test functions are Dirac functions located at the constraint sample points.
   */
  template <class Scalar, int dim>
  class DiracMortar: public Mortar<Scalar,dim>
  {
  public:
    using typename Mortar<Scalar,dim>::Row;

    /**
     * \brief The number of resulting constraints if `n` samples are provided.
     */
    virtual int size(int n) const { return n; }

    /**
     * \brief The
     */
    virtual void updateConstraints(int n, Dune::FieldVector<Scalar,dim-1> const& xi,
                                   Row& Gi, Scalar gi,
                                   std::vector<Row>& B, std::vector<Scalar>& b) const;
  };

  /// \cond internals
  namespace ContactConstraintsDetail
  {
    template <class Scalar, int dim>
    constexpr DiracMortar<Scalar,dim> const& defaultMortar();
  }
  /// \endcond

  /**
   * \brief Defines a constraint formulation where samples are weighted by Bezier test functions.
   *
   * For a detailed description of the concept, see the base class \ref Mortar.
   * Let \f$ g(x_i) \f$ denote the gap evaluated at sample point \f$ x_i \f$, \f$ i=1,\dots,N \f$.
   * With \f$ M \f$ Bezier functions \f$ B_k \f$ (depends on the Bezier order given), we obtain
   * \f$ M \f$ constraints \f[ \sum_{i=1}^N g(x_i) B_k(x_i) \ge 0. \f]
   */
  template <class Scalar, int dim>
  class BezierMortar: public Mortar<Scalar,dim>
  {
  public:
    using typename Mortar<Scalar,dim>::Row;

    /**
     * \brief Creates a Bezier mortar formulation of order `m`.
     */
    BezierMortar(int m);

    /**
     * \brief The number of resulting constraints if `m` samples are provided.
     */
    virtual int size(int n) const;

    /**
     * \brief The
     */
    virtual void updateConstraints(int n, Dune::FieldVector<Scalar,dim-1> const& xi,
                                   Row& vic, Scalar g,
                                   std::vector<Row>& rows, std::vector<Scalar>& bounds) const;
  private:
    int m;
  };

  /**
   * \ingroup contact
   * \brief Defines the sample-based contact constraint formulation.
   */
  struct MortarB
  {
    /**
     * \brief Defines the type of constraint formulation.
     */
    enum class Type { Dirac, Bezier };


    static constexpr MortarB dirac()
    {
      return MortarB{Type::Dirac,0};
    }

    static constexpr MortarB bezier(int order)
    {
      return MortarB{Type::Bezier,order};
    }

    Type type;
    int  mortarOrder;
  };

  // ----------------------------------------------------------------------------------------------


  /**
   * \ingroup contact
   * \brief Computes contact sample points on faces
   *
   * Equidistant contact sample points are computed.
   *
   * \param gt the type of face geometry, usually line or triangle (only those are supported right now)
   * \param nodesPerEdge the number of sample points per one-dimensional face subentity
   *
   * For lines (2D contact), \f$ n \f$ sample points are created, whereas for triangles (3D contact)
   * \f$ n(n+1)/2 \f$ points are created.
   *
   * \return a vector of sample points with associated (constant) weights
   */
  template <int dim>
  std::vector<Dune::QuadraturePoint<double,dim>> constraintPositions(Dune::GeometryType gt, int nodesPerEdge)
  {
    assert(nodesPerEdge>0);
    
    
    using QP = Dune::QuadraturePoint<double,dim>;
    std::vector<QP> pos;
    
    if (gt.isLine())
    {
      if (nodesPerEdge==1)
      {
        Dune::FieldVector<double,dim> p{0.5};                       // minimal number
        pos.push_back(QP(p,1.0));                                   // -> just center position
      }
      else
      {
        for (int i=0; i<nodesPerEdge; ++i)                          // otherwise equidistant grid on [0,1] including
        {                                                           // the end points
          Dune::FieldVector<double,dim> p{i/(nodesPerEdge-1.0)};    // equidistant positions
          double w = (i==0 || i+1==nodesPerEdge)? 0.5/(nodesPerEdge-1): 1.0/(nodesPerEdge-1); // and trapezoidal rule
          pos.push_back(QP(p,w));                                   // Newton-Cotes does not appear to be really beneficial
        }
      }
    }
    else if (gt.isTriangle())
    {
      if (nodesPerEdge==1)
      {   
        Dune::FieldVector<double,dim> p{1.0/3,1.0/3};               // minimal number of constraints per triangle
        pos.push_back(QP(p,1.0));                                   // -> just center position
      }
      else
      {
        double w = 2.0/(nodesPerEdge*(nodesPerEdge+1));
        for (int ix=0; ix<nodesPerEdge; ++ix)                       // otherwise equidistant cartesian grid of points
        {
          double x = ix/(nodesPerEdge-1.0);
          for (int iy=0; iy<nodesPerEdge-ix; ++iy)                  // with required number of points per edge
          {
            double y = iy/(nodesPerEdge-1.0);
            Dune::FieldVector<double,dim> p{x,y};
            pos.push_back(QP(p,w));                                 // and including the vertices (closed formula)
          }
        }
      }
    }
    else
    {
      std::cerr << "unsupported geometry type of face!\n";
      abort();
    }
    
    return pos;
  }
  
  /**
   * \ingroup contact 
   * \brief Computes a complete set of pointwise multibody contact constraints.
   * 
   * This computes a linear inequality constraint of the form \f$ B \delta u \le b \f$. If satisfied by
   * some small displacement \f$ \delta u \f$, this guarantees (up to linearization and discretization)
   * mutual nonpenetration and self-nonpenetration.
   * 
   * \param boundaryLocator the spatial index of boundary faces
   * \param pointsPerEdge the number of points per edge of the boundary face
   * \param overlap states how far into the interior for an opposed face is searched.
   *                If not given a default value (small positive value) will be chosen in dependence of the face size.
   * \param mortar the type of constraint agglomeration/averaging
   * \return a pair \f$ (B,b) \f$ of constraint matrix and right hand side
   *
   * \see getContactConstraint
   */
  template <class Space, class Displacement>
  auto getContactConstraints(Space const& space,
                             BoundaryLocator<typename Space::GridView,Displacement> const& boundaryLocator,
                             int pointsPerEdge, double overlap = std::numeric_limits<double>::lowest(),
                             Mortar<typename Space::GridView::ctype,Space::GridView::dimension> const& mortar = ContactConstraintsDetail::defaultMortar<typename Space::GridView::ctype,Space::GridView::dimension>())
  {
    using GridView = typename Space::GridView;
    using ctype = typename GridView::ctype;
    constexpr int dim = GridView::Grid::dimension;
    using Entry = Dune::FieldMatrix<ctype,1,dim>;
    using Row = std::vector<std::pair<size_t,Entry>>;
    
    std::vector<Row> rows, tmpRows;
    std::vector<ctype> bounds, tmpBounds;
    
    auto faces = boundaryLocator.faces();

    // In each quadrature point on a boundary face, look in normal direction and find the 
    // corresponding algebraic constraint.
    for (auto const& face: faces)
    {
      auto const qr = constraintPositions<dim-1>(face.geometry().type(),pointsPerEdge);
      auto volume = face.geometry().volume();
      tmpRows.clear();
      tmpBounds.clear();

      for (auto const& qp: qr)
      {
        auto const& xi = qp.position();
        auto c = getContactConstraint(space,boundaryLocator,face,xi,overlap); // find potential contact partner
        if (c)                                                                // there need not be any - then skip
        {
          ctype w = qp.weight()*volume;              // get the quadrature weight
          auto [vic,g] = *c;
          for (auto& p: vic)                         // and scale the constraint by this weight
            p.second *= w;
          g *= w;

          mortar.updateConstraints(qr.size(),xi,vic,g,tmpRows,tmpBounds);
        }
      }

     // Append the constraints of this face to the complete list of global constraints
     // TODO: This is inefficient. We could move the constraints instead of copying them.
     std::copy(begin(tmpRows),end(tmpRows),back_inserter(rows));
     std::copy(begin(tmpBounds),end(tmpBounds),back_inserter(bounds));
    }
    
    NumaCRSPatternCreator<> creator(rows.size(),space.degreesOfFreedom());
    for (size_t i=0; i<rows.size(); ++i)
      for (auto const& p: rows[i])
        creator.addElement(i,p.first);
      
    NumaBCRSMatrix<Entry> B(creator);
    for (size_t i=0; i<rows.size(); ++i)
      for (auto const& p: rows[i])
        B[i][p.first] += p.second;
      
    Dune::BlockVector<Dune::FieldVector<ctype,1>> b(bounds.size());
    std::copy(begin(bounds),end(bounds),begin(b));
    
    return std::make_pair(B,b);
  }

  /**
   * \ingroup contact
   * \brief Computes a complete pointwise twobody contact constraint.
   *
   * This version is for problems where each body is represented by its own grid.
   *
   * \param boundaryLocator1 the spatial index of boundary faces of first body/grid
   * \param boundaryLocator2 the spatial index of boundary faces of second body/grid
   * \param order the order of the quadrature rule that is used for selecting test points in the faces
   * \param overlap states how far into the interior for an opposed face is searched.
   * Negative value means search is only performed in the exterior with corresponding minimal distance.
   * If not given a default value (small positive value) will be chosen.
   * \param space1 if given contact constraints are computed with respect to this space, otherwise the space from boundaryLocator1 is used
   * \param space2 analogously to space1 but for the second grid
   * \return a three tuple \f$ (B1,B2,b) \f$ of constraint matrix blocks (belonging to grids) and right hand side
   */
  template <class GridView1, class Displacement1, int dimw1, class GridView2, class Displacement2, int dimw2, bool flattened=false>
  auto getContactConstraints(BoundaryLocator<GridView1,Displacement1,dimw1> const& boundaryLocator1,
                             BoundaryLocator<GridView2,Displacement2,dimw2> const& boundaryLocator2,
                             int order, double overlap = std::numeric_limits<double>::lowest(),
                             typename Displacement1::Space const* space1 = nullptr, typename Displacement2::Space const* space2 = nullptr)
  {
    constexpr int dim1 = GridView1::Grid::dimension;
    constexpr int dim2 = GridView2::Grid::dimension;
    constexpr int dimension_world = std::max(dimw1, dimw2);
    constexpr int dimension = std::min(dim1, dim2);
    
    using ctype = typename GridView1::ctype;
    constexpr int blockSize = flattened ? 1 : dimension_world;//GridView::Grid::dimension;
    constexpr int blocksPerNode = flattened ? /*GridView::Grid::dimension*/dimension_world : 1;
    using Entry = Dune::FieldMatrix<ctype,1,blockSize>;
    using Row = std::vector<std::pair<size_t,Dune::FieldMatrix<ctype,1,/*GridView::Grid::dimension*/dimension_world>>>;
    using QR = Dune::QuadratureRule<ctype,dimw1-1>;

    std::vector<Row> rows1;
    std::vector<Row> rows2;
    std::vector<ctype> bounds;

    auto faces = boundaryLocator1.faces();
    std::vector<typename BoundaryLocator<GridView1,Displacement1,dimw1>::Face> reducedFaces; //this is either an Intersection or a Cell
    QuadratureTraits<QR> quadratureRules;

    for (auto const& face: faces)
    {
      QR const& qr = quadratureRules.rule(face.geometry().type(),order);

      for (auto const& qp: qr)
      {
        auto const& xi = qp.position();
        auto c = getContactConstraint(boundaryLocator1,boundaryLocator2,face,xi,overlap/*,
                                      space1 ? space1 : &(boundaryLocator1.displacement()->space()),
                                      space2 ? space2 : &(boundaryLocator2.displacement()->space())*/);
        if (c)
        {
          rows1.push_back(std::get<0>(*c));
          rows2.push_back(std::get<1>(*c));
          bounds.push_back(std::get<2>(*c));
          reducedFaces.push_back(face);
        }
        
        if constexpr(dimension!=dimension_world)
        {
          // check second normal direction (0,0,1) and (0,0,-1)
          auto cc = getContactConstraint(boundaryLocator1,boundaryLocator2,face,xi,overlap, 1/*,
                                      space1 ? space1 : &(boundaryLocator1.displacement()->space()),
                                      space2 ? space2 : &(boundaryLocator2.displacement()->space())*/);
          if (cc)
          {
            rows1.push_back(std::get<0>(*cc));
            rows2.push_back(std::get<1>(*cc));
            bounds.push_back(std::get<2>(*cc));
            reducedFaces.push_back(face);
          }
        }
      }
    }

    NumaCRSPatternCreator<> creator1(rows1.size(),(space1 ? space1->degreesOfFreedom() : boundaryLocator1.displacement()->space().degreesOfFreedom())*blocksPerNode);
    for (size_t i=0; i<rows1.size(); ++i)
      for (auto const& p: rows1[i])
        for (int l=0; l<blocksPerNode; ++l)
          creator1.addElement(i,p.first*blocksPerNode+l);

    NumaBCRSMatrix<Entry> B1(creator1);
    for (size_t i=0; i<rows1.size(); ++i)
      for (auto const& p: rows1[i]) {
        if(!flattened) B1[i][p.first] = p.second;
        else
          for (int l=0; l<blocksPerNode; ++l)
            B1[i][p.first*blocksPerNode+l] = p.second[0][l];
      }

    NumaCRSPatternCreator<> creator2(rows2.size(),(space2 ? space2->degreesOfFreedom() : boundaryLocator2.displacement()->space().degreesOfFreedom())*blocksPerNode);
    for (size_t i=0; i<rows2.size(); ++i)
      for (auto const& p: rows2[i])
        for (int l=0; l<blocksPerNode; ++l)
          creator2.addElement(i,p.first*blocksPerNode+l);

    NumaBCRSMatrix<Entry> B2(creator2);
    for (size_t i=0; i<rows2.size(); ++i)
      for (auto const& p: rows2[i]) {
        if(!flattened) B2[i][p.first] = p.second;
        else
          for (int l=0; l<blocksPerNode; ++l)
            B2[i][p.first*blocksPerNode+l] = p.second[0][l];
      }

    Dune::BlockVector<Dune::FieldVector<ctype,1>> b(bounds.size());
    std::copy(begin(bounds),end(bounds),begin(b));

    return std::make_tuple(B1,B2,b,reducedFaces);
  }

  // ---------------------------------------------------------------------------------------------------------------
  // ---------------------------------------------------------------------------------------------------------------

  /**
   * \ingroup contact
   * \brief Computes the contact area for the first body.
   *
   *  The threshold value maxGap is not so easy to choose, maybe this is not the best way to compute the contact area.
   *
   * \param boundaryLocator1 the spatial index of boundary faces of first body/grid
   * \param boundaryLocator2 the spatial index of boundary faces of second body/grid
   * \param order the order of the quadrature rule that is used for selecting test points in the faces
   * \param overlap states how far into the interior for an opposed face is searched.
   *                Negative value means search is only performed in the exterior with corresponding minimal distance.
   *                If not given a default value (small positive value) will be chosen.
   * \param maxGap threshold value, distances below this value are treated as "in contact".
   * \return the area
   */
  template <class GridView, class Displacement>
  double getContactArea(BoundaryLocator<GridView,Displacement> const& boundaryLocator1,
                      BoundaryLocator<GridView,Displacement> const& boundaryLocator2,
                      int order, double overlap = std::numeric_limits<double>::lowest(),
                      double maxGap = 1e-4)
  {
    using ctype = typename GridView::ctype;
    using QR = Dune::QuadratureRule<ctype,GridView::Grid::dimension-1>;

    auto faces = boundaryLocator1.faces();
    QuadratureTraits<QR> quadratureRules;

    double area = 0.0;

    for (auto const& face: faces)
    {
      QR const& qr = quadratureRules.rule(face.geometry().type(),order);

      // usage of standard quadrature rule for integration of discontinuous contact area indicator function is maybe not the best idea, but its convenient
      for (auto const& qp: qr)
      {
        auto const& xi = qp.position();
        auto c = getContactConstraint(boundaryLocator1,boundaryLocator2,face,xi,overlap);

        if (c && std::get<2>(*c) < maxGap)
        {
          auto dupi = boundaryLocator1.displacement()->derivative(face.inside(), face.geometryInInside().global(xi));
          dupi += unitMatrix<ctype, GridView::Grid::dimension>();

          auto jt = face.geometry().jacobianTransposed(xi).rightmultiplyany(Dune::transpose(dupi));
          ctype intElem = std::sqrt(std::abs(determinant(jt.rightmultiplyany(Dune::transpose(jt)))));
          area += intElem * qp.weight();
        }
      }
    }

    return area;
  }

  // ---------------------------------------------------------------------------------------------------------------
  // ---------------------------------------------------------------------------------------------------------------

  /**
   * \ingroup contact 
   * \brief Computes a feasible step size for contact constraints.
   * 
   * The contact constraints as, e.g., obtained from \ref getContactConstraints, are linearized, in that they restrict 
   * the displacement of boundary points in \em normal direction. A solution of this linearized contact problem may 
   * be infeasible: other body parts may not have been detected as obstacles in normal direction, but now become relevant.
   * Taking a full step often leads to infeasible deformation states with considerable interpenetration. Reducing the 
   * stepsize appropriately, i.e. taking the largest possible step such that the configuration remains feasible not only 
   * in the linearized, but in the full nonlinear setting, is a promising way.
   * 
   * This function computes a feasible step size that is nearly optimal.
   * 
   * \tparam Displacement a finite element function type for representing volume displacements
   * \tparam BoundaryDisplacement a boundary displacement
   * 
   * \param u               the volume displacement, starting point for line search
   * \param boundaryLocator a spatial index for looking up ray-face intersections. Its internal boundary displacement
   *                        will be modified during the line search
   * \param direction       the step to be taken (linearized contact solution)
   * \param pointsPerEdge   the number of contact sample points per edge
   * \param trialStepSize   how aggressively the method goes ahead. 1=fast but with risk of ending up infeasible, 0=very slow but safe. 
   *                        In the range ]0,1[. Use smaller values for highly nonlinear problems with large displacements.
   * \param overlap         the amount of penetration to be accepted when looking backwards for contact
   */
  template <class Displacement, class BoundaryDisplacement>
  double contactLinesearch(Displacement const& u,
                           BoundaryLocator<typename Displacement::GridView,BoundaryDisplacement>& boundaryLocator,
                           Displacement const& direction,
                           int pointsPerEdge, double trialStepSize=0.1,
                           double overlap = std::numeric_limits<double>::lowest(),
                           double targetOverlap = 0,
                           Mortar<typename Displacement::ctype,Displacement::GridView::dimension> const& mortar =
                             ContactConstraintsDetail::defaultMortar<typename Displacement::ctype,Displacement::GridView::dimension>())
  {
    using GridView = typename Displacement::GridView;
    static_assert(GridView::dimensionworld==Displacement::components);
    assert(pointsPerEdge>=0);
    assert(targetOverlap<std::max(0.0,overlap) || (targetOverlap==0 && overlap==std::numeric_limits<double>::lowest()));
    
    double tmin = 0;        // current position on the full step [0,1].
    double tmax = 1;        // linear model predicts we can take a full step.

    
    assert(boundaryLocator.displacement());


    // Function for computing the minimal remaining gap depending on the
    // step size t we take in direction of the given displacement "direction".
    auto getGap = [&](double t)
    {
      // First get the constraints at the new trial point.
      auto uTrial = u;                                    // uTrial <- u + t*direction
      uTrial.axpy(t,direction);
      boundaryLocator.updateDisplacement(uTrial);         // build spatial index for new deformation
      auto Bb = getContactConstraints(u.space(),boundaryLocator,pointsPerEdge,overlap,mortar);  // get constraints B*dx <= b
      auto Bx(Bb.second); Bb.first.mv(direction.coefficients(),Bx);
      auto const& b = Bb.second;                          // the gap

      // Now step through all constraints and find, for each of them,
      // the maximal feasible step size.
      double gmin = std::numeric_limits<double>::max();
      double dg, taumax = gmin;
      for (int i=0; i<b.N(); ++i)
      {
        // Find the minimal gap
        if (b[i][0] < gmin)
        {
          gmin = b[i][0];
          dg = -Bx[i][0];
        }

        // Find the maximal allowed step size, i.e. max t s.t. (B*direction)[i]*t <= b[i]+targetOverlap.
        // This limits t only if (B*direction)[i] > 0 (otherwise the gap is increased, and we obtain a
        // (hopefully negative) minimal step size.
        if (Bx[i][0] > 0)
          taumax = std::min(taumax,(b[i][0]+targetOverlap)/Bx[i][0]);
      }

      return std::make_tuple(gmin,dg,taumax);
    };

    // step ahead until we find an infeasible step size.
    // This cannot be done in one step up to tmax, because e may overlook constraints.
    double const h = 0.1;
    while (tmin < 0.999*tmax)
    {
      double t = std::min(tmax,tmin+h);
      auto [g0,dg0,tau0] = getGap(t);
      if (g0 < -targetOverlap)
        break;
      else
        tmin = t;
    }

    if (tmin >= 0.999*tmax)
      return tmin;
    else
      tmax = std::min(tmax,tmin+h);

    while (tmax-tmin > std::min(1e-4,tmax/10))
    {
      double t = (tmax+tmin)/2;
      auto [g0,dg0,tau0] = getGap(t);
      if (g0 < -targetOverlap)
        tmax = t;
      else
        tmin = t;
    }

    return tmin;
  }
  
  /**
   * \ingroup contact
   * \brief Computes a feasible step size for contact constraints.
   *
   * The contact constraints as, e.g., obtained from \ref getContactConstraints, are linearized, in that they restrict
   * the displacement of boundary points in \em normal direction. A solution of this linearized contact problem may
   * be infeasible: other body parts may not have been detected as obstacles in normal direction, but now become relevant.
   * Taking a full step often leads to infeasible deformation states with considerable interpenetration. Reducing the
   * stepsize appropriately, i.e. taking the largest possible step such that the configuration remains feasible not only
   * in the linearized, but in the full nonlinear setting, is a promising way.
   *
   * This function computes a feasible step size that is nearly optimal.
   * 
   * This variant is using two BoundaryLocators to determine contact between objects
   * discretized with two individual grids.
   *
   * \tparam GridView1          the gridview of first object's FE space
   * \tparam Displacement1      a FunctionSpaceElement (first object)
   * \tparam dimw1              the world dimension of the first object
   * \tparam GridView2          the gridview of second object's FE space
   * \tparam Displacement2      a FunctionSpaceElement (second object)
   * \tparam dimw2              the world dimension of the second object
   *
   * \param boundaryLocator1    the spatial index for looking up ray-face intersections. Its displacement() method is supposed
   *                            to be the current displacement, the starting point of the step.
   * \param boundaryLocator2    the spatial index for looking up ray-face intersections. Its displacement() method is supposed
   *                            to be the current displacement, the starting point of the step.
   * \param direction1           the step to be taken by object 1 (linearized contact solution)
   * \param direction2           the step to be taken by object 2 (linearized contact solution)
   * \param order               the order of the quadrature rule that is used for selecting test points in the faces
   * \param trialStepSize       how aggressively the method goes ahead. 1=fast but with risk of ending up infeasible, 0=very slow but safe.
   *                            In the range ]0,1[. Use smaller values for highly nonlinear problems with large displacements.
   * \param overlap             the amount of infeasibility that is to be accepted.
   */
  template <class GridView1, class Displacement1, int dimw1, class GridView2, class Displacement2,  int dimw2>  
  double contactLinesearch(BoundaryLocator<GridView1,Displacement1,dimw1>& boundaryLocator1,
                           BoundaryLocator<GridView2,Displacement2,dimw2>& boundaryLocator2,
                           Displacement1 const& direction1, Displacement2 const& direction2,
//                            VectorType const& combinedDirection,
                           int order, double trialStepSize=0.1,
                           double overlap = std::numeric_limits<double>::lowest(),
                           double targetOverlap = 0
                          )
  {
    assert(order>=0);
    assert(0<trialStepSize && trialStepSize<1);
    assert(dimw1==dimw2);
    assert(targetOverlap<overlap || (targetOverlap==0 && overlap==std::numeric_limits<double>::lowest()));


    double tmin = 0;        // current position on the full step [0,1].
    double tmax = 1;        // linear model predicts we can take a full step.

    size_t nCoeff1 = direction1.coefficients().N();
    size_t nCoeff2 = direction2.coefficients().N();
    
    assert(boundaryLocator1.displacement());
    Displacement1 u1(*boundaryLocator1.displacement());
    assert(boundaryLocator2.displacement());
    Displacement2 u2(*boundaryLocator2.displacement());

    // For a general documentation of this lambda, compare the single-grid
    // contactLinesearch function above.
    auto getGap = [&](double t)
    {
      auto uTrial1 = u1;
      uTrial1.axpy(t,direction1);
      auto uTrial2 = u2;
      uTrial2.axpy(t,direction2);
      boundaryLocator1.updateDisplacement(uTrial1);                              // build spatial index for new deformation
      boundaryLocator2.updateDisplacement(uTrial2);                            
      auto Bb = getContactConstraints(boundaryLocator1, boundaryLocator2,order,overlap); // get constraints B*dx <= b
      
      auto const& B = horzcat(std::get<0>(Bb),std::get<1>(Bb));
      auto const& g = std::get<2>(Bb);
      typename Displacement1::StorageType combinedDirection(nCoeff1+nCoeff2);
      for(size_t i=0; i< nCoeff1; ++i) 
          combinedDirection[i]=direction1.coefficients()[i];
      for(size_t i=0; i< nCoeff2; ++i) 
          combinedDirection[i+nCoeff1]=direction2.coefficients()[i];
      
      auto Bx(g); B.mv(combinedDirection,Bx); Bx *= -1;

      double gmin = std::numeric_limits<double>::max();
      double dg, taumax = gmin;
      for (int i=0; i<g.N(); ++i)
      {
        if (g[i][0] < gmin)
        {
          gmin = g[i][0];
          dg = Bx[i][0];
        }
        if (Bx[i][0] < 0)
          taumax = std::min(taumax,-(g[i][0]+targetOverlap)/Bx[i][0]);
      }
      
      std::cout << "tau max: " << taumax << std::endl;

      return std::make_tuple(gmin,dg,taumax);
    };
    
    // step ahead until we find an infeasible step size.
    // This cannot be done in one step up to tmax, because e may overlook constraints.
    double const h = 0.1;
    while (tmin < 0.999*tmax)
    {
      double t = std::min(tmax,tmin+h);
      auto [g0,dg0,tau0] = getGap(t);
      if (g0 < -targetOverlap)
        break;
      else
        tmin = t;
    }

    if (tmin >= 0.999*tmax)
      return tmin;
    else
      tmax = std::min(tmax,tmin+h);

    while (tmax-tmin > std::min(1e-4,tmax/10))
    {
      double t = (tmax+tmin)/2;
      auto [g0,dg0,tau0] = getGap(t);
      if (g0 < -targetOverlap)
        tmax = t;
      else
        tmin = t;
    }

    return tmin;
    
//     while (t < 0.995*tmax)
//     {
//       u1.axpy(trialStepSize*(tmax-t),direction1); // move forward
//       boundaryLocator1.updateDisplacement(u1); // build spatial index for new deformation
//       u2.axpy(trialStepSize*(tmax-t),direction2);
//       boundaryLocator2.updateDisplacement(u2);
// 
//       auto Bb = getContactConstraints(boundaryLocator1, boundaryLocator2,order,2*overlap);
//       auto const& B = horzcat(std::get<0>(Bb),std::get<1>(Bb));
//       auto const& b = std::get<2>(Bb);
//       
//       typename Displacement1::StorageType combinedDirection(nCoeff1+nCoeff2);
//       for(size_t i=0; i< nCoeff1; ++i) 
//           combinedDirection[i]=direction1.coefficients()[i];
//       for(size_t i=0; i< nCoeff2; ++i) 
//           combinedDirection[i+nCoeff1]=direction2.coefficients()[i];
//       
//       auto Bx(b); B.mv(combinedDirection,Bx);
//       double tau = std::numeric_limits<double>::max();                    // find maximal tau such that
//       for (size_t i=0; i<b.N(); ++i)                                      // B*(tau*x) <= b+overlap
//         if (Bx[i][0]>0)
//           tau = std::min(tau,double((b[i][0]+overlap)/Bx[i][0]));
//       
//       std::cout << "tau = " << tau << "\n";
// 
//       // now the linear model from the previous position said we could go ahead for tmax-t. We took a
//       // step trialStepSize*(tmax-t), such that we should have (1-trialStepSize)*(tmax-t) to go.
//       // If the linear model was a good prediction, i.e. tau>(1-trialStepSize)*(tmax-t), we can increase
//       // trialStepSize.
//       // From the new point, we could go tau. Since we're closer to the target, tau should be a more
//       // accurate information of how far we can go.
//       double newTrialStepSize = tau>=(1-trialStepSize)*(tmax-t)? (1+trialStepSize)/2: trialStepSize;
//       t += trialStepSize*(tmax-t);
//       tmax = std::min(1.0,t+tau);
//       trialStepSize = newTrialStepSize;
//     }
// 
//     return t;
  } 
}

#endif
