/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2017-2017 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef BOUNDARYLOCATOR_HPP
#define BOUNDARYLOCATOR_HPP

#include <utility>
#include <vector>
#include <iterator>

#include <boost/geometry.hpp>
#include <boost/geometry/geometries/linestring.hpp>
#include <boost/geometry/geometries/point.hpp>
#include <boost/geometry/index/rtree.hpp>

#include "dune/common/fvector.hh"
// #include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"

#include "fem/boundaryLocator.hh"
#include "fem/fixdune.hh"
#include "fem/forEach.hh"
#include "fem/functional_aux.hh" // for <<
#include "fem/lagrangespace.hh"
#include "fem/spaces.hh"
#include "utilities/detailed_exception.hh"

namespace Kaskade
{
    namespace bg = boost::geometry;

    namespace BoundaryLocatorDetail
    {
        // convert Dune points to bg points. Adapting Dune::FieldVector as point type in bg
        // didn't work (for unknown reason)
        bg::model::point< double, 2, bg::cs::cartesian >
        bgPoint( Dune::FieldVector< double, 2 > const& p )
        {
            return bg::model::point< double, 2, bg::cs::cartesian >( p[ 0 ], p[ 1 ] );
        }
        bg::model::point< double, 3, bg::cs::cartesian >
        bgPoint( Dune::FieldVector< double, 3 > const& p )
        {
            return bg::model::point< double, 3, bg::cs::cartesian >( p[ 0 ], p[ 1 ], p[ 2 ] );
        }

        // Dummy implementation for FE function, just to be syntactically correct
        struct ZeroDisplacement
        {
            template < class Cell >
            int order( Cell const& ) const
            {
                return 0;
            }

            template < class Cell, class B >
            B value( Cell, B b ) const
            {
                return B( 0.0 );
            }

            template < class Cell, class B >
            Dune::FieldMatrix< typename B::field_type, B::dimension, B::dimension >
                derivative( Cell, B ) const
            {
                return 0.0;
            }
        };

        // ---------------------------------------------------------------------------------------------

        // This maps x -> x+u(x) and is the deformation function
        template < typename Face, typename Position, typename Function, int dimension,
                   int dimension_world >
        Position position( Face const& face, Position x, Function const* displacement )
        {
            static_assert( Position::dimension == dimension_world,
                           "Position::dimension has to be world dimension!" );

            if ( displacement )
            {
                if constexpr ( dimension == dimension_world ) // 2D-2D or 3D-3D contact
                    x += displacement->value( face.inside(), face.inside().geometry().local( x ) );
                else // dimension is 2D (midsurface), displacement is 3D
                     // x has to have world dimension (3D)
                     // in this case, face is a cell and has no inside
                {
                    Dune::FieldVector< double, dimension > xred = { x[ 0 ], x[ 1 ] };
                    x += displacement->value( face, face.geometry().local( xred ) );
                }
                // TODO: consider using an evaluator explicitly when stepping through the corners
            }
            return x;
        }

        // This maps y=x+u(x) -> x and is the inverse function of the deformation
        template < typename Face, typename Position, typename Function, int dimension,
                   int dimension_world >
        std::optional< Position > invPosition( Face const& face, Position y,
                                               Function const* displacement )
        {
            static_assert( Position::dimension == dimension_world,
                           "Position::dimension has to be world dimension!" );

            std::optional< Position > retVal;

            if ( !displacement ) // If a zero displacement is given, any boundary point remains at
                                 // its
            {                    // position.
                retVal = y;
                return retVal;
            }

            // Otherwise, perform a few Newton iteration for solving F(x) = x+u(x)-y = 0, starting
            // at the face center
            auto x = face.geometry().center();

            // rough estimate of face size, to scale tolerance
            typename Position::field_type fs =
                ( face.geometry().center() - face.geometry().corner( 0 ) ).two_norm();
            bool converged = false;

            bool isLinear; // Whether the displacement is linear or not
            if constexpr ( dimension ==
                           dimension_world ) // Linear displacements simplify the Newton
                isLinear = displacement->order( face.inside() ) <= 1; // iteration considerably :)
            else
                isLinear = displacement->order( face ) <= 1;

            for ( int ni = 0; ni < 10 && !converged; ++ni )
            {
                if constexpr ( dimension == dimension_world ) // 2D-2D or 3D-3D contact
                {
                    auto xi = face.inside().geometry().local( x );
                    auto u = displacement->value( face.inside(), xi );
                    auto du = displacement->derivative( face.inside(), xi );
                    // TODO: consider using an evaluator explicitly when stepping through the
                    // corners

                    auto F = x + u - y;
                    auto dF = unitMatrix< typename Position::field_type, dimension >() + du;
                    Position dx;
                    dF.solve( dx, -F );

                    x += dx;
                    converged = dx.two_norm() < 1e-6 * fs;
                }
                else
                {
                    auto xi = face.geometry().local( x );
                    auto u = displacement->value( face, xi );
                    auto du = displacement->derivative( face, xi );
                    Dune::FieldVector< double, dimension_world > xext = { x[ 0 ], x[ 1 ], 0.0 };

                    auto F = xext + u - y;
                    Dune::FieldMatrix< double, dimension, dimension_world > dF( 0 );
                    dF[ 0 ][ 0 ] = 1.0;
                    dF[ 1 ][ 1 ] = 1.0;
                    dF += du;
                    auto dx = x;
                    dx = 0;
                    dF.solve( dx, -F );

                    x += dx;
                    converged = dx.two_norm() < 1e-6 * fs;
                }

                // for linear displacement we need only one iteration and know that we're converged
                if ( isLinear )
                    converged = true;
            }

            if ( converged )
            {
                if constexpr ( dimension == dimension_world )
                    retVal = x;
                else
                    retVal = Position{ x[ 0 ], x[ 1 ], 0 };
            }

            return retVal;
        }

        // this maps n -> n + du(x)n and is the derivative of position
        // Note that due to shearing, boundary normals need not be mapped to normals of the deformed
        // boundary! If the deformed boundary's normal is required, transform the tangential vectors
        // with this function according to the deformation, and take the orthognoal complement of
        // their span.
        template < typename Face, typename Position, typename Function, int dimension,
                   int dimension_world >
        Position direction( Face const& face, Position x, Position n, Function const* displacement )
        {
            if ( displacement )
            {
                if constexpr ( dimension == dimension_world )
                {
                    auto xi = face.inside().geometry().local( x );
                    n += displacement->derivative( face.inside(), xi ) * n;
                    // TODO: consider using an evaluator explicitly when stepping through the
                    // corners
                }
                else
                {
                    Dune::FieldVector< double, dimension > xred = { x[ 0 ], x[ 1 ] },
                                                           nred = { n[ 0 ], n[ 1 ] };
                    n += displacement->derivative( face, face.geometry().local( xred ) ) *
                         nred; // du is 3x2 matrix
                }
            }
            return n;
        }

        // ---------------------------------------------------------------------------------------------

        template < class GridView, int dimw = GridView::Grid::dimension >
        struct SpatialIndex
        {
            //       using Face = typename GridView::Intersection;
            static int const dimension = GridView::Grid::dimension; // Face::dimensionworld;
            static int const dimension_world = dimw;
            using Face =
                std::conditional_t< dimension == dimension_world, typename GridView::Intersection,
                                    typename GridView::template Codim< 0 >::Entity >;
            using ctype = typename GridView::ctype;
            using Position = Dune::FieldVector< ctype, dimension_world >;
            using Point = bg::model::point< double, dimension_world, bg::cs::cartesian >;
            using Box = bg::model::box< Point >;
            using Value = std::pair< Box, Face >;
            using RTree = bg::index::rtree< Value, bg::index::rstar< 8 > >; // is 8 a good value?

            RTree tree;

            ctype diameter() const
            {
                auto box = tree.bounds();
                return bg::distance( box.max_corner(), box.min_corner() );
            }
        };
    } // namespace BoundaryLocatorDetail

    // ---------------------------------------------------------------------------------------------------
    // ---------------------------------------------------------------------------------------------------

    template < class GridView, class Function, int dimw >
    BoundaryLocator< GridView, Function, dimw >::BoundaryLocator( GridView const& gridView )
        : spatialIndex( new BoundaryLocatorDetail::SpatialIndex< GridView, dimw > )
    {
        init( gridView, std::vector< bool >() );
    }

    template < class GridView, class Function, int dimw >
    BoundaryLocator< GridView, Function, dimw >::BoundaryLocator(
        GridView const& gridView, std::vector< bool > const& boundarySegments )
        : spatialIndex( new BoundaryLocatorDetail::SpatialIndex< GridView, dimw > )
    {
        init( gridView, boundarySegments );
    }

    template < class GridView, class Function, int dimw >
    void
    BoundaryLocator< GridView, Function, dimw >::init( GridView const& gridView,
                                                       std::vector< bool > const& boundarySegments )
    {
        using namespace BoundaryLocatorDetail;

        ScopedTimingSection constructorTiming( "boundary locator construction" );

        if ( !boundarySegments.empty() &&
             ( boundarySegments.size() != gridView.grid().numBoundarySegments() ) )
        {
            throw Kaskade::DetailedException( "Boundary segments vector has wrong length.",
                                              __FILE__, __LINE__ );
        }

        auto& timer = Timings::instance();
        timer.start( "boundary faces" );

        // TODO: parallelize this using cell ranges (around 10% of constructor time)
        std::vector< Face > fs;
        if constexpr ( dimension == dimension_world )
        {
            forEachBoundaryFace( gridView, [ & ]( auto const& face ) {
                if ( face.neighbor() ) // on periodic boundary
                    return;            // - ignore
                if ( !boundarySegments.empty() && !boundarySegments[ face.boundarySegmentIndex() ] )
                    return;

                fs.push_back( face );
            } );
        }
        else
        {
            // nothing to skip here, enter all cells
            forEachCell( gridView, [ & ]( auto const& face ) { fs.push_back( face ); } );
        }
        timer.stop( "boundary faces" );

        enterFaces( fs );
    }

    template < class GridView, class Function, int dimw >
    BoundaryLocator< GridView, Function, dimw >::~BoundaryLocator()
    {
    }

    // ----------------------------------------------------------------------------------------------

    template < class GridView, class Function, int dimw >
    void BoundaryLocator< GridView, Function, dimw >::enterFaces( std::vector< Face > const& fs )
    {
        using namespace BoundaryLocatorDetail;
        using Index = SpatialIndex< GridView, dimw >;
        using Box = typename Index::Box;
        using Value = typename Index::Value;

        auto& timer = Timings::instance();

        timer.start( "clearing tree" );
        spatialIndex->tree.clear(); // remove old displaced faces from spatial index
        timer.stop( "clearing tree" );

        std::vector< Value > boxes;

        timer.start( "boundary face bounding boxes" );
        // TODO: parallelize this. Amounts to 50-60% of construction time.
        for ( Face const& face : fs )
        {
            // compute bounding box (assuming the face is essentially convex - to be a bit more
            // on the safe side in case the displacement is non-affine we consider the face center,
            // too)
            auto coor = face.geometry().center();
            Position pos;
            if constexpr ( dimension == dimension_world )
            {
                pos = coor;
            }
            else
            {
                pos = { coor[ 0 ], coor[ 1 ], 0.0 };
            }

            Position minCorner = position< Face, Position, Function, dimension, dimension_world >(
                face, pos, f.get() );
            Position maxCorner = minCorner;
            for ( int i = 0; i < face.geometry().corners(); ++i )
            {
                auto coor = face.geometry().corner( i );
                if constexpr ( dimension == dimension_world )
                {
                    pos = coor;
                }
                else
                {
                    pos = { coor[ 0 ], coor[ 1 ], 0.0 };
                }
                Position x = position< Face, Position, Function, dimension, dimension_world >(
                    face, pos, f.get() );
                minCorner = min( minCorner, x );
                maxCorner = max( maxCorner, x );
            }

            boxes.push_back( Value( Box( bgPoint( minCorner ), bgPoint( maxCorner ) ), face ) );
        }
        timer.stop( "boundary face bounding boxes" );

        // insert all bounding boxes together with their faces into the spatial index
        timer.start( "constructing spatial index" );
        spatialIndex->tree.insert( boxes );
        timer.stop( "constructing spatial index" );

        diam = spatialIndex->diameter();
    }

    template < class GridView, class Function, int dimw >
    typename BoundaryLocator< GridView, Function, dimw >::IntersectionSet
    BoundaryLocator< GridView, Function, dimw >::getIntersectingFaces( Position const& from,
                                                                       Position const& to,
                                                                       ctype minAngle ) const
    {
        using namespace BoundaryLocatorDetail;
        using Point = bg::model::point< ctype, dimension, bg::cs::cartesian >;
        //     using Position = Dune::FieldVector<ctype,dimension>;

        // extract all faces from the spatial index whose bounding boxes intersect the given line
        // segment
        bg::model::linestring< Point > segment{ bgPoint( from ), bgPoint( to ) };
        std::vector< typename BoundaryLocatorDetail::SpatialIndex< GridView, dimw >::Value >
            intersectingFaces;
        spatialIndex->tree.query( bg::index::intersects( segment ),
                                  std::back_inserter( intersectingFaces ) );

        // Note that the found faces are just those whose bounding box
        // intersects the line segment. We filter those which actually intersect the line
        // parametrized over [0,1].
        IntersectionSet result;
        Position direction = to - from;
        auto length = direction.two_norm();
        direction /= length;

        for ( auto const& value : intersectingFaces )
        {
            // Find the intersection of the line segment with the tangent plane at the face center.
            // The intersection point is then translated into local coordinates.
            Face const& face = value.second;

            auto coor = face.geometry().center();
            Position pos;
            if constexpr ( dimension == dimension_world )
                pos = coor;
            else
                pos = { coor[ 0 ], coor[ 1 ], 0.0 };

            //       Position x = position(face,face.geometry().center(),f);
            Position x = position< Face, Position, Function, dimension, dimension_world >(
                face, pos, f.get() );
            for ( int i = 0; i <= 1; i++ )
            {
                Position n =
                    unitOuterNormal( face, face.geometry().local( face.geometry().center() ), i );

                double q = n * direction; // >0 if the line leaves the domain
                double tau =
                    ( n * ( x - from ) ) /
                    ( q *
                      length ); // intersection parameter where the face tangent plane intersects
                if ( 0 <= tau && tau <= 1 &&
                     q <= minAngle ) // consider only faces that have a chance to intersect
                {
                    auto y =
                        ( 1 - tau ) * from + tau * to; // compute global coordinate of intersection
                    auto invPos =
                        invPosition< Face, Position, Function, dimension, dimension_world >(
                            face, y, f.get() );

                    if ( invPos ) // only if an intersection point has been found...
                    {
                        auto const& refElem =
                            Dune::ReferenceElements< ctype, dimension_world - 1 >::general(
                                face.geometry().type() );
                        if constexpr ( dimension == dimension_world )
                        {
                            auto yi =
                                face.geometry().local( *invPos ); // ... and face-local coordinate
                                                                  // is inside the reference element
                            if ( refElem.checkInside( yi ) )      // ok, segment intersects face
                                result.push_back( std::make_tuple( face, yi, tau, q ) );
                        }
                        else
                        {
                            auto yi = face.geometry().local(
                                { *invPos[ 0 ], *invPos[ 1 ] } ); // ... and face-local coordinate
                            if ( refElem.checkInside( yi ) )      // ok, segment intersects face
                                result.push_back( std::make_tuple( face, yi, tau, q ) );
                        }
                    }
                }

                if constexpr ( dimension == dimension_world )
                    break;
            }
        }

        return result;
    }

    template < class GridView, class Function, int dimw >
    std::optional< std::tuple< typename BoundaryLocator< GridView, Function, dimw >::Face,
                               typename BoundaryLocator< GridView, Function, dimw >::LocalPosition,
                               typename GridView::ctype > >
    BoundaryLocator< GridView, Function, dimw >::byLineSegment(
        typename BoundaryLocator::Position const& from,
        typename BoundaryLocator::Position const& to, ctype minAngle ) const
    {
        // extract all faces from the spatial index which intersect the given line segment and the
        // line enters the domain
        auto intersectingFaces = getIntersectingFaces( from, to, minAngle );

        // Find the closest intersection.
        std::optional< std::tuple< Face, LocalPosition, ctype > > retval;

        auto it = std::min_element( begin( intersectingFaces ), end( intersectingFaces ),
                                    []( auto const& fa, auto const& fb ) {
                                        return std::get< 2 >( fa ) < std::get< 2 >( fb );
                                    } );
        if ( it != end( intersectingFaces ) )
            retval =
                std::make_tuple( std::get< 0 >( *it ), std::get< 1 >( *it ), std::get< 3 >( *it ) );

        return retval;
    }

    template < class GridView, class Function, int dimw >
    typename BoundaryLocator< GridView, Function, dimw >::Position
    BoundaryLocator< GridView, Function, dimw >::global( Face const& face,
                                                         LocalPosition const& xi ) const
    {
        if constexpr ( dimension == dimension_world )
            return BoundaryLocatorDetail::position< Face, Position, Function, dimension,
                                                    dimension_world >(
                face, face.geometry().global( xi ), f.get() );
        else
        {
            auto x = face.geometry().global( xi );
            Position xext{ x[ 0 ], x[ 1 ], 0.0 };
            return BoundaryLocatorDetail::position< Face, Position, Function, dimension,
                                                    dimension_world >( face, xext, f.get() );
        }
    }

    template < class GridView, class Function, int dimw >
    typename BoundaryLocator< GridView, Function, dimw >::Position
    BoundaryLocator< GridView, Function, dimw >::unitOuterNormal( Face const& face,
                                                                  LocalPosition const& xi,
                                                                  int which ) const
    {
        using namespace BoundaryLocatorDetail;

        Dune::FieldVector< ctype, dimension_world > n, x;

        if constexpr ( dimension == dimension_world )
        {
            x = face.geometry().global( xi );
            n = face.outerNormal( xi );
        }
        else
        {
            auto xtmp = face.geometry().global( xi );
            x = { xtmp[ 0 ], xtmp[ 1 ], 0.0 };
            if ( which == 0 )
                n = { 0.0, 0.0, 1.0 };
            else
                n = { 0.0, 0.0, -1.0 };
        }
        std::array< Dune::FieldVector< ctype, dimension_world >, dimension_world - 1 > ts;

        // This is the original code by Martin which is not general enough to compute the tangents
        // to n (at least in 3D)
        //    for (int i=0; i<dimension-1; ++i)
        //    {
        //      ts[i] = n;                          // obtain normal
        //      ctype a = ts[i][i+1];               // turn it by 90 degrees
        //      ctype b = -ts[i][0];                // in the 0-(i+1) plane
        //      ts[i][0]   = a;
        //      ts[i][i+1] = b;
        //      ts[i] = direction(face,x,ts[i],f);  // transform the tangent vector according to
        //      deformation
        //    }

        // instead we can do the following
        if ( dimension_world == 2 )
        {
            ts[ 0 ][ 0 ] = n[ 1 ]; // just turn normal by 90 degrees
            ts[ 0 ][ 1 ] = -n[ 0 ];
            ts[ 0 ] = direction< Face, Position, Function, dimension, dimension_world >(
                face, x, ts[ 0 ],
                f.get() ); // transform the tangent vector according to deformation
        }
        if ( dimension_world == 3 )
        {
            // This computes tangents by householder transformation as described in
            // "Tangent vectors to a 3-D surface normal: A geometric tool to find orthogonal vectors
            // based on the Householder transformation"
            // https://www.researchgate.net/publication/235733679
            ctype nn = n.two_norm();
            auto h = n;
            h[ 0 ] = std::max( n[ 0 ] - nn, n[ 0 ] + nn );
            ts[ 0 ][ 0 ] = h[ 0 ] * h[ 1 ];
            ts[ 0 ][ 1 ] = h[ 1 ] * h[ 1 ];
            ts[ 0 ][ 2 ] = h[ 1 ] * h[ 2 ];
            ts[ 1 ][ 0 ] = h[ 0 ] * h[ 2 ];
            ts[ 1 ][ 1 ] = ts[ 0 ][ 2 ];
            ts[ 1 ][ 2 ] = h[ 2 ] * h[ 2 ];
            ctype h2 = h[ 0 ] * h[ 0 ];
            h2 += ts[ 0 ][ 1 ];
            h2 += ts[ 1 ][ 2 ];
            h2 = -2 / h2;
            ts[ 0 ] *= h2;
            ts[ 0 ][ 1 ] += 1;
            ts[ 1 ] *= h2;
            ts[ 1 ][ 2 ] += 1;
            ts[ 0 ] = direction< Face, Position, Function, dimension, dimension_world >(
                face, x, ts[ 0 ],
                f.get() ); // transform the tangent vector according to deformation
            ts[ 1 ] = direction< Face, Position, Function, dimension, dimension_world >(
                face, x, ts[ 1 ], f.get() );
        }

        if ( dimension_world == 2 )
        {
            n[ 0 ] = -ts[ 0 ][ 1 ]; // rotate the tangent vector back
            n[ 1 ] = ts[ 0 ][ 0 ];  // taking care to produce an *outer* normal
        }
        else if ( dimension_world == 3 )
        {
            Dune::FieldVector< ctype, dimension_world > n3;
            n3 << vectorProduct( ts[ 0 ],
                                 ts[ 1 ] ); // take the cross product (TODO use constexpr if)
            if ( direction< Face, Position, Function, dimension, dimension_world >( face, x, n,
                                                                                    f.get() ) *
                     n3 <
                 0 )     // and make sure we're pointing outwards
                n = -n3; // this is the case if we point to the same side as
            else         // the transformed normal vector (which may be skewed)
                n = n3;
        }
        static_assert( 2 <= dimension_world && dimension_world <= 3,
                       "boundary locator only defined for 2D and 3D" );
        return n / n.two_norm(); // return the *unit* outer normal vector
    }

    template < class GridView, class Function, int dimw >
    std::vector< typename BoundaryLocator< GridView, Function, dimw >::Face >
    BoundaryLocator< GridView, Function, dimw >::faces() const
    {
        std::vector< Face > fs;
        fs.reserve( spatialIndex->tree.size() );

        std::transform( spatialIndex->tree.begin(), spatialIndex->tree.end(), back_inserter( fs ),
                        [ & ]( auto const& value ) { return value.second; } );
        return fs;
    }

} // namespace Kaskade

#endif
