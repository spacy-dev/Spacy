/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2019-2019 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#ifndef GRIDBASICS_HH_
#define GRIDBASICS_HH_

namespace Kaskade
{
  /**
   * \ingroup grid
   * \brief The type of cells (entities of codimension 0) in the grid view.
   */
  template <class GridView>
  using Cell = typename GridView::template Codim<0>::Entity;

  /**
   * \ingroup grid
   * \brief The type of global positions within the grid view.
   * \tparam GridView a grid view type (a grid type works as well)
   */
  template <class GridView>
  using GlobalPosition = Dune::FieldVector<typename GridView::ctype,GridView::dimensionworld>;

  /**
   * \ingroup grid
   * \brief The type of local positions within the grid view.
   * \tparam GridView a grid view type (a grid type works as well)
   */
  template <class GridView>
  using LocalPosition = Dune::FieldVector<typename GridView::ctype,GridView::dimension>;

  // ----------------------------------------------------------------------------------------------


}

#endif
