# Release notes for Kaskade 7.4

## Installation
1. To install required third party libraries, do one of the following:
   - use the new installer scripts from InstallDependencies directory
   - rely on the central ZIB installation
2. Edit Makefile.Local to fit your needs
3. Type "make all" - this will build library and documentation, and perform the tests

## Dependencies
- A new and simplified installer script is available.

### Third party libraries
The following libraries are used:

- Dune 2.6 with git version of dune-alugrid
- SuiteSparse 5.3
- MUMPS 5.1.2
- ITSOL 2
- Hypre 2.11.2
- FP from git


### Environment
- A C++17-capable compiler is required.
- GCC 8.2 can be installed by installer script

## Build system
- The structure of the makefiles has been changed towards a non-recursive make structure.
- Per-source dependency management provides more accurate dependency information and
  eliminates the need for calling "make depend".
- Due to path issues with symlinked NFS file systems, tools/remove_install_deps does require 
  the second argument now.
- For better dependency checking, library member object files are updated individually.
  This means that *parallel make invocations are not safe*. Avoid make -j.

## C++ language standard
- C++17 is the standard for Kaskade 7.4
- use constexpr if when defining variational functionals in systems with variables of different dimension
