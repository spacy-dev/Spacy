#ifndef CT_H
#define CT_H

#include <vector>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <string>
#include <map>
#include <experimental/filesystem>
#include <ctime>

#include <boost/program_options.hpp>

using namespace boost::program_options;
namespace fs = std::experimental::filesystem;


enum Style
{
	S1,
	S2,
	S3,
	S4,
	S5,
	S6,
	S7,
	S8,
	S9
};


class ConsoleTable
{
public:

	ConsoleTable(std::initializer_list<std::string> list) : padsize{1}, linetype{S1},
	                                                        innerlines(false), precision(4),
	                                                        header(list)
	{
		updateWidths(header); //function that stores the sizes of the longest string in each column.	
	}

	ConsoleTable(variables_map& vm, options_description& desc) : padsize{1}, linetype{S1},
	                                                             innerlines(false), precision(4),
	                                                             vm_(vm), desc_(desc)
	{
		header = {"Name", "Value", "Description"};
		updateWidths(header);
		std::vector<std::string> tmp;
		
		for (auto& it : vm_)
		{
			tmp.push_back(it.first);
			
			auto option = desc_.options();
			std::string description;
			for (const auto & descIt : option )
			{
				if(it.first == descIt->long_name())
				{
					description = descIt->description();
				}
			}
			
			if (static_cast<boost::any>(it.second.value()).type() == typeid(int))
			{
				tmp.push_back(std::to_string(vm[it.first].as<int>()));
			}
			else if (static_cast<boost::any>(it.second.value()).type() == typeid(bool))
			{
				tmp.push_back(std::to_string(vm[it.first].as<bool>()));
			}
			else if (static_cast<boost::any>(it.second.value()).type() == typeid(double))
			{
				std::stringstream sstream;
				sstream << std::setprecision(precision) << vm[it.first].as<double>();
				tmp.push_back(sstream.str());
			}
			else if (static_cast<boost::any>(it.second.value()).type() == typeid(std::string))
			{
				tmp.push_back(vm[it.first].as<std::string>());
			}

			for (unsigned int i = 0; i < tmp.size(); ++i)
			{
				widths[i] = std::max(tmp[i].size(), widths[i]);
			}
			
			tmp.push_back(description);
			rows.push_back(tmp);
			tmp.clear();
		}
	};

	// OPERATOR
	ConsoleTable& operator+=(std::initializer_list<std::string> row)
	{
		if (row.size() > widths.size())
		{
			throw std::invalid_argument{"appended row size must be same as header size"};
		}
		std::vector<std::string> r = std::vector<std::string>{row};
		rows.push_back(r);
		for (std::size_t i{0}; i < r.size(); ++i)
		{
			widths[i] = std::max(r[i].size(), widths[i]);
		}
		return *this;
	}

	friend std::ostream& operator<<(std::ostream& os, ConsoleTable& t)
	{
		os << t.line(0);
		t.printRow(os, t.header);
		auto mid = t.line(1);
		if (!t.innerlines)
		{
			os << mid;
			mid.erase();
		}
		for (const auto& row : t.rows)
		{
			os << mid;
			t.printRow(os, row);
		}
		return os << t.line(2);
	}

	void flush()
	{
		rows.clear();
	}

	void setGlobalPrecision(int p)
	{
		precision = p;
	}

	void setStyle(int padSize, Style lineType, int pre = 4, bool innerLines = false)
	{
		padsize = padSize;
		linetype = lineType;
		precision = pre;
		innerlines = innerLines;
	}

	
	void writeToTex(std::string && filename, bool translate = false)
	{
		/*
		 * 
		 * if translate is true , alpha, beta , gamma etc is converted to $\alpha$ etc...
		 * 
		 */
		if (translate)
		{
			for (int i = 0; i < rows.size(); ++i)
			{
				for (int j = 0; j < rows[i].size(); ++j)
				{
					auto it = greeks.find(rows[i][j]);
					if (it != greeks.end())
					{
						rows[i][j] = it->second;
					}
				}
			}
		}

		std::string beginTabular("\\begin{tabular}");
		std::stringstream positionBraces;
		//Erstes Element - nur für die Bestimmung der Anzahl der Elemente
		std::string pos(rows[0].size(), 'l');
		positionBraces << "{" << pos << "}";
		beginTabular += positionBraces.str();

		std::string newLine("\\\\");

		std::vector<std::string> table = {
			"\\documentclass{standalone}",
			"\\usepackage{booktabs}",
			"\\begin{document}",
			beginTabular,
			"\\toprule"
		};

		for (int i = 0; i < header.size(); ++i)
		{
			std::stringstream entries;
			auto entry = header[i];

			if (i == 0)
			{
				entries << entry;
			}
			else
			{
				entries << " & " << entry;
			}
			if (i == header.size() - 1)
			{
				entries << newLine;
			}
			table.push_back(entries.str());
			entries.flush();
		}

		table.push_back("\\midrule");

		for (int i = 0; i < rows.size(); ++i)
		{
			std::stringstream entries;
			for (int j = 0; j < rows[i].size(); ++j)
			{
				auto entry = rows[i][j];
				if (j == 0)
				{
					entries << entry;
				}
				else
				{
					entries << " & " << entry;
				}
				if (j == rows[i].size() - 1)
				{
					entries << newLine;
				}
			}
			table.push_back(entries.str());
			entries.flush();
		}

		table.push_back("\\bottomrule");
		table.push_back("\\end{tabular}");
		table.push_back("\\end{document}");


		// EXPORT   
		auto t = std::time(nullptr);
		auto tm = *std::localtime(&t);
		std::ostringstream oss;
		oss << std::put_time(&tm, "%d-%m-%Y-%H-%M");
		auto timestamp = oss.str();

		fs::create_directory(timestamp);

		std::stringstream outputfile;
		outputfile << timestamp << "/" << filename << "_" << timestamp << ".tex";
		//Write to stream
		std::ofstream ofs;
		ofs.open(outputfile.str());


		if (ofs.good())
		{
			for (const auto& it : table)
			{
				ofs << it << "\n";
			}
		}

		else
		{
			ofs.clear();
		}

		ofs.close();
	}

private:

	//Style
	int padsize;
	Style linetype;
	bool innerlines;
	int precision;

	std::vector<std::string> header;
	std::vector<std::vector<std::string>> rows;
	std::vector<std::size_t> widths;

	variables_map vm_;
	options_description desc_;

	void updateWidths(std::vector<std::string>& list)
	{
		for (const auto& it : list)
			widths.push_back(it.size());
	}

	const std::string markers[9][11]
	{
		{
			//S1
			"-", "|",
			"+", "+", "+",
			"+", "+", "+",
			"+", "+", "+"
		},
		{
			//S2
			".", "|",
			".", ".", ".",
			".", ".", ".",
			".", ".", "."
		},
		{
			//S3
			".", "|",
			"+", "+", "+",
			"+", "+", "+",
			"+", "+", "+"
		},
		{
			//S4
			"-", "|",
			"-", "-", "-",
			"-", "-", "-",
			"-", "-", "-"
		},
		{
			//S5
			"_", "|",
			"+", "+", "+",
			"+", "+", "+",
			"+", "+", "+"
		},
		{
			//S6
			"*", "|",
			"+", "+", "+",
			"+", "+", "+",
			"+", "+", "+"
		},
		{
			//S7
			"_", "|",
			"+", "+", "+",
			"+", "+", "+",
			"+", "+", "+"
		},
		{
			//S8
			"━", "┃",
			"┏", "┳", "┓",
			"┣", "╋", "┫",
			"┗", "┻", "┛"
		},
		{
			//S9
			"═", "║",
			"╔", "╦", "╗",
			"╠", "╬", "╣",
			"╚", "╩", "╝"
		},
	};


	std::map<std::string, std::string> greeks = {
		{"alpha", "$\\alpha$"},
		{"beta", "$\\beta$"},
		{"gamma", "$\\gamma$"},
		{"delta", "$\\delta$"},
		{"epsilon", "$\\varepsilon$"},
		{"zeta", "$\\zeta$"},
		{"eta", "$\\eta$"},
		{"theta", "$\\theta$"},
		{"kappa", "$\\kappa$"},
		{"lambda", "$\\lambda$"},
		{"xi", "$\\xi$"},
		{"pi", "$\\pi$"},
		{"rho", "$\\varrho$"},
		{"sigma", "$\\sigma$"},
		{"tau", "$\\tau$"},
		{"phi", "$\\phi$"},
		{"psi", "$\\psi$"},
		{"omega", "$\\omega$"},
		/*-------------------------------------*/
		{"Alpha", "$\\Alpha$"},
		{"Beta", "$\\Beta$"},
		{"Gamma", "$\\Gamma$"},
		{"Delta", "$\\Delta$"},
		{"Epsilon", "$\\Epsilon$"},
		{"Zeta", "$\\Zeta$"},
		{"Eta", "$\\Eta$"},
		{"Theta", "$\\Theta$"},
		{"Kappa", "$\\Kappa$"},
		{"Lambda", "$\\Lambda$"},
		{"Xi", "$\\Xi$"},
		{"Pi", "$\\Pi$"},
		{"Rho", "$\\Rho$"},
		{"Sigma", "$\\Sigma$"},
		{"Tau", "$\\Tau$"},
		{"Phi", "$\\Phi$"},
		{"Psi", "$\\Psi$"},
		{"Omega", "$\\Omega$"}
	};

	// Member functions    
	void printRow(std::ostream& os, std::vector<std::string> row)
	{
		int n;

		for (unsigned int i = 0; i < row.size(); ++i)
		{
			if (i == 0)
			{
				n = 2;
				std::string space(n, ' ');
				os << space + row[i];
			}
			else
			{
				n = 2 * padsize + 1 + (widths[i - 1] - row[i - 1].size());

				std::string space(n, ' ');
				std::string output = space + row[i];
				os << output;
			}
		}

		os << std::endl;
	}


	std::string line(unsigned n) const
	{
		std::stringstream line;
		n *= 3;
		line << markers[linetype][2 + n];
		for (std::size_t i{0}; i < widths.size() - 1; ++i)
		{
			for (std::size_t j{0}; j < (widths[i] + padsize + padsize); ++j)
			{
				line << markers[linetype][0];
			}
			line << markers[linetype][3 + n];
		}
		for (std::size_t j{0}; j < (widths.back() + padsize + padsize); ++j)
		{
			line << markers[linetype][0];
		}
		line << markers[linetype][4 + n] << '\n';
		return line.str();
	}
};

#endif
