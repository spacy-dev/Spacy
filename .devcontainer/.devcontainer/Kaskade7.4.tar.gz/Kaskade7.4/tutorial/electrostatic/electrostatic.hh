/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2015 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef HEATTRANSFER_HH
#define HEATTRANSFER_HH

#include <algorithm>
#include "fem/functional_aux.hh"
#include "fem/fixdune.hh"
#include "fem/variables.hh"
#include "utilities/linalg/scalarproducts.hh"

/// Electrostatic example
template <class RType, class VarSet, class MatVarSet>
class ElectroStaticFunctional : public Kaskade::FunctionalBase<Kaskade::VariationalFunctional>
{
public:
  using Scalar = RType;
  using OriginVars = VarSet;
  using AnsatzVars = VarSet;
  using TestVars = VarSet;

  static constexpr int dim = AnsatzVars::Grid::dimension;
  static constexpr int VeIdx = 0;
  static constexpr int VeSpaceIdx = boost::fusion::result_of::value_at_c<typename AnsatzVars::Variables,
                                             VeIdx>::type::spaceIndex;
                                             
  typedef typename AnsatzVars::Grid::template Codim<0>::Entity Cell;
  typedef Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension> Position;                                            
                                               

/// \class DomainCache
///
  class DomainCache : public Kaskade::CacheBase<ElectroStaticFunctional,DomainCache>
  {
  public:
    DomainCache (ElectroStaticFunctional<RType, AnsatzVars, MatVarSet> const& f_,
                typename AnsatzVars::VariableSet const& vars_,
                int flags=7): f(f_),data(vars_),epsilon(0.01f)
    {}
    
        void moveTo(Cell const &entity) 
    { e = &entity; }

    template <class Position, class Evaluators>
    void evaluateAt(Position const& x, Evaluators const& evaluators)
    {
      Ve  = component<VeIdx>(data).value(boost::fusion::at_c<VeSpaceIdx>(evaluators));
      dVe = component<VeIdx>(data).derivative(boost::fusion::at_c<VeSpaceIdx>(evaluators));
    
      epsilon = boost::fusion::at_c<0>(f.mat.data).value(*e, x);
      
      //xglob = ent->geometry().global(x);  
    }

    Scalar
    d0() const
    {
      return epsilon * sp(Ve,Ve)/2;
    }

    template<int row>
    Scalar d1_impl(Kaskade::VariationalArg<Scalar,dim,TestVars::template Components<row>::m> const& arg) const
    {
      return epsilon * sp(dVe,arg.derivative) ;
    }

    template<int row, int col>
    Scalar d2_impl(Kaskade::VariationalArg<Scalar,dim,TestVars::template Components<row>::m> const &arg1,
                   Kaskade::VariationalArg<Scalar,dim,AnsatzVars::template Components<row>::m> const &arg2) const
    {
      return epsilon  * sp(arg1.derivative,arg2.derivative);
    }

  private:
    typename AnsatzVars::VariableSet const& data;
    Dune::FieldVector<Scalar,AnsatzVars::template Components<VeIdx>::m> Ve;
    Dune::FieldMatrix<Scalar,AnsatzVars::template Components<VeIdx>::m,dim> dVe;
    Kaskade::LinAlg::EuclideanScalarProduct sp;
    Scalar epsilon;
    
    typename AnsatzVars::Grid::template Codim<0>::Entity const* ent;
    Dune::FieldVector<typename AnsatzVars::Grid::ctype,AnsatzVars::Grid::dimension> xglob;
    int materialId;
    Cell const* e;
    
    ElectroStaticFunctional const& f;
    
  };

/// \class BoundaryCache
///
  class BoundaryCache : public Kaskade::CacheBase<ElectroStaticFunctional,BoundaryCache>
  {

using FaceIterator = typename AnsatzVars::Grid::LeafIntersectionIterator;
  public:
    BoundaryCache (ElectroStaticFunctional<RType, AnsatzVars, MatVarSet> const&,
                  typename AnsatzVars::VariableSet const& vars_,
                  int flags=7):
      data(vars_), penalty(1e20), Ve(0.), VeDirichletBoundaryValue(0.)
    {}

void moveTo(FaceIterator const &face_) { e = &face_; }

    template <class Evaluators>
    void evaluateAt(Dune::FieldVector<typename AnsatzVars::Grid::ctype, dim - 1> const &x, Evaluators const& evaluators)
    {

      using namespace boost::fusion;

      Dune::FieldVector<Scalar, dim> xglob = (*e)->geometry().global(x);
      Ve = boost::fusion::at_c<VeIdx>(data.data).value(boost::fusion::at_c<VeSpaceIdx>(evaluators));
        
      /*
       * UNIT GRID
        if (xglob[1] >= .99999  )
        {
		      penalty = 1e18;
          VeDirichletBoundaryValue = 0;          
   
        }
        else if (xglob[1]<=.00001&& xglob[0]>=0.2 &&xglob[0]<=0.8)
        {
		      penalty = 1e18;
          VeDirichletBoundaryValue = 10;          
        }
        else
        {
          penalty = 0;
        }*/
      
      /*
       * Kondensator !!
       * 
        if (xglob[0]>= 0.2 && xglob[0]<=0.3 && xglob[1]>=0.3 && xglob[1]<=0.6)
        {
		  penalty = 1e12;
          VeDirichletBoundaryValue = 10;          
        }
        else if (xglob[0]>= 0.7 && xglob[0]<=0.8 && xglob[1]>=0.3 && xglob[1]<=0.6)
        {
		  penalty = 1e12;
          VeDirichletBoundaryValue = -10;          
        }
        else
        {
          penalty = 0;
        }*/
      
      /*
       * Quadropol
       */
      if((xglob[0]>= 0.25 || xglob[0]<=0.75) && (xglob[1]<=0.25 || xglob[1]>=0.75))
      {
		  penalty = 1e12;
          VeDirichletBoundaryValue = 10;          
      }
      else if((xglob[0]<= 0.25 || xglob[0]>=0.75) && (xglob[1]>=0.25 || xglob[1]<=0.75))
      {
		  penalty = 1e12;
          VeDirichletBoundaryValue = -10;          
      }
      else
      {
         penalty = 0;
      }
    }

    Scalar d0() const
    {
      return penalty*(Ve-VeDirichletBoundaryValue)*(Ve-VeDirichletBoundaryValue)/2;
    }

    template<int row>
    Scalar d1_impl(Kaskade::VariationalArg<Scalar,dim> const& arg) const
    {
      return penalty*(Ve-VeDirichletBoundaryValue)*arg.value;
    }

    template<int row, int col>
    Scalar d2_impl(Kaskade::VariationalArg<Scalar,dim> const &arg1,
                   Kaskade::VariationalArg<Scalar,dim> const &arg2) const
    {
      return penalty*arg1.value*arg2.value;
    }

  private:
    typename AnsatzVars::VariableSet const& data;
    Scalar penalty;

    FaceIterator const *e;

    int boundary;

    Dune::FieldVector<Scalar,AnsatzVars::template Components<VeIdx>::m> Ve, VeDirichletBoundaryValue;
  };

  
public:
  ElectroStaticFunctional(MatVarSet const& mat_) : mat(mat_){}

  template <int row>
  struct D1: public Kaskade::FunctionalBase<Kaskade::VariationalFunctional>::D1<row>
  {
    static bool const present   = true;
    static bool const constant  = false;
  };

  template <int row, int col>
  struct D2: public Kaskade::FunctionalBase<Kaskade::VariationalFunctional>::D2<row,col>
  {
    static bool const present = true;
    static bool const symmetric = true;
    static bool const lumped = false;
  };

/// \fn integrationOrder
///
  template <class Cell>
  int integrationOrder(Cell const& /* cell */, int shapeFunctionOrder, bool boundary) const
  {
    if (boundary)
      return 2*shapeFunctionOrder;
    else
    {
      int stiffnessMatrixIntegrationOrder = 2*(shapeFunctionOrder-1);
      int sourceTermIntegrationOrder = shapeFunctionOrder;        // as rhs f is constant, i.e. of order 0

      return std::max(stiffnessMatrixIntegrationOrder,sourceTermIntegrationOrder);
    }
  }

  private:
    MatVarSet const& mat;  
    
};

#endif
