/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*  This file is part of the library KASKADE 7                               */
/*    see http://www.zib.de/projects/kaskade7-finite-element-toolbox         */
/*                                                                           */
/*  Copyright (C) 2002-2018 Zuse Institute Berlin                            */
/*                                                                           */
/*  KASKADE 7 is distributed under the terms of the ZIB Academic License.    */
/*    see $KASKADE/academic.txt                                              */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include <iostream>

#include "dune/grid/config.h"
#include "dune/grid/uggrid.hh"

#include "fem/assemble.hh"
#include "fem/istlinterface.hh"
#include "fem/functional_aux.hh"
#include "fem/gridmanager.hh"
#include "fem/lagrangespace.hh"
#include "fem/variables.hh"
#include "io/vtk.hh"
#include "linalg/direct.hh"
#include "utilities/gridGeneration.hh"  // for grid generation (unit square)
#include "utilities/kaskopt.hh"         // for command line option parsing

using namespace Kaskade;
#include "laplace.hh"

int main(int argc, char* argv[])
{
  std::cout << "Start Laplacian tutorial program" << std::endl;



  constexpr int dim = 2;
  int refinements, order;
  double penalty;

  if (getKaskadeOptions(argc,argv,Options
  ("refine", refinements,           5,"uniform mesh refinements")
  ("order",        order,           2,"polynomial ansatz order")
  ("penalty",    penalty,         1e6,"penalty factor for Dirichlet/Nitsche boundary conditions")
  )) return 0;

  using Grid = Dune::UGGrid<dim>;
  using LeafView = Grid::LeafGridView;
  using H1Space = FEFunctionSpace<ContinuousLagrangeMapper<double,LeafView>>;
  using Spaces = boost::fusion::vector<H1Space const*>;
  using VariableDescriptions = boost::fusion::vector<Variable<SpaceIndex<0>,Components<1>>>;
  using VariableSetDesc = VariableSetDescription<Spaces,VariableDescriptions>;
  using Functional = HeatFunctional<double,VariableSetDesc>;
  using Assembler = VariationalFunctionalAssembler<LinearizationAt<Functional> >;
  using Operator = AssembledGalerkinOperator<Assembler>;
  using CoefficientVectors = VariableSetDesc::CoefficientVectorRepresentation<0,1>::type;


  GridManager<Grid> gridManager( createUnitSquare<Grid>() );
  gridManager.globalRefine(refinements);

  // construction of finite element space for the scalar solution u.
  H1Space temperatureSpace(gridManager,gridManager.grid().leafGridView(),order);
  Spaces spaces(&temperatureSpace);
  VariableSetDesc variableSetDesc(spaces,{ "u" });

  Functional F(penalty);

  //construct Galerkin representation
  Assembler assembler(spaces);
  auto u = variableSetDesc.variableSet();
  assembler.assemble(linearization(F,u));

  Operator A(assembler);
  CoefficientVectors solution = variableSetDesc.zeroCoefficientVector();
  CoefficientVectors rhs(assembler.rhs());

  directInverseOperator(A).applyscaleadd(-1.0,rhs,solution);
  component<0>(u) += component<0>(solution);

  Dune::FieldVector<double,dim> x;
  x[0] = 0; x[1] = 0.5;
  std::cout << "Boundary value violation at [" << x << "]: " << component<0>(u).value(x) << " (Dirichlet penalty)\n";
  x[0] = 1;
  std::cout << "Boundary value violation at [" << x << "]: " << component<0>(u).value(x) << " (Nitsche)\n";

  writeVTK(u,"temperature",IoOptions().setOrder(order).setPrecision(7));

  std::cout << "graphical output finished, data in VTK format is written into file temperature.vtu \n";
  std::cout << "End Laplacian tutorial program" << std::endl;
}
